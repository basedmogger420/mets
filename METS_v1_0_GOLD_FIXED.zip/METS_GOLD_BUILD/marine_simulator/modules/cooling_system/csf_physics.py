"""modules/cooling_system/csf_physics.py — re-export for test compatibility"""
from marine_simulator.modules.cooling_system.csf_module import (  # noqa: F401
    PumpStage,
    PumpState,
    CSFState,
    CSFPhysics,
)
