"""
marine_simulator/core/session_db.py
=====================================
SessionDB — SQLite-backed longitudinal session persistence (Feature 4).

Thread-safe via WAL journal mode + connection-per-thread pattern.
Retry logic for BUSY / LOCKED conditions.
"""
from __future__ import annotations
import csv
import os
import sqlite3
import threading
import time
from typing import Dict, List, Optional

_RETRY_DELAY_S: float  = 0.05
_RETRY_MAX:     int    = 60   # up to 3 seconds total


class SessionDB:

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._local   = threading.local()
        self._init_db()

    # ── Connection management ──────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        """Return a per-thread connection with WAL journal mode."""
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self._db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = conn
        return conn

    def _execute_with_retry(self, conn, sql: str, params=()):
        """Execute SQL with exponential retry on BUSY/LOCKED."""
        for attempt in range(_RETRY_MAX):
            try:
                return conn.execute(sql, params)
            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower() or "busy" in str(e).lower():
                    if attempt < _RETRY_MAX - 1:
                        time.sleep(_RETRY_DELAY_S)
                        continue
                raise

    # ── Schema init ───────────────────────────────────────────────────────────

    def _init_db(self):
        conn = self._conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at        REAL    DEFAULT (strftime('%s','now')),
                student_id        TEXT    DEFAULT '',
                student_name      TEXT    DEFAULT '',
                module_id         TEXT    DEFAULT '',
                scenario_id       TEXT    DEFAULT '',
                total_score       INTEGER DEFAULT 0,
                max_score         INTEGER DEFAULT 100,
                grade             TEXT    DEFAULT '',
                pass_pct          REAL    DEFAULT 75.0,
                elapsed_s         REAL    DEFAULT 0.0,
                total_alarms      INTEGER DEFAULT 0,
                alarms_acked      INTEGER DEFAULT 0,
                avg_reaction_ms   REAL    DEFAULT 0.0,
                hard_fail         INTEGER DEFAULT 0,
                hard_fail_reason  TEXT    DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS alarm_events (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  INTEGER NOT NULL REFERENCES sessions(id),
                tick        INTEGER DEFAULT 0,
                alarm_id    TEXT    DEFAULT '',
                severity    INTEGER DEFAULT 0,
                status      TEXT    DEFAULT '',
                timestamp_s REAL    DEFAULT 0.0,
                reaction_ms REAL    DEFAULT 0.0
            );
        """)
        conn.commit()

    # ── Public API ────────────────────────────────────────────────────────────

    def save_session(self, summary: dict) -> int:
        """Persist a session summary and return the new session id."""
        conn = self._conn()
        cur = self._execute_with_retry(conn, """
            INSERT INTO sessions (
                student_id, student_name, module_id, scenario_id,
                total_score, max_score, grade, pass_pct, elapsed_s,
                total_alarms, alarms_acked, avg_reaction_ms,
                hard_fail, hard_fail_reason
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            summary.get("student_id",       ""),
            summary.get("student_name",     ""),
            summary.get("module_id",        ""),
            summary.get("scenario_id",      ""),
            summary.get("total_score",      0),
            summary.get("max_score",        100),
            summary.get("grade",            ""),
            summary.get("pass_pct",         75.0),
            summary.get("elapsed_s",        0.0),
            summary.get("total_alarms",     0),
            summary.get("alarms_acked",     0),
            summary.get("avg_reaction_ms",  0.0),
            1 if summary.get("hard_fail") else 0,
            summary.get("hard_fail_reason", ""),
        ))
        conn.commit()
        return cur.lastrowid

    def save_alarm_events(self, session_id: int, events: list) -> None:
        conn = self._conn()
        for ev in events:
            self._execute_with_retry(conn, """
                INSERT INTO alarm_events
                    (session_id, tick, alarm_id, severity, status, timestamp_s, reaction_ms)
                VALUES (?,?,?,?,?,?,?)
            """, (
                session_id,
                ev.get("tick", 0),
                ev.get("alarm_id", ""),
                ev.get("severity", 0),
                ev.get("status", ""),
                ev.get("timestamp_s", 0.0),
                ev.get("reaction_ms", 0.0),
            ))
        conn.commit()

    def get_student_history(self, student_id: str) -> List[dict]:
        conn = self._conn()
        cur = conn.execute(
            "SELECT * FROM sessions WHERE student_id=? ORDER BY created_at",
            (student_id,)
        )
        return [dict(row) for row in cur.fetchall()]

    def get_learning_curve(self, student_id: str, module_id: str) -> List[dict]:
        conn = self._conn()
        cur = conn.execute(
            """SELECT id, total_score, max_score, grade, created_at
               FROM sessions
               WHERE student_id=? AND module_id=?
               ORDER BY created_at""",
            (student_id, module_id)
        )
        rows = cur.fetchall()
        result = []
        for i, row in enumerate(rows, start=1):
            ms = row["max_score"] or 1
            result.append({
                "attempt":     i,
                "total_score": row["total_score"],
                "max_score":   ms,
                "score_pct":   round((row["total_score"] / ms) * 100.0, 1),
                "grade":       row["grade"],
            })
        return result

    def get_cohort_summary(self, module_id: str) -> List[dict]:
        conn = self._conn()
        cur = conn.execute(
            """SELECT student_id,
                      COUNT(*) AS attempts,
                      AVG(CAST(total_score AS REAL) / CASE WHEN max_score>0 THEN max_score ELSE 1 END * 100) AS avg_score_pct
               FROM sessions
               WHERE module_id=?
               GROUP BY student_id""",
            (module_id,)
        )
        return [dict(row) for row in cur.fetchall()]

    def export_csv(self, path: str) -> int:
        # FIX #15: Sanitize export path — only allow writing to exports/ subdirectory
        import os
        safe_dir = os.path.abspath(os.path.join(os.path.dirname(self._db_path), "exports"))
        os.makedirs(safe_dir, exist_ok=True)
        basename = os.path.basename(path)
        if not basename or not basename.endswith(".csv"):
            basename = "session_export.csv"
        safe_path = os.path.join(safe_dir, basename)
        # Verify no path traversal
        if not os.path.abspath(safe_path).startswith(safe_dir):
            raise ValueError(f"Unsafe export path rejected: {path}")
        conn = self._conn()
        cur = conn.execute("SELECT * FROM sessions ORDER BY created_at")
        fieldnames = [d[0] for d in cur.description]
        rows = cur.fetchall()
        if not rows:
            return 0
        with open(safe_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(dict(row))
        return len(rows)
