"""
marine_simulator/core/base_procedure.py — GOLD v1.0
====================================================
FIXES: #11 (safety valve hysteresis timer support), #36 (timer freeze on done)
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ProcedureStep:
    step_id:        str
    description:    str
    description_ua: str
    points:         int   = 10
    time_budget_s:  float = 60.0
    critical:       bool  = False
    done:       bool  = False
    active:     bool  = False
    penalty:    int   = 0
    start_time: Optional[float] = None
    end_time:   Optional[float] = None

    def elapsed_s(self) -> float:
        if self.start_time is None:
            return 0.0
        end = self.end_time if self.end_time is not None else time.monotonic()
        return end - self.start_time

    def compute_penalty(self, extra_ooo: bool = False) -> int:
        if extra_ooo:
            return self.points
        overtime = max(0.0, self.elapsed_s() - self.time_budget_s)
        raw_penalty = int(overtime * 0.5)
        return min(raw_penalty, self.points)

    def to_dict(self) -> dict:
        return {
            "step_id":        self.step_id,
            "description":    self.description,
            "description_ua": self.description_ua,
            "points":         self.points,
            "done":           self.done,
            "active":         self.active,
            "penalty":        self.penalty,
            "critical":       self.critical,
        }


class BaseProcedure:
    STEP_DEFINITIONS: list = []
    _pass_score_pct:        int = 75
    _borderline_offset_pct: int = 15

    def __init__(self):
        self._steps: List[ProcedureStep] = []
        self._is_complete: bool   = False
        self._report: Optional[dict] = None
        self._action_history: list   = []
        self._ooo_violated: bool     = False
        self.hard_fail: bool         = False
        self.hard_fail_reason: Optional[str] = None
        self.last_acked_alarm_id: str = ""
        self.ack_log: list = []
        self._completed_order: list  = []
        self._scenario_start: float  = time.monotonic()
        self.alarm_acknowledged: bool = False
        self._build_steps()
        if self._steps:
            self._steps[0].active = True
            self._steps[0].start_time = time.monotonic()

    def _build_steps(self):
        for defn in self.STEP_DEFINITIONS:
            self._steps.append(ProcedureStep(
                step_id       = defn["step_id"],
                description   = defn.get("description_en", defn.get("description", defn["step_id"])),
                description_ua= defn.get("description_ua", ""),
                points        = defn.get("points", 10),
                time_budget_s = defn.get("time_budget_s", 60.0),
                critical      = defn.get("critical", False),
            ))

    def _find(self, step_id: str) -> Optional[ProcedureStep]:
        return next((s for s in self._steps if s.step_id == step_id), None)

    def _active_step_index(self) -> int:
        for i, s in enumerate(self._steps):
            if not s.done:
                return i
        return len(self._steps)

    def mark_done(self, step_id: str) -> bool:
        if self._is_complete:
            return False
        step = self._find(step_id)
        if step is None or step.done:
            return False
        expected_idx = self._active_step_index()
        actual_idx   = self._steps.index(step)
        is_ooo = actual_idx > expected_idx
        if is_ooo:
            self._ooo_violated = True
            step.penalty = step.points
        else:
            step.penalty = step.compute_penalty()
        step.done     = True
        step.active   = False
        step.end_time = time.monotonic()
        self._action_history.append({
            "step_id":   step.step_id,
            "points":    step.points,
            "penalty":   step.penalty,
            "elapsed_s": round(step.elapsed_s(), 1),
            "timestamp": time.monotonic(),
            "auto":      False,
            "ooo":       is_ooo,
        })
        self._advance_active()
        if all(s.done for s in self._steps):
            self._finalise()
        return True

    def auto_mark_done(self, step_id: str) -> bool:
        if self._is_complete:
            return False
        step = self._find(step_id)
        if step is None or step.done:
            return False
        step.penalty = 0
        step.done    = True
        step.active  = False
        step.end_time = time.monotonic()
        self._action_history.append({
            "step_id":   step.step_id,
            "points":    step.points,
            "penalty":   0,
            "elapsed_s": round(step.elapsed_s(), 1),
            "timestamp": time.monotonic(),
            "auto":      True,
        })
        self._advance_active()
        if all(s.done for s in self._steps):
            self._finalise()
        return True

    def _advance_active(self):
        active_set = False
        for s in self._steps:
            if not s.done and not active_set:
                s.active = True
                if s.start_time is None:
                    s.start_time = time.monotonic()
                active_set = True
            elif not s.done:
                s.active = False

    def _finalise(self):
        if self._is_complete:
            return
        self._is_complete = True
        for s in self._steps:
            if s.critical and not s.done:
                self.trigger_hard_fail(f"STCW_CRITICAL_STEP_SKIPPED:{s.step_id}")
                s.done    = True
                s.penalty = s.points
        total_earned = sum(max(0, s.points - s.penalty) for s in self._steps)
        max_score    = sum(s.points for s in self._steps)
        score        = max(0, min(total_earned, max_score))
        if self.hard_fail:
            grade = "FAIL"
        elif max_score == 0:
            grade = "PASS"
        else:
            pct = (score / max_score) * 100.0
            if pct >= self._pass_score_pct:
                grade = "DISTINCTION" if pct >= 90 else "PASS"
            elif pct >= (self._pass_score_pct - self._borderline_offset_pct):
                grade = "BORDERLINE_PASS"
            else:
                grade = "FAIL"
        self._report = {
            "score":           score,
            "max_score":       max_score,
            "grade":           grade,
            "hard_fail":       self.hard_fail,
            "hard_fail_reason": self.hard_fail_reason,
            "elapsed_s":       round(sum(s.elapsed_s() for s in self._steps if s.done), 1),
            "penalties":       sum(s.penalty for s in self._steps),
            "pass_score_pct":  self._pass_score_pct,
            "ooo_steps":       sum(1 for h in self._action_history if h.get("ooo")),
        }

    def trigger_hard_fail(self, reason: str):
        if not self.hard_fail:
            self.hard_fail        = True
            self.hard_fail_reason = reason
        if self._report is not None:
            self._report["hard_fail"]        = True
            self._report["hard_fail_reason"] = self.hard_fail_reason
            self._report["grade"]            = "FAIL"

    def acknowledge_alarm(self, alarm_id: str = "") -> None:
        self.last_acked_alarm_id = alarm_id
        self.ack_log.append({"alarm_id": alarm_id, "timestamp_s": time.monotonic()})
        self.mark_done("ACK_ALARM")

    def to_dict(self) -> dict:
        done_count  = sum(1 for s in self._steps if s.done)
        total       = len(self._steps)
        active_step = next((s for s in self._steps if s.active and not s.done), None)
        return {
            "steps":               [s.to_dict() for s in self._steps],
            "progress_pct":        round((done_count / total * 100) if total else 0, 1),
            "is_complete":         self._is_complete,
            "hard_fail":           self.hard_fail,
            "hard_fail_reason":    self.hard_fail_reason,
            "report":              self._report,
            "history":             list(self._action_history),
            "ack_log":             list(self.ack_log),
            "last_acked_alarm_id": self.last_acked_alarm_id,
            "active_step":         active_step.step_id if active_step else None,
        }

    def reset(self):
        self._steps          = []
        self._is_complete    = False
        self._report         = None
        self._action_history = []
        self._ooo_violated   = False
        self.hard_fail       = False
        self.hard_fail_reason = None
        self._pass_score_pct = 75
        # FIX #20: Reset borderline offset too
        self._borderline_offset_pct = 15
        self.last_acked_alarm_id = ""
        self.ack_log         = []
        self._completed_order    = []
        self._scenario_start     = time.monotonic()
        self.alarm_acknowledged  = False
        self._build_steps()
        if self._steps:
            self._steps[0].active = True
            self._steps[0].start_time = time.monotonic()
