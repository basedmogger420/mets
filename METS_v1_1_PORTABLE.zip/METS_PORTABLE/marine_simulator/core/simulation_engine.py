"""
marine_simulator/core/simulation_engine.py
===========================================
SimulationEngine — orchestrates all registered lab modules.

Features:
  • Robust tick loop: a broken module never stops the others (Feature 1)
  • Power coupling: reads DG bus state after each tick and propagates
    set_power_available() to all non-DG modules (Feature 3)
  • tick_count property tracks total ticks; reset_all() zeroes it
  • reset_all() continues past a broken module's reset()
"""
from __future__ import annotations
from typing import Dict, List


class SimulationEngine:

    BLACKOUT_VOLTAGE_THRESHOLD = 50.0   # V below which power is considered lost

    def __init__(self):
        self._modules: Dict[str, object] = {}   # module_id → module
        self._tick_count: int = 0
        self.power_available: bool = True

    # ── Module registry ────────────────────────────────────────────────────────

    def register(self, module) -> None:
        self._modules[module.module_id] = module

    def registered_modules(self) -> List:
        return list(self._modules.values())

    # ── Tick ──────────────────────────────────────────────────────────────────

    def tick(self) -> None:
        """
        Run one simulation tick.

        Feature 1: any module that raises an exception is skipped silently;
        all other modules continue normally.
        """
        for mod in list(self._modules.values()):
            try:
                mod.step()
            except Exception:
                pass   # loop safety — one broken module never stops others

        self._tick_count += 1
        self._update_power_state()

    def _update_power_state(self) -> None:
        """
        Feature 3 — Cross-module power coupling.

        Read the DG module's bus voltage (if registered) and propagate
        power_available to all other modules.  DG module itself is excluded
        from receiving set_power_available() calls.
        """
        dg = self._modules.get("diesel_generator")
        if dg is None:
            return   # no DG registered — assume power available

        try:
            state = dg.get_state()
            voltage = state.get("voltage_v", 400.0)
            new_power = voltage >= self.BLACKOUT_VOLTAGE_THRESHOLD
        except Exception:
            new_power = self.power_available   # keep last known state on error

        if new_power != self.power_available:
            self.power_available = new_power
            for mod_id, mod in self._modules.items():
                if mod_id == "diesel_generator":
                    continue   # DG drives the bus — never receives the call
                if hasattr(mod, "set_power_available"):
                    try:
                        mod.set_power_available(new_power)
                    except Exception:
                        pass

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def tick_count(self) -> int:
        return self._tick_count

    # ── Reset ─────────────────────────────────────────────────────────────────

    def reset_all(self) -> None:
        """Reset every registered module. Broken reset() methods are skipped."""
        self._tick_count    = 0
        self.power_available = True
        for mod in list(self._modules.values()):
            try:
                mod.reset()
            except Exception:
                pass
        # FIX #50: Sync power state immediately after reset
        self._update_power_state()
