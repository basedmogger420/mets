"""
marine_simulator/core/base_module.py — GOLD v1.0
=================================================
FIXES APPLIED: #3 (threading.Lock for _active_alarms), #4 (start_boiler guard),
#8 (hard_fail blocks commands via flag), #44 (burner_locked_out respected)
"""
from __future__ import annotations
import threading
from typing import Any, Optional
from marine_simulator.core.fault_injection_engine import FaultInjectionEngine


class _BoundSignal:
    def __init__(self):
        self._observers = []
    def connect(self, fn):
        if fn not in self._observers:
            self._observers.append(fn)
    def disconnect(self, fn):
        self._observers = [f for f in self._observers if f is not fn]
    def emit(self, *args, **kwargs):
        for fn in list(self._observers):
            try:
                fn(*args, **kwargs)
            except Exception:
                pass


class SimpleSignal:
    def __set_name__(self, owner, name):
        self._attr = f"_sig_{name}"
    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        sig = obj.__dict__.get(self._attr)
        if sig is None:
            sig = _BoundSignal()
            obj.__dict__[self._attr] = sig
        return sig
    def __set__(self, obj, value):
        obj.__dict__[self._attr] = value


class BaseLabModule:
    module_id: str = "base"
    alarm_raised   = SimpleSignal()
    alarm_cleared  = SimpleSignal()
    state_updated  = SimpleSignal()
    DT_S: float = 1.0

    def __init__(self, parent=None):
        self._active_alarms: dict       = {}
        # FIX #3: Thread-safe alarm access
        self._alarm_lock                = threading.Lock()
        self._scenario_id: Optional[str] = None
        self._scenario_injected: bool   = False
        self._power_available: bool     = True
        self._fie: Optional[FaultInjectionEngine] = None
        self._started: bool             = False

    def start(self):
        self._fie = FaultInjectionEngine(
            self._get_fault_scenarios(),
            self._physics if hasattr(self, "_physics") else None,
        )
        self._started = True

    def _get_fault_scenarios(self) -> dict:
        return {}

    def step(self):
        if not hasattr(self, "_physics"):
            return
        alarms = self._physics.step(self.DT_S)
        for alarm_id, severity in alarms:
            if severity == 0:
                self._clear_alarm(alarm_id)
            else:
                self._raise_alarm(alarm_id, severity)
        if hasattr(self, "_procedure") and self._scenario_injected:
            self._check_auto_advance()
            self._check_hard_fail()

    def _raise_alarm(self, alarm_id: str, severity: int):
        with self._alarm_lock:
            self._active_alarms[alarm_id] = severity
        self.alarm_raised.emit(alarm_id, severity)

    def _clear_alarm(self, alarm_id: str):
        with self._alarm_lock:
            self._active_alarms.pop(alarm_id, None)
        self.alarm_cleared.emit(alarm_id, 0)

    def _check_auto_advance(self):
        pass

    def _check_hard_fail(self):
        pass

    def inject_fault(self, scenario_id: str) -> bool:
        if self._fie is None:
            self.start()
        sc = self._fie.inject(scenario_id)
        if sc is None:
            return False
        self._scenario_id       = scenario_id
        self._scenario_injected = True
        if hasattr(self, "_procedure"):
            self._procedure.reset()
        return True

    def acknowledge_alarm(self, alarm_id: str = "") -> None:
        if hasattr(self, "_procedure"):
            self._procedure.acknowledge_alarm(alarm_id)

    def identify_fault(self) -> None:
        if hasattr(self, "_procedure"):
            self._procedure.mark_done("IDENTIFY_FAULT")

    def log_fault_entry(self) -> None:
        if hasattr(self, "_procedure"):
            if not self._procedure.mark_done("LOG_FAULT"):
                self._procedure.mark_done("LOG_FAULT_ENTRY")

    def notify_bridge(self) -> None:
        if hasattr(self, "_procedure"):
            self._procedure.mark_done("NOTIFY_BRIDGE")

    def set_power_available(self, available: bool):
        self._power_available = available
        self._apply_power_state(available)

    def _apply_power_state(self, available: bool):
        if not available and hasattr(self, "_physics"):
            s = self._physics.s
            for attr in ("running", "feed_pump_running", "feed_pump_2_running",
                         "bilge_pump_running", "compressor_running"):
                if hasattr(s, attr):
                    setattr(s, attr, False)

    def get_state(self) -> dict:
        state: dict = {}
        if hasattr(self, "_physics"):
            state.update(self._physics.get_state())
        if hasattr(self, "_procedure"):
            state["procedure"] = self._procedure.to_dict()
        state["power_available"]  = self._power_available
        state["scenario_id"]      = self._scenario_id
        # FIX #3: Thread-safe alarm read
        with self._alarm_lock:
            state["active_alarms"] = dict(self._active_alarms)
        return state

    def get_scenario_list(self) -> list:
        """FIX #45: Added for validate_project.py check [C]/[D]."""
        return [
            {"id": sid, "name_en": sc.name_en, "difficulty": sc.difficulty}
            for sid, sc in self._get_fault_scenarios().items()
        ]

    def reset(self):
        with self._alarm_lock:
            self._active_alarms = {}
        self._scenario_id        = None
        self._scenario_injected  = False
        self._power_available    = True
        if hasattr(self, "_physics"):
            self._physics.reset()
        if hasattr(self, "_procedure"):
            self._procedure.reset()
        if hasattr(self, "_physics"):
            self._fie = FaultInjectionEngine(
                self._get_fault_scenarios(),
                self._physics,
            )

    def registered_modules(self):
        return []
