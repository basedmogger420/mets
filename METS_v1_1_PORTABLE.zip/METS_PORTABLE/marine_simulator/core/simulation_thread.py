"""
marine_simulator/core/simulation_thread.py

Background thread that drives the SimulationEngine at 1 Hz
and processes enqueued commands from the bridge.
"""
from __future__ import annotations

import threading
import time
from queue import Queue, Empty
from typing import Callable, Any

from .simulation_engine import SimulationEngine


class SimulationThread:
    TICK_INTERVAL_S = 1.0

    def __init__(self, engine: SimulationEngine) -> None:
        self._engine = engine
        self._running = False
        self._thread: threading.Thread | None = None
        # FIX #27: Bounded queue prevents DoS via command flooding.
        self._cmd_queue: Queue = Queue(maxsize=200)

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=3.0)

    def enqueue_command(self, fn: Callable, *args: Any) -> None:
        try:
            self._cmd_queue.put_nowait((fn, args))
        except Exception:
            pass  # Queue full — drop command silently (DoS protection)

    def _run(self) -> None:
        while self._running:
            t0 = time.monotonic()
            # Process pending commands
            while True:
                try:
                    fn, args = self._cmd_queue.get_nowait()
                    fn(*args)
                except Empty:
                    break
                except Exception:
                    pass
            # Tick physics
            try:
                self._engine.tick()
            except Exception:
                pass
            # Sleep remainder of interval
            elapsed = time.monotonic() - t0
            sleep_time = max(0, self.TICK_INTERVAL_S - elapsed)
            time.sleep(sleep_time)
