"""
marine_simulator/core/ship_system_protocol.py

ShipSystemProtocol  — structural typing interface for all lab modules.

FIX-6: Instead of duck-typing, the bridge now validates that every registered
module satisfies this Protocol at startup.  No existing module code needs to
change — Python's @runtime_checkable Protocol uses structural subtyping.

Usage in websocket_server.py:
    from marine_simulator.core.ship_system_protocol import ShipSystemProtocol
    assert isinstance(module, ShipSystemProtocol), f"{type(module)} missing required interface"
"""
from __future__ import annotations
from typing import Protocol, runtime_checkable


@runtime_checkable
class ShipSystemProtocol(Protocol):
    """
    Every ship system module MUST expose these members.
    The bridge checks isinstance(module, ShipSystemProtocol) at load time.
    """
    module_id: str          # unique string ID matching LAB_METADATA entry

    def start(self) -> None:
        """Called once when the bridge initialises.  Start background tasks."""
        ...

    def reset(self) -> None:
        """Return module to initial state.  Called by instructor reset command."""
        ...

    def step(self) -> None:
        """Advance physics one tick.  Called by SimulationThread at 1 Hz."""
        ...

    def get_state(self) -> dict:
        """Return complete JSON-serialisable state snapshot."""
        ...
