"""
marine_simulator/core/assessment_rules.py — GOLD v1.0
======================================================
FIXES: #16 (Lock in rebuild_procedure), #20 (_borderline_offset_pct in rebuild),
#23 (monkey-patch guard against re-application)
"""
from __future__ import annotations
import logging, threading
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)
ASSESSMENT_RULES: Dict[str, Dict[str, Dict]] = {}


def register_module_rules(module: Any) -> None:
    mid = getattr(module, "module_id", None)
    if not mid:
        return
    scenarios: dict = {}
    try:
        scenarios = module._get_fault_scenarios()
    except Exception as exc:
        log.error("AssessmentRules: cannot load scenarios from %s: %s", mid, exc)
        return
    rules = {}
    for sid, scenario in scenarios.items():
        rules[sid] = {
            "steps":          list(scenario.expected_steps),
            "pass_score_pct": getattr(scenario, "pass_score_pct", 75),
            "name_en":        scenario.name_en,
            "difficulty":     scenario.difficulty,
        }
    ASSESSMENT_RULES[mid] = rules
    log.info("AssessmentRules: registered %d scenario(s) for module=%s", len(rules), mid)


def get_steps(module_id: str, scenario_id: str) -> Optional[List[str]]:
    return ASSESSMENT_RULES.get(module_id, {}).get(scenario_id, {}).get("steps")


def get_rules(module_id: str, scenario_id: str) -> Optional[Dict]:
    return ASSESSMENT_RULES.get(module_id, {}).get(scenario_id)


def build_procedure_state(module: Any, scenario_id: str) -> dict:
    proc = getattr(module, "_procedure", None)
    if proc is None:
        return {}
    state_dict = proc.to_dict()
    rules = get_rules(getattr(module, "module_id", ""), scenario_id)
    if rules:
        state_dict["scenario_id"]         = scenario_id
        state_dict["scenario_name_en"]    = rules.get("name_en", "")
        state_dict["scenario_difficulty"] = rules.get("difficulty", 1)
    return state_dict


class DynamicProcedureManager:
    def __init__(self) -> None:
        self._event_bus: Optional[Any] = None

    def set_event_bus(self, bus: Any) -> None:
        self._event_bus = bus

    def rebuild_procedure(self, module: Any, scenario_id: str) -> None:
        mid = getattr(module, "module_id", "")
        steps = get_steps(mid, scenario_id)
        if steps is None:
            log.warning("DynamicProcedureManager: no steps for %s/%s", mid, scenario_id)
            return
        proc = getattr(module, "_procedure", None)
        if proc is None:
            return
        all_defs = {d["step_id"]: d for d in type(proc).STEP_DEFINITIONS}
        new_defs = []
        for sid in steps:
            if sid in all_defs:
                new_defs.append(dict(all_defs[sid]))
            else:
                log.warning("DynamicProcedureManager: step '%s' in %s/%s not in STEP_DEFINITIONS",
                            sid, mid, scenario_id)
        if not new_defs:
            log.error("DynamicProcedureManager: zero valid steps for %s/%s", mid, scenario_id)
            return
        from marine_simulator.core.base_procedure import ProcedureStep
        import time as _time

        def _make_step(d):
            return ProcedureStep(
                step_id       = d["step_id"],
                description   = d.get("description_en", d.get("description", d["step_id"])),
                description_ua= d.get("description_ua", ""),
                points        = d.get("points", 10),
                time_budget_s = d.get("time_budget_s", 60.0),
                critical      = d.get("critical", False),
            )

        # FIX #16: Thread-safe procedure rebuild
        if not hasattr(proc, '_rebuild_lock'):
            proc._rebuild_lock = threading.Lock()
        with proc._rebuild_lock:
            proc._steps = [_make_step(d) for d in new_defs]
            proc._scenario_start = _time.monotonic()
            proc._completed_order.clear()
            proc._action_history.clear()
            proc._is_complete = False
            proc._report = None
            proc.alarm_acknowledged = False
            proc.hard_fail = False
            proc.hard_fail_reason = None
            proc._ooo_violated = False
            proc.last_acked_alarm_id = ""
            proc.ack_log.clear()
            rules = get_rules(mid, scenario_id)
            if rules:
                proc._pass_score_pct = rules.get("pass_score_pct", 75)
                # FIX #20: Also reset borderline offset
                proc._borderline_offset_pct = rules.get("borderline_offset_pct", 15)
            if proc._steps:
                proc._steps[0].active = True
                proc._steps[0].start_time = _time.monotonic()

        log.info("DynamicProcedureManager: rebuilt %s/%s with %d steps: %s",
                 mid, scenario_id, len(new_defs), [d["step_id"] for d in new_defs])
        if self._event_bus is not None:
            self._event_bus.publish("procedure_reset", {
                "module_id": mid, "scenario_id": scenario_id,
                "steps": [d["step_id"] for d in new_defs],
            })


_manager: Optional[DynamicProcedureManager] = None


def get_dynamic_procedure_manager() -> DynamicProcedureManager:
    global _manager
    if _manager is None:
        _manager = DynamicProcedureManager()
    return _manager


def patch_base_module_inject_fault() -> None:
    from marine_simulator.core.base_module import BaseLabModule
    # FIX #23: Guard against double-patching
    if getattr(BaseLabModule, '_inject_fault_patched', False):
        log.info("AssessmentRules: inject_fault already patched — skipping")
        return
    _orig_inject = BaseLabModule.inject_fault

    def _patched_inject(self, scenario_id: str) -> bool:
        result = _orig_inject(self, scenario_id)
        active_scenario = getattr(self, "_scenario_id", scenario_id)
        if active_scenario and getattr(self, "_scenario_injected", False):
            get_dynamic_procedure_manager().rebuild_procedure(self, active_scenario)
        return result

    BaseLabModule.inject_fault = _patched_inject
    BaseLabModule._inject_fault_patched = True
    log.info("AssessmentRules: BaseLabModule.inject_fault patched")
