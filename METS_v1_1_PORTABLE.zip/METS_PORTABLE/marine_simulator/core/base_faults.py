"""
marine_simulator/core/base_faults.py
=====================================
Re-exports FaultScenario from fault_injection_engine for backward compatibility.
All modules that do `from marine_simulator.core.base_faults import FaultScenario`
will continue to work without modification.
"""
from marine_simulator.core.fault_injection_engine import (   # noqa: F401
    FaultScenario,
    FaultInjectionEngine,
    apply_gas_charge_bernoulli_leak,
    apply_fluid_pressure_bernoulli_leak,
)
