"""
marine_simulator/core/fault_injection_engine.py — GOLD v1.0
============================================================
FIXES: #12 (thread-safe _fie_injecting via Lock), #48 (atomic injection with rollback)
"""
from __future__ import annotations
import copy, math, threading, time
from typing import Any, Callable, Dict, Optional


def apply_gas_charge_bernoulli_leak(charge_pct, pressure_bar, dt_s, orifice_coeff=0.012):
    if charge_pct <= 0.0:
        return 0.0
    rate = orifice_coeff * math.sqrt(max(0.0, pressure_bar))
    return max(0.0, min(100.0, charge_pct - rate * dt_s))


def apply_fluid_pressure_bernoulli_leak(pressure_bar, tank_level_pct, dt_s, orifice_coeff=0.008):
    if tank_level_pct <= 0.0 or pressure_bar <= 0.0:
        return 0.0, 0.0
    rate = orifice_coeff * math.sqrt(max(0.0, pressure_bar))
    new_pressure = max(0.0, pressure_bar - rate * dt_s * 10.0)
    new_level    = max(0.0, tank_level_pct - rate * dt_s * 2.0)
    return new_pressure, new_level


class FaultScenario:
    __slots__ = (
        "scenario_id", "name_en", "name_ua", "description_en",
        "difficulty", "expected_steps", "_apply_fn", "interrupt_overrides",
    )
    def __init__(self, scenario_id, name_en, name_ua="", description_en="",
                 difficulty=1, expected_steps=None, _apply_fn=None,
                 interrupt_overrides=None):
        self.scenario_id       = scenario_id
        self.name_en           = name_en
        self.name_ua           = name_ua
        self.description_en    = description_en
        self.difficulty        = difficulty
        self.expected_steps    = expected_steps or []
        self._apply_fn         = _apply_fn
        self.interrupt_overrides = interrupt_overrides or {}


class FaultInjectionEngine:
    def __init__(self, scenarios: Dict[str, FaultScenario], physics):
        self._scenarios = scenarios
        self._physics   = physics
        # FIX #12: Thread-safe injection guard
        self._fie_lock: threading.Lock = threading.Lock()
        self._fie_injecting: bool = False

    @property
    def scenario_ids(self) -> list:
        return list(self._scenarios.keys())

    def inject(self, scenario_id: str) -> Optional[FaultScenario]:
        # FIX #12: Thread-safe guard
        with self._fie_lock:
            if self._fie_injecting:
                return None
            self._fie_injecting = True
        try:
            sc = self._scenarios.get(scenario_id)
            if sc is None:
                return None

            # FIX #48: Save state snapshot for atomic rollback
            state_snapshot = None
            if hasattr(self._physics, 's'):
                try:
                    state_snapshot = copy.copy(self._physics.s)
                except Exception:
                    pass

            try:
                # Step 1: Apply interrupt_overrides immediately
                if sc.interrupt_overrides and hasattr(self._physics, "s"):
                    for attr, val in sc.interrupt_overrides.items():
                        try:
                            setattr(self._physics.s, attr, val)
                        except (AttributeError, TypeError):
                            pass
                # Step 2: Run _apply_fn
                if sc._apply_fn is not None:
                    sc._apply_fn(self._physics)
            except Exception:
                # FIX #48: Rollback on failure
                if state_snapshot is not None:
                    try:
                        self._physics.s = state_snapshot
                    except Exception:
                        pass
                return None

            return sc
        finally:
            with self._fie_lock:
                self._fie_injecting = False
