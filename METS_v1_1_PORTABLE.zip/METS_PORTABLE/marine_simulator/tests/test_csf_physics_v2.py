"""
marine_simulator/tests/test_csf_physics_v2.py

Unit tests for CoolingPhysics v2.0 — verifies all 6 audit fixes.
Run:  pytest marine_simulator/tests/test_csf_physics_v2.py -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import pytest
from marine_simulator.modules.cooling_system.csf_physics import (
    CoolingPhysics, PumpStage
)


@pytest.fixture
def p() -> CoolingPhysics:
    return CoolingPhysics()


# ── FIX-1: Alarm spam ──────────────────────────────────────────────────────

def test_fix1_pump_fault_alarm_fires_once(p):
    """SW_PUMP_P1_FAULT must fire exactly once, not every tick."""
    p.inject_pump_failure("P1")
    all_events = []
    for _ in range(10):
        all_events += p.step(1.0)
    fault_raises = [e for e in all_events if e == ("SW_PUMP_P1_FAULT", 2)]
    assert len(fault_raises) == 1, f"Expected 1 fault raise, got {len(fault_raises)}"


def test_fix1_low_flow_alarm_fires_once(p):
    """COOLING_LOW_FLOW must fire once when pump stops, not every tick."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)   # pump running, no alarm
    p.stop_pump("P1")
    all_events = []
    for _ in range(20): all_events += p.step(1.0)
    low_flow_events = [e for e in all_events if e[0] == "COOLING_LOW_FLOW" and e[1] == 2]
    assert len(low_flow_events) == 1, f"Expected 1 LOW_FLOW raise, got {len(low_flow_events)}"


def test_fix1_low_flow_clears_with_hysteresis(p):
    """LOW_FLOW must clear only when flow exceeds FLOW_LOW_CLEAR_LS (2 L/s)."""
    p.stop_pump("P1")
    events_initial = []
    for _ in range(5): events_initial += p.step(1.0)
    assert any(e[0] == "COOLING_LOW_FLOW" for e in events_initial)

    # Start pump and let it ramp up past 2 L/s
    p.start_pump("P1")
    clear_events = []
    for _ in range(15): clear_events += p.step(1.0)
    assert any(e == ("COOLING_LOW_FLOW", 0) for e in clear_events), \
        "LOW_FLOW should clear after flow exceeds 2 L/s"


# ── FIX-2: Dead-head fault ─────────────────────────────────────────────────

def test_fix2_dead_head_fault_after_30s(p):
    """Closing sea chest valve while P1 running must fault P1 after 30s."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)   # let pump reach RUNNING
    assert p.s.sw_pump_p1.stage == PumpStage.RUNNING

    p.set_sea_chest_valve(False)
    events = []
    for _ in range(35): events += p.step(1.0)

    assert p.s.sw_pump_p1.stage == PumpStage.FAULT
    assert p.s.sw_pump_p1.seal_leak is True
    dead_head_events = [e for e in events if "DEAD_HEAD" in e[0]]
    assert len(dead_head_events) == 1, "Dead-head fault event should fire once"


def test_fix2_dead_head_timer_resets_when_valve_opens(p):
    """Dead-head timer resets if valve reopened before 30s expires."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)

    p.set_sea_chest_valve(False)
    for _ in range(15): p.step(1.0)    # 15s — below 30s threshold
    p.set_sea_chest_valve(True)
    for _ in range(20): p.step(1.0)    # 20s more with valve open

    assert p.s.sw_pump_p1.stage != PumpStage.FAULT, \
        "Pump should NOT fault if valve reopened before 30s"
    assert p.s.sw_pump_p1.dead_head_timer == 0.0


def test_fix2_start_pump_blocked_with_closed_valve(p):
    """start_pump should return SEA_CHEST_VALVE_CLOSED if valve is closed."""
    p.set_sea_chest_valve(False)
    result = p.start_pump("P1")
    assert result == "SEA_CHEST_VALVE_CLOSED"


# ── FIX-3: Cavitation ──────────────────────────────────────────────────────

def test_fix3_cavitation_on_severe_blockage(p):
    """Blockage > 75% drops suction below NPSH_MIN → cavitation alarm."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)

    p.inject_sea_chest_blockage(0.85)   # 85% blockage → suction ~0.27 bar < 0.5
    events = []
    for _ in range(5): events += p.step(1.0)

    cavitation_events = [e for e in events if "CAVITATION" in e[0] and e[1] == 2]
    assert len(cavitation_events) >= 1, "Cavitation alarm should fire"
    assert p.s.sw_pump_p1.cavitating is True


def test_fix3_cavitation_fault_after_90s(p):
    """90 seconds of cavitation should force pump to FAULT."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)

    p.inject_sea_chest_blockage(0.9)
    events = []
    for _ in range(95): events += p.step(1.0)

    assert p.s.sw_pump_p1.stage == PumpStage.FAULT
    damage_events = [e for e in events if "CAVITATION_DAMAGE" in e[0]]
    assert len(damage_events) == 1


def test_fix3_moderate_blockage_no_cavitation(p):
    """60% blockage (Scenario B) should NOT immediately cause cavitation."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)

    p.inject_sea_chest_blockage(0.6)   # blockage_factor = 0.4 → suction ~0.72 bar
    for _ in range(10): p.step(1.0)

    assert p.s.sw_pump_p1.cavitating is False, \
        "60% blockage should not cause cavitation (suction still above NPSH)"


# ── FIX-4: Fouling factor ──────────────────────────────────────────────────

def test_fix4_fouled_cooler_raises_temperature(p):
    """With cooler fouled to 0.6 UA, engine temp should rise despite normal flow."""
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)

    # Record baseline temp (should be near steady state ~72°C with normal cooling)
    for _ in range(50): p.step(1.0)
    temp_clean = p.s.engine_temp_c

    p.reset()
    p.start_pump("P1")
    for _ in range(10): p.step(1.0)
    p.inject_cooler_fouling(0.4)      # UA reduced to 60%
    for _ in range(50): p.step(1.0)
    temp_fouled = p.s.engine_temp_c

    assert temp_fouled > temp_clean + 5, \
        f"Fouled cooler should cause higher temp: clean={temp_clean:.1f} fouled={temp_fouled:.1f}"


def test_fix4_cooler_dp_rises_with_fouling(p):
    """Cooler ΔP should increase when fouling is injected."""
    initial_dp = p.s.cooler_dp_bar
    p.inject_cooler_fouling(0.5)
    assert p.s.cooler_dp_bar > initial_dp


# ── FIX-5: Temperature alarm hysteresis (regression) ─────────────────────

def test_fix5_temp_alarm_hysteresis(p):
    """HIGH_TEMP alarm must not re-fire until temp drops 3°C below setpoint."""
    p.s.engine_temp_c = 84.5     # after step → ~84.7  (below 85 threshold)
    events_before = p.step(1.0)
    assert not any(e[0] == "COOLING_HIGH_TEMP" for e in events_before)

    p.s.engine_temp_c = 85.5     # after step → ~85.7  (above 85 threshold)
    events_raise = p.step(1.0)
    assert any(e == ("COOLING_HIGH_TEMP", 2) for e in events_raise)

    # Drops to 83°C — below 85 but not below 82 (hysteresis threshold)
    p.s.engine_temp_c = 83.0
    events_mid = p.step(1.0)
    assert not any(e[0] == "COOLING_HIGH_TEMP" for e in events_mid), \
        "Alarm should NOT clear at 83°C — hysteresis requires drop to 82°C"

    # Now drops below 82
    p.s.engine_temp_c = 81.5
    events_clear = p.step(1.0)
    assert any(e == ("COOLING_HIGH_TEMP", 0) for e in events_clear), \
        "Alarm should clear at 81.5°C"


# ── General: reset clears all state ────────────────────────────────────────

def test_reset_clears_all_faults(p):
    """reset() must return physics to clean initial state."""
    p.inject_pump_failure("P1")
    p.inject_cooler_fouling(0.5)
    p.inject_sea_chest_blockage(0.8)
    for _ in range(10): p.step(1.0)

    p.reset()
    assert p.s.sw_pump_p1.stage == PumpStage.STOPPED
    assert p.s.cooler_ua_factor == 1.0
    assert p.s.sea_chest_blocked is False
    assert p.s.engine_temp_c == pytest.approx(72.0)
    assert p.s.p1_fault_latched is False
    assert p.s.low_flow_latched is False
