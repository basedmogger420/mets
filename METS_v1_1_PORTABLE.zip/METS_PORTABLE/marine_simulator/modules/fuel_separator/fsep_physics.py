"""modules/fuel_separator/fsep_physics.py — Lab 7 Fuel Separator physics"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass
class FuelSepState:
    running: bool = True
    bowl_speed_rpm: float = 7500.0
    fuel_temp_c: float = 98.0
    clean_fuel_flow_ls: float = 0.8
    sludge_level_pct: float = 5.0
    heater_on: bool = True
    motor_fault: bool = False
    water_transducer_ok: bool = True
    _low_speed_latched: bool = False
    _high_sludge_latched: bool = False
    _heater_fault_latched: bool = False

class FuelSepPhysics:
    NOMINAL_RPM = 7500.0
    NOMINAL_FLOW_LS = 0.8
    OPTIMAL_TEMP_C = 98.0
    HIGH_SLUDGE_PCT = 75.0  # FIX: was 80 — alarm at 75% for earlier warning
    LOW_SPEED_RPM = 5000.0
    TAU_RPM = 15.0; TAU_FLOW = 10.0; TAU_TEMP = 45.0

    def __init__(self): self.s = FuelSepState()

    def step(self, dt_s: float) -> list[tuple[str, int]]:
        target_rpm = self.NOMINAL_RPM if self.s.running and not self.s.motor_fault else 0.0
        if self.s.motor_fault and self.s.running: target_rpm = 3000.0
        self.s.bowl_speed_rpm += (target_rpm - self.s.bowl_speed_rpm) / self.TAU_RPM * dt_s
        target_temp = self.OPTIMAL_TEMP_C if self.s.heater_on else 25.0
        self.s.fuel_temp_c += (target_temp - self.s.fuel_temp_c) / self.TAU_TEMP * dt_s
        # Feature 2 — RPM gating: purification only when bowl speed >= 95% of nominal.
        # This prevents instant throughput on startup (realistic Westfalia behaviour).
        PURIFY_THRESHOLD_RPM = self.NOMINAL_RPM * 0.95   # 7125 RPM
        if self.s.running and self.s.bowl_speed_rpm >= PURIFY_THRESHOLD_RPM:
            eff = min(1.0, self.s.fuel_temp_c / self.OPTIMAL_TEMP_C)
            target_flow = self.NOMINAL_FLOW_LS * eff * (self.s.bowl_speed_rpm / self.NOMINAL_RPM)
        else: target_flow = 0.0
        self.s.clean_fuel_flow_ls += (target_flow - self.s.clean_fuel_flow_ls) / self.TAU_FLOW * dt_s
        if self.s.running: self.s.sludge_level_pct = min(100.0, self.s.sludge_level_pct + 0.02 * dt_s)
        # Feature 1 — Safety clamping
        self.s.bowl_speed_rpm    = max(0.0, min(self.s.bowl_speed_rpm, self.NOMINAL_RPM * 1.05))
        self.s.fuel_temp_c       = max(0.0, min(self.s.fuel_temp_c, 150.0))
        self.s.clean_fuel_flow_ls = max(0.0, min(self.s.clean_fuel_flow_ls, self.NOMINAL_FLOW_LS * 1.1))
        self.s.sludge_level_pct  = max(0.0, min(self.s.sludge_level_pct, 100.0))
        return self._eval_alarms()

    def _eval_alarms(self) -> list[tuple[str, int]]:
        ev = []
        if self.s.bowl_speed_rpm < self.LOW_SPEED_RPM and self.s.running and not self.s._low_speed_latched:
            self.s._low_speed_latched = True; ev.append(("FUELSEP_LOW_SPEED", 2))
        elif self.s.bowl_speed_rpm > self.LOW_SPEED_RPM + 500 and self.s._low_speed_latched:
            self.s._low_speed_latched = False; ev.append(("FUELSEP_LOW_SPEED", 0))
        if self.s.sludge_level_pct > self.HIGH_SLUDGE_PCT and not self.s._high_sludge_latched:
            self.s._high_sludge_latched = True; ev.append(("FUELSEP_HIGH_SLUDGE", 2))
        elif self.s.sludge_level_pct < self.HIGH_SLUDGE_PCT - 10 and self.s._high_sludge_latched:
            self.s._high_sludge_latched = False; ev.append(("FUELSEP_HIGH_SLUDGE", 0))
        if not self.s.heater_on and self.s.running and not self.s._heater_fault_latched:
            self.s._heater_fault_latched = True; ev.append(("FUELSEP_HEATER_FAULT", 2))
        elif self.s.heater_on and self.s._heater_fault_latched:
            self.s._heater_fault_latched = False; ev.append(("FUELSEP_HEATER_FAULT", 0))
        return ev

    def get_state(self) -> dict:
        return {"running": self.s.running, "bowl_speed_rpm": round(self.s.bowl_speed_rpm, 0),
                "fuel_temp_c": round(self.s.fuel_temp_c, 1), "clean_fuel_flow_ls": round(self.s.clean_fuel_flow_ls, 3),
                "sludge_level_pct": round(self.s.sludge_level_pct, 1), "heater_on": self.s.heater_on,
                "motor_fault": self.s.motor_fault}

    def inject_motor_fault(self): self.s.motor_fault = True
    def inject_heater_failure(self): self.s.heater_on = False
    def inject_high_sludge(self): self.s.sludge_level_pct = 85.0
    def reset(self): self.s = FuelSepState()
