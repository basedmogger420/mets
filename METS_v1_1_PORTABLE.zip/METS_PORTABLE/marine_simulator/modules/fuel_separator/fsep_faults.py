"""modules/fuel_separator/fsep_faults.py — Lab 7
v8: interrupt_overrides added for zero-latency alarm on first tick.
"""
from marine_simulator.core.base_faults import FaultScenario
FAULT_SCENARIOS: dict[str, FaultScenario] = {}
def _register():
    FAULT_SCENARIOS["fsep_motor"] = FaultScenario(
        scenario_id="fsep_motor",
        name_en="Bowl Motor Fault — Speed Drop ★",
        name_ua="Несправність мотора — падіння обертів ★",
        description_en="Motor winding fault. Bowl speed drops. Poor separation. Switch to standby separator.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","SWITCH_STANDBY","VERIFY_FUEL","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_motor_fault(),
        # Drop bowl speed below PURIFY_THRESHOLD_RPM (6000) immediately
        interrupt_overrides={"bowl_speed_rpm": 4200.0},
    )
    FAULT_SCENARIOS["fsep_heater"] = FaultScenario(
        scenario_id="fsep_heater",
        name_en="Fuel Heater Failure — Cold Fuel ★★",
        name_ua="Відмова нагрівача палива — холодне паливо ★★",
        description_en="Heater fails. Fuel temp drops, viscosity too high for separation.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","RESTORE_HEATING","VERIFY_FUEL","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_heater_failure(),
        # Flag heater off immediately; physics will naturally degrade flow
        interrupt_overrides={"heater_on": False},
    )
    FAULT_SCENARIOS["fsep_sludge"] = FaultScenario(
        scenario_id="fsep_sludge",
        name_en="Sludge Tank Full — Discharge Required ★",
        name_ua="Повний шламовий танк — потрібне розвантаження ★",
        description_en="Sludge tank nearly full. Must discharge before overflow contaminates clean fuel.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","DISCHARGE_SLUDGE","VERIFY_FUEL","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_high_sludge(),
        # Push sludge above HIGH_SLUDGE_PCT (80.0) immediately
        interrupt_overrides={"sludge_level_pct": 85.0},
    )
_register()

class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        # FIX-SCORE-2: VERIFY_FUEL gates behind ACK — nominal startup satisfies this.
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.clean_fuel_flow_ls > 0.6 and state.bowl_speed_rpm > 6000:
            procedure.auto_mark_done("VERIFY_FUEL")
