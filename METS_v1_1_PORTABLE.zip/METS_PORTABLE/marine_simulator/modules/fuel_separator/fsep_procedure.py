"""modules/fuel_separator/fsep_procedure.py — Lab 7"""
from marine_simulator.core.base_procedure import BaseProcedure
class FuelSepProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM", description_en="Acknowledge alarm — identify whether cause is bowl speed, temperature, or sludge level", description_ua="Підтвердити сигнал — визначити причину: оберти, температура або рівень шламу", points=10, time_budget_s=30.0),
        dict(step_id="IDENTIFY_FAULT", description_en="Read tachometer (normal >95% speed), fuel inlet temp (85–95°C), sludge tank level", description_ua="Зчитати тахометр (норма >95% об), температуру подачі (85–95°C), рівень шламу", points=15, time_budget_s=45.0),
        dict(step_id="SWITCH_STANDBY", description_en="Start standby separator and confirm clean fuel flow before stopping faulty unit", description_ua="Запустити резервний сепаратор та підтвердити подачу чистого палива перед зупинкою", points=15, time_budget_s=30.0),
        dict(step_id="RESTORE_HEATING", description_en="Restore fuel heating", description_ua="Відновити нагрів палива", points=10, time_budget_s=30.0),
        dict(step_id="DISCHARGE_SLUDGE", description_en="Initiate manual desludge cycle — confirm sludge pump running and discharge valve open", description_ua="Виконати ручний цикл видалення шламу — підтвердити роботу насоса та відкриття клапана", points=10, time_budget_s=30.0),
        dict(step_id="VERIFY_FUEL", description_en="Monitor clean fuel outlet: flow rate, temperature, and absence of water in sight glass", description_ua="Контролювати вихід чистого палива: витрата, температура, відсутність води у оглядовому склі", points=15, time_budget_s=120.0),
        dict(step_id="LOG_FAULT", description_en="Record in machinery log", description_ua="Записати в машинний журнал", points=10, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE", description_en="Notify bridge/CE", description_ua="Повідомити місток/ст.механіка", points=5, time_budget_s=60.0),
    ]
