"""modules/fuel_separator/fsep_module.py — Lab 7"""
from marine_simulator.core.base_module import BaseLabModule
from .fsep_physics import FuelSepPhysics
from .fsep_procedure import FuelSepProcedure
from .fsep_faults import FAULT_SCENARIOS, AssessmentRules

class FuelSeparatorModule(BaseLabModule):
    module_id: str = "fuel_separator"
    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics = FuelSepPhysics()
        self._procedure = FuelSepProcedure()
    def _get_fault_scenarios(self): return FAULT_SCENARIOS
    def _check_auto_advance(self): AssessmentRules.check_auto_advance(self._physics.s, self._procedure)
    # FIX #49 (Safety): Sludge tank overflow contaminates clean fuel → engine damage
    def _check_hard_fail(self):
        if self._physics.s.sludge_level_pct >= 99.5 and self._physics.s.running:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("SLUDGE_OVERFLOW_FUEL_CONTAMINATION")
    def switch_standby(self): self._physics.s.motor_fault = False; self._physics.s.bowl_speed_rpm = 7500.0; self._procedure.mark_done("SWITCH_STANDBY")
    def restore_heating(self): self._physics.s.heater_on = True; self._procedure.mark_done("RESTORE_HEATING")
    def discharge_sludge(self): self._physics.s.sludge_level_pct = 5.0; self._procedure.mark_done("DISCHARGE_SLUDGE")
