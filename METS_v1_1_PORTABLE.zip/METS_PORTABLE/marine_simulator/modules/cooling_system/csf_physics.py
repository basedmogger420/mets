"""Legacy API adapter for cooling-system physics.

`CSFPhysics` is the canonical implementation used by current modules.

This file provides a compatibility bridge (`CoolingPhysics`) so older
tests/integrations keep working with the pre-refactor API surface.
"""

from __future__ import annotations

from marine_simulator.modules.cooling_system.csf_module import (  # noqa: F401
    PumpStage as _CSFPumpStage,
    PumpState,
    CSFState,
    CSFPhysics,
)


class PumpStage:
    STOPPED  = _CSFPumpStage.STOPPED
    STARTING = _CSFPumpStage.STARTING
    RUNNING  = _CSFPumpStage.RUNNING
    FAULT    = _CSFPumpStage.TRIPPED
    TRIPPED  = _CSFPumpStage.TRIPPED


class CoolingPhysics(CSFPhysics):

    LOW_FLOW_RAISE_LS    = 0.5
    LOW_FLOW_CLEAR_LS    = 2.0
    HIGH_TEMP_C          = 85.0
    HIGH_TEMP_CLEAR_C    = 82.0
    DEAD_HEAD_TIMEOUT_S  = 30.0
    NPSH_MIN_BAR         = 0.5
    CAVITATION_DAMAGE_S  = 90.0

    def __init__(self):
        super().__init__()
        self._legacy_reset_state()

    def _legacy_reset_state(self):
        s = self.s
        s.sw_pump_p1.stage   = _CSFPumpStage.STOPPED
        s.sw_pump_p1.flow_ls = 0.0
        s.sw_pump_p2.stage   = _CSFPumpStage.STOPPED
        s.sw_pump_p2.flow_ls = 0.0
        s.engine_temp_c      = 72.0
        s.fw_temp_c          = 68.5
        self._sea_chest_open           = True
        self._sea_chest_blockage       = 0.0
        self._high_temp_latched        = False
        self._cavitation_damage_latched = False
        s.p1_fault_latched   = False
        s.low_flow_latched   = False
        s.sea_chest_blocked  = False
        for pump in (s.sw_pump_p1, s.sw_pump_p2):
            pump.dead_head_timer          = 0.0
            pump.seal_leak                = False
            pump.cavitating               = False
            pump.cavitation_timer         = 0.0
            pump._cavitation_alarm_latched = False

    def _pump(self, pump_id: str):
        return self.s.sw_pump_p1 if pump_id == "P1" else self.s.sw_pump_p2

    def start_pump(self, pump_id: str = "P1"):
        if not self._sea_chest_open:
            return "SEA_CHEST_VALVE_CLOSED"
        pump = self._pump(pump_id)
        if pump.stage != _CSFPumpStage.TRIPPED:
            pump.stage   = _CSFPumpStage.RUNNING
            pump.flow_ls = self.NOMINAL_SW_FLOW_LS
        return "OK"

    def stop_pump(self, pump_id: str = "P1"):
        pump = self._pump(pump_id)
        if pump.stage != _CSFPumpStage.TRIPPED:
            pump.stage   = _CSFPumpStage.STOPPED
            pump.flow_ls = 0.0

    def set_sea_chest_valve(self, is_open: bool):
        self._sea_chest_open = bool(is_open)
        self.s.sea_chest_blocked = (not self._sea_chest_open) or self._sea_chest_blockage > 0.0

    def inject_pump_failure(self, pump_id: str = "P1"):
        self.inject_pump_trip(pump_id)

    def inject_cooler_fouling(self, severity: float = 0.5):
        self.inject_hx_fouling(severity)
        self.s.cooler_dp_bar = max(0.05, 0.22 / max(0.1, self.s.hx_condition))

    def inject_sea_chest_blockage(self, blockage_ratio: float):
        self._sea_chest_blockage = max(0.0, min(1.0, blockage_ratio))
        self.s.sea_chest_blocked = self._sea_chest_blockage > 0.0 or (not self._sea_chest_open)

    def reset(self):
        super().reset()
        self._legacy_reset_state()

    def step(self, dt_s: float) -> list:
        # Legacy tests directly poke `engine_temp_c`; mirror that into FW temp
        # before canonical physics step so temperature alarms see expected value.
        if abs(self.s.engine_temp_c - (self.s.fw_temp_c + 3.5)) > 0.25:
            self.s.fw_temp_c = max(self.s.sw_temp_in_c + 2.0, self.s.engine_temp_c - 3.5)

        super().step(dt_s)

        s = self.s
        events = []

        sw_flow = sum(
            self.NOMINAL_SW_FLOW_LS
            for p in (s.sw_pump_p1, s.sw_pump_p2)
            if p.stage == _CSFPumpStage.RUNNING
        )

        blockage_factor = max(0.0, 1.0 - self._sea_chest_blockage)
        s.suction_pressure_bar = max(0.1, 1.8 * blockage_factor) if sw_flow > 0 else 0.0

        for pump_id in ("P1", "P2"):
            pump = self._pump(pump_id)

            if pump.stage == _CSFPumpStage.RUNNING and not self._sea_chest_open:
                pump.dead_head_timer += dt_s
                if pump.dead_head_timer >= self.DEAD_HEAD_TIMEOUT_S and not pump.seal_leak:
                    pump.seal_leak = True
                    pump.stage     = _CSFPumpStage.TRIPPED
                    pump.flow_ls   = 0.0
                    events.append((f"SW_PUMP_{pump_id}_DEAD_HEAD", 2))
            else:
                pump.dead_head_timer = 0.0

            cavitating = pump.stage == _CSFPumpStage.RUNNING and s.suction_pressure_bar < self.NPSH_MIN_BAR
            if cavitating:
                pump.cavitation_timer += dt_s
                pump.cavitating = True
                if not pump._cavitation_alarm_latched:
                    pump._cavitation_alarm_latched = True
                    events.append((f"SW_PUMP_{pump_id}_CAVITATION", 2))
                if pump.cavitation_timer >= self.CAVITATION_DAMAGE_S and not self._cavitation_damage_latched:
                    self._cavitation_damage_latched = True
                    pump.stage   = _CSFPumpStage.TRIPPED
                    pump.flow_ls = 0.0
                    events.append((f"SW_PUMP_{pump_id}_CAVITATION_DAMAGE", 2))
            else:
                pump.cavitation_timer         = 0.0
                pump.cavitating               = False
                pump._cavitation_alarm_latched = False

        if s.sw_pump_p1.stage == _CSFPumpStage.TRIPPED and not s.p1_fault_latched:
            s.p1_fault_latched = True
            events.append(("SW_PUMP_P1_FAULT", 2))
        elif s.sw_pump_p1.stage != _CSFPumpStage.TRIPPED and s.p1_fault_latched:
            s.p1_fault_latched = False
            events.append(("SW_PUMP_P1_FAULT", 0))

        if sw_flow < self.LOW_FLOW_RAISE_LS and not s.low_flow_latched:
            s.low_flow_latched = True
            events.append(("COOLING_LOW_FLOW", 2))
        elif sw_flow > self.LOW_FLOW_CLEAR_LS and s.low_flow_latched:
            s.low_flow_latched = False
            events.append(("COOLING_LOW_FLOW", 0))

        if s.engine_temp_c > self.HIGH_TEMP_C and not self._high_temp_latched:
            self._high_temp_latched = True
            events.append(("COOLING_HIGH_TEMP", 2))
        elif s.engine_temp_c < self.HIGH_TEMP_CLEAR_C and self._high_temp_latched:
            self._high_temp_latched = False
            events.append(("COOLING_HIGH_TEMP", 0))

        return events


__all__ = ["PumpStage", "PumpState", "CSFState", "CSFPhysics", "CoolingPhysics"]
