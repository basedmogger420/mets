"""modules/cooling_system/csf_module.py — Lab 10 Central Cooling System
FIXES: BUG-I (csf_sw_shortage CLEAN_HX removed — HX clean at inject),
       BUG-J (csf_pump_trip fw_temp_c override added),
       BUG-B3 (CLEAN_HX auto_advance scenario guard)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario
from marine_simulator.core.base_procedure import BaseProcedure


class PumpStage(Enum):
    STOPPED  = "stopped"
    STARTING = "starting"
    RUNNING  = "running"
    TRIPPED  = "tripped"


@dataclass
class PumpState:
    stage:       PumpStage = PumpStage.STOPPED
    flow_ls:     float     = 0.0
    fault:       bool      = False


@dataclass
class CSFState:
    sw_pump_p1: PumpState = field(default_factory=lambda: PumpState(PumpStage.RUNNING, 25.0))
    sw_pump_p2: PumpState = field(default_factory=PumpState)
    sw_temp_in_c:  float  = 22.0
    sw_temp_out_c: float  = 28.0
    fw_temp_c:     float  = 36.0   # nominal steady-state: engine_heat balanced by SW cooling
    fw_pressure_bar: float = 2.8
    hx_condition:  float  = 1.0
    # FIX UI-1: The following fields are required by app.js MODULE_CONFIG gauges
    # for Lab 10.  Without them every gauge rendered NaN/undefined in the UI.
    engine_temp_c:       float = 39.5   # nominal: fw_temp_c(36.0) + 3.5°C offset
    cooling_flow_ls:     float = 25.0   # total SW flow, mirrors sw_pump outputs
    sea_chest_dp_bar:    float = 0.15   # differential pressure across sea chest strainer
    cooler_dp_bar:       float = 0.22   # differential pressure across central cooler
    suction_pressure_bar: float = 1.8   # pump suction pressure
    cooler_ua_factor:    float = 1.0    # heat-transfer coefficient 0–1 (mirrors hx_condition)
    _low_sw_flow_latched:  bool = False
    _high_fw_temp_latched: bool = False  # correct: nominal fw_temp=36°C < alarm threshold=42°C
    _pump_trip_latched:    bool = False
    # FIX BUG-4: Field was missing from dataclass - added here instead of hasattr guard
    # which caused duplicate alarm after reset() (new CSFState() lost the attr → reset to False
    # each time, re-triggering the alarm even while fw_temp was still above threshold)
    _critical_temp_latched: bool = False


class CSFPhysics:
    NOMINAL_SW_FLOW_LS  = 25.0
    LOW_SW_FLOW_LS      = 8.0
    NOMINAL_FW_TEMP_C   = 36.0
    HIGH_FW_TEMP_C      = 42.0   # alarm at 42°C (was 45 — now realistic)
    SCRAM_FW_TEMP_C     = 58.0   # hard fail at 58°C
    TAU = 15.0

    def __init__(self):
        self.s = CSFState()

    def step(self, dt_s: float) -> list:
        s = self.s
        # SW pump flow
        sw_flow = 0.0
        for pump in (s.sw_pump_p1, s.sw_pump_p2):
            if pump.stage == PumpStage.RUNNING:
                sw_flow += self.NOMINAL_SW_FLOW_LS

        # FW temperature model:
        # Engine generates ~800 kW of waste heat → raises FW temp by ~8°C/min with no cooling
        # SW flow removes heat proportional to flow × HX efficiency
        hx_eff = s.hx_condition * min(1.0, sw_flow / max(1.0, self.NOMINAL_SW_FLOW_LS))

        # Engine heat input always raises FW temp (engine runs constantly)
        engine_heat_rate = 8.0   # °C/min equivalent ≈ 0.133 °C/s
        # Cooling removes heat proportional to HX effectiveness
        # Calibrated: at nominal (hx_eff=1.0, fw=36°C, sw_in=22°C) → 1.0*(36-22)*0.0095 = 0.133 ≈ engine heat
        # Fouled HX (0.4): 0.4*(47-22)*0.0095 = 0.095 < 0.133 → temp rises correctly
        cooling_rate = hx_eff * (s.fw_temp_c - s.sw_temp_in_c) * 0.0095  # °C/s

        # Net FW temperature change
        d_fw = (engine_heat_rate / 60.0 - cooling_rate) * dt_s
        s.fw_temp_c = max(s.sw_temp_in_c + 2.0, min(s.fw_temp_c + d_fw, 95.0))

        # SW temperature differential
        s.sw_temp_out_c = s.sw_temp_in_c + min(12.0, 8.0 / max(0.1, sw_flow / self.NOMINAL_SW_FLOW_LS))

        # engine_temp_c is FW supply temp + small offset
        s.engine_temp_c   = min(s.fw_temp_c + 3.5, 95.0)
        s.cooling_flow_ls = sw_flow
        s.cooler_ua_factor = s.hx_condition
        s.sea_chest_dp_bar = max(0.05, 0.15 * (sw_flow / max(1.0, self.NOMINAL_SW_FLOW_LS))
                                        / max(0.2, s.hx_condition))
        s.cooler_dp_bar = max(0.05, 0.22 / max(0.1, s.hx_condition))
        s.suction_pressure_bar = max(0.3, 1.8 * (sw_flow / max(1.0, self.NOMINAL_SW_FLOW_LS)))

        return self._eval_alarms()

    def _eval_alarms(self) -> list:
        s  = self.s
        ev = []
        sw_flow = sum(
            self.NOMINAL_SW_FLOW_LS
            for p in (s.sw_pump_p1, s.sw_pump_p2)
            if p.stage == PumpStage.RUNNING
        )

        if sw_flow < self.LOW_SW_FLOW_LS and not s._low_sw_flow_latched:
            s._low_sw_flow_latched = True
            ev.append(("CSF_LOW_SW_FLOW", 2))
        elif sw_flow >= self.LOW_SW_FLOW_LS + 5 and s._low_sw_flow_latched:
            s._low_sw_flow_latched = False
            ev.append(("CSF_LOW_SW_FLOW", 0))

        if s.fw_temp_c > self.HIGH_FW_TEMP_C and not s._high_fw_temp_latched:
            s._high_fw_temp_latched = True
            ev.append(("CSF_HIGH_FW_TEMP", 2))
        elif s.fw_temp_c < self.HIGH_FW_TEMP_C - 3 and s._high_fw_temp_latched:
            s._high_fw_temp_latched = False
            ev.append(("CSF_HIGH_FW_TEMP", 0))
        # FIX #38: Critical intermediate alarm at 50°C (gives student warning before SCRAM at 58°C)
        WARN_FW_TEMP_C = 50.0
        if s.fw_temp_c > WARN_FW_TEMP_C and not s._critical_temp_latched:
            s._critical_temp_latched = True
            ev.append(("CSF_CRITICAL_FW_TEMP", 3))
        elif s.fw_temp_c < WARN_FW_TEMP_C - 3 and s._critical_temp_latched:
            s._critical_temp_latched = False
            ev.append(("CSF_CRITICAL_FW_TEMP", 0))

        tripped = any(p.stage == PumpStage.TRIPPED for p in (s.sw_pump_p1, s.sw_pump_p2))
        if tripped and not s._pump_trip_latched:
            s._pump_trip_latched = True
            ev.append(("CSF_PUMP_TRIP", 2))
        elif not tripped and s._pump_trip_latched:
            s._pump_trip_latched = False
            ev.append(("CSF_PUMP_TRIP", 0))

        return ev

    def get_state(self) -> dict:
        s = self.s
        return {
            "p1_stage":            s.sw_pump_p1.stage.value,
            "p2_stage":            s.sw_pump_p2.stage.value,
            "sw_temp_in_c":        round(s.sw_temp_in_c, 1),
            "sw_temp_out_c":       round(s.sw_temp_out_c, 1),
            "fw_temp_c":           round(s.fw_temp_c, 1),
            "fw_pressure_bar":     round(s.fw_pressure_bar, 2),
            "hx_condition":        round(s.hx_condition, 2),
            # FIX UI-1: expose all keys expected by app.js MODULE_CONFIG gauges
            "engine_temp_c":       round(s.engine_temp_c, 1),
            "cooling_flow_ls":     round(s.cooling_flow_ls, 1),
            "sea_chest_dp_bar":    round(s.sea_chest_dp_bar, 3),
            "cooler_dp_bar":       round(s.cooler_dp_bar, 3),
            "suction_pressure_bar": round(s.suction_pressure_bar, 2),
            "cooler_ua_factor":    round(s.cooler_ua_factor, 2),
        }

    def inject_pump_trip(self, pump_id: str = "P1"):
        pump = self.s.sw_pump_p1 if pump_id == "P1" else self.s.sw_pump_p2
        pump.stage = PumpStage.TRIPPED
        pump.flow_ls = 0.0

    def inject_hx_fouling(self, severity: float = 0.5):
        self.s.hx_condition = max(0.2, 1.0 - severity)

    def inject_sw_shortage(self):
        self.s.sw_pump_p1.stage = PumpStage.STOPPED
        self.s.sw_pump_p1.flow_ls = 0.0

    def reset(self):
        self.s = CSFState()


class CSFProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM",      description_en="Acknowledge cooling system alarm",
             description_ua="Підтвердити сигнал охолодження", points=10, time_budget_s=30.0),
        dict(step_id="IDENTIFY_FAULT", description_en="Check SW flow, pump status, HX differentials",
             description_ua="Перевірити потік МВ, стан насосів, перепади на теплообмінниках", points=15, time_budget_s=45.0),
        dict(step_id="START_PUMP2",    description_en="Start standby SW pump P2",
             description_ua="Запустити резервний насос МВ P2", points=15, time_budget_s=20.0),
        dict(step_id="RESET_TRIP",     description_en="Reset tripped pump and investigate cause",
             description_ua="Скинути захист насоса та з'ясувати причину", points=10, time_budget_s=30.0),
        dict(step_id="CLEAN_HX",       description_en="Clean sea water strainer / heat exchanger",
             description_ua="Очистити морський фільтр / теплообмінник", points=10, time_budget_s=60.0),
        dict(step_id="VERIFY_TEMPS",   description_en="Confirm FW supply temp within 32–40°C",
             description_ua="Переконатися що температура ПВ у діапазоні 32–40°C", points=10, time_budget_s=90.0),
        dict(step_id="LOG_FAULT",      description_en="Record in machinery log",
             description_ua="Записати в журнал", points=5, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE",  description_en="Notify bridge/CE",
             description_ua="Повідомити місток/ст.мех.", points=5, time_budget_s=60.0),
    ]


FAULT_SCENARIOS: dict = {}

def _register():
    FAULT_SCENARIOS["csf_pump_trip"] = FaultScenario(
        scenario_id="csf_pump_trip",
        name_en="SW Pump Trip — Low Cooling Flow ★",
        name_ua="Зупинка насоса МВ — низький потік охолодження ★",
        description_en="Main SW pump trips on overload. FW temperature rises.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_PUMP2","RESET_TRIP","VERIFY_TEMPS","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_pump_trip("P1"),
        interrupt_overrides={"fw_temp_c": 46.0},  # FIX BUG-J: elevate temp so VERIFY_TEMPS doesn't auto-fire at inject
    )
    FAULT_SCENARIOS["csf_hx_fouling"] = FaultScenario(
        scenario_id="csf_hx_fouling",
        name_en="HX Fouling — High FW Temperature ★★",
        name_ua="Забруднення теплообмінника — висока температура ПВ ★★",
        description_en="Biofouling on SW side of central cooler. FW supply temp rises.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","CLEAN_HX","VERIFY_TEMPS","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_hx_fouling(0.6),
        interrupt_overrides={"hx_condition": 0.4, "fw_temp_c": 47.0},
    )
    FAULT_SCENARIOS["csf_sw_shortage"] = FaultScenario(
        scenario_id="csf_sw_shortage",
        name_en="SW Shortage — Pump Suction Loss ★★",
        name_ua="Нестача морської води — втрата всмоктування насоса ★★",
        description_en="Sea chest becomes partially blocked. P1 loses suction.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_PUMP2","VERIFY_TEMPS","LOG_FAULT","NOTIFY_BRIDGE"],  # FIX BUG-I: HX is clean in SW shortage; CLEAN_HX auto-fired for free
        _apply_fn=lambda p: p.inject_sw_shortage(),
        interrupt_overrides={"fw_temp_c": 46.0},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        # FIX-SCORE-2: VERIFY_TEMPS gates behind ACK — CSF starts at nominal condition.
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and 32.0 <= state.fw_temp_c <= 42.0:
            procedure.auto_mark_done("VERIFY_TEMPS")
        # FIX BUG-9: Irrelevant-step skips must gate behind ACK.
        # Without this, CLEAN_HX auto-completes in csf_sw_shortage (hx=1.0)
        # and RESET_TRIP in csf_hx_fouling (no tripped pump) before student acts.
        # FIX #19: RESET_TRIP is an active action — student must call reset_pump_trip()
        # Removed auto-complete to prevent it from being credited before student acts
        # FIX BUG-B3: Only auto-credit CLEAN_HX if this scenario includes that step
        # (csf_pump_trip and csf_sw_shortage don't need CLEAN_HX)
        has_clean_hx = any(s.step_id == "CLEAN_HX" for s in procedure._steps)
        if ack_done and has_clean_hx and state.hx_condition >= 0.8:
            procedure.auto_mark_done("CLEAN_HX")


class CoolingSystemModule(BaseLabModule):
    module_id: str = "cooling_system"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = CSFPhysics()
        self._procedure = CSFProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        if self._physics.s.fw_temp_c >= self._physics.SCRAM_FW_TEMP_C:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("CSF_OVERHEAT_SCRAM")

    def _apply_power_state(self, available: bool):
        if not available:
            for pump in (self._physics.s.sw_pump_p1, self._physics.s.sw_pump_p2):
                pump.stage = PumpStage.STOPPED
                pump.flow_ls = 0.0

    def start_pump(self, pump_id: str = "P1"):
        pump = self._physics.s.sw_pump_p1 if pump_id == "P1" else self._physics.s.sw_pump_p2
        pump.stage   = PumpStage.RUNNING
        pump.flow_ls = self._physics.NOMINAL_SW_FLOW_LS
        if pump_id == "P2":
            self._procedure.mark_done("START_PUMP2")

    def stop_pump(self, pump_id: str = "P1"):
        pump = self._physics.s.sw_pump_p1 if pump_id == "P1" else self._physics.s.sw_pump_p2
        pump.stage   = PumpStage.STOPPED
        pump.flow_ls = 0.0

    def reset_pump_trip(self, pump_id: str = "P1"):
        pump = self._physics.s.sw_pump_p1 if pump_id == "P1" else self._physics.s.sw_pump_p2
        if pump.stage == PumpStage.TRIPPED:
            pump.stage   = PumpStage.STOPPED
        self._procedure.mark_done("RESET_TRIP")

    def clean_hx(self):
        self._physics.s.hx_condition = 1.0
        self._procedure.mark_done("CLEAN_HX")
