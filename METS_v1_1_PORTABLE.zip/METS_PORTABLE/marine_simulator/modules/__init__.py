# marine_simulator/modules/__init__.py
