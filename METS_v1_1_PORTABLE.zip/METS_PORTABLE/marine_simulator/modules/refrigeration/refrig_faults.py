"""modules/refrigeration/refrig_faults.py — GOLD v1.0
FIX #29: refrig_compressor_trip — added INCREASE_COOLING to expected_steps
         and reduced fouling severity so VERIFY_PRESSURES is reachable.
"""
from marine_simulator.core.base_faults import FaultScenario

FAULT_SCENARIOS: dict[str, FaultScenario] = {}

def _register():
    FAULT_SCENARIOS["refrig_leak"] = FaultScenario(
        scenario_id="refrig_leak",
        name_en="Refrigerant Leak — Low Suction Pressure ★",
        name_ua="Витік холодоагенту — низький тиск всмоктування ★",
        description_en="Slow refrigerant leak. Suction pressure drops. Find and isolate leak.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","STOP_COMPRESSOR",
                        "ISOLATE_LEAK","VERIFY_PRESSURES","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_refrigerant_leak(35.0),
        interrupt_overrides={"refrigerant_charge_pct": 65.0},
    )
    # FIX REFRIG-1: severity 0.35 → condition=0.65 → target_pressure≈18.5 bar
    # discharge_temp rises slowly (~2°C/tick), giving students ~60 ticks before SCRAM
    FAULT_SCENARIOS["refrig_condenser_fouling"] = FaultScenario(
        scenario_id="refrig_condenser_fouling",
        name_en="Condenser Fouling — High Head Pressure ★★",
        name_ua="Забруднення конденсатора — високий тиск нагнітання ★★",
        description_en="Fouled condenser tubes. Head pressure rises above 18 bar alarm. Increase SW cooling flow before discharge temperature reaches SCRAM limit.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","INCREASE_COOLING",
                        "VERIFY_PRESSURES","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_condenser_fouling(0.35),
        interrupt_overrides={"condenser_pressure_bar": 18.5},
    )
    # FIX #29: compressor_trip uses severity 0.2 → condition=0.8 → target≈15 bar (completable)
    FAULT_SCENARIOS["refrig_compressor_trip"] = FaultScenario(
        scenario_id="refrig_compressor_trip",
        name_en="Compressor Trip — HP Cutout ★★",
        name_ua="Зупинка компресора — відсічка по ВТ ★★",
        description_en="Compressor trips on high pressure cutout. Investigate and restore cooling before cargo hold temps rise.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","CHECK_CONDENSER",
                        "INCREASE_COOLING","RESTART_COMPRESSOR",
                        "VERIFY_PRESSURES","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: (p.inject_condenser_fouling(0.2), p.inject_compressor_trip()),
        interrupt_overrides={"compressor_running": False},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if (ack_done and state.suction_pressure_bar > 2.0
                and state.condenser_pressure_bar < 16.0
                and state.compressor_running):
            procedure.auto_mark_done("VERIFY_PRESSURES")
