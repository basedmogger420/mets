"""modules/refrigeration/refrig_module.py — Lab 4 bridge module"""
from __future__ import annotations
from marine_simulator.core.base_module import BaseLabModule
from .refrig_physics import RefrigPhysics
from .refrig_procedure import RefrigProcedure
from .refrig_faults import FAULT_SCENARIOS, AssessmentRules


class RefrigerationModule(BaseLabModule):
    module_id: str = "refrigeration"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics = RefrigPhysics()
        self._procedure = RefrigProcedure()

    def _get_fault_scenarios(self): return FAULT_SCENARIOS
    def _check_auto_advance(self): AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        if self._physics.s.discharge_temp_c >= self._physics.SCRAM_DISCHARGE_C:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("COMPRESSOR_OVERHEAT_SCRAM")

    def start_compressor(self):
        self._physics.s.compressor_running = True
        self._procedure.mark_done("RESTART_COMPRESSOR")
    def stop_compressor(self):
        self._physics.s.compressor_running = False
        self._procedure.mark_done("STOP_COMPRESSOR")
    def increase_cooling(self):
        # FIX BUG-12: +0.2 from condition=0.5 gave 0.7 → target cond pressure=17.1
        # which never dropped below VERIFY_PRESSURES threshold of 16.0.
        # Real fix: opening extra SW valves restores capacity to at least 0.85
        # (represents full cooling water flow through remaining clean tubes).
        self._physics.s.condenser_condition = min(1.0, self._physics.s.condenser_condition + 0.35)
        self._procedure.mark_done("INCREASE_COOLING")
    def check_condenser(self):
        self._procedure.mark_done("CHECK_CONDENSER")
    def isolate_leak(self):
        # FIX #53a (Safety): Isolating a refrigerant leak section while compressor
        # is running creates high-pressure liquid hammer and frostbite risk.
        # STCW requires compressor shutdown before isolation valve operation.
        if self._physics.s.compressor_running:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("UNSAFE_ISOLATION_COMPRESSOR_RUNNING")
            return
        self._physics.s.refrigerant_leak = False   # FIX BUG-1: stop Bernoulli leak drain
        self._procedure.mark_done("ISOLATE_LEAK")
