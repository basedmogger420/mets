"""
modules/refrigeration/refrig_physics.py
Lab 4 — Refrigeration Plant (R22)

Physics: vapour-compression cycle with compressor, condenser, expansion valve,
evaporator.  Tracks suction/discharge pressures, superheat, cooling output.
v8: refrigerant leak now uses Bernoulli exponential decay (apply_gas_charge_bernoulli_leak)
    instead of the old one-shot subtraction, producing a realistic slow-then-fast depletion.
"""
from __future__ import annotations
from dataclasses import dataclass
from marine_simulator.core.fault_injection_engine import apply_gas_charge_bernoulli_leak


@dataclass
class RefrigState:
    compressor_running: bool = True
    evap_temp_c: float = -5.0
    condenser_pressure_bar: float = 12.0
    suction_pressure_bar: float = 2.8
    discharge_temp_c: float = 85.0
    cooling_kw: float = 45.0
    superheat_k: float = 8.0
    oil_pressure_bar: float = 3.5
    condenser_fouled: bool = False
    condenser_condition: float = 1.0
    refrigerant_charge_pct: float = 100.0
    refrigerant_leak: bool = False          # v8: continuous Bernoulli leak flag
    _high_discharge_latched: bool = False
    _low_suction_latched: bool = False
    _high_condenser_latched: bool = False
    _compressor_trip_latched: bool = False   # v7 FIX: was missing
    _low_charge_latched: bool = False          # v7.0 STABLE


class RefrigPhysics:
    NOMINAL_EVAP_C = -5.0
    NOMINAL_COND_BAR = 12.0
    NOMINAL_SUCTION_BAR = 2.8
    NOMINAL_COOLING_KW = 45.0
    HIGH_DISCHARGE_C = 120.0
    HIGH_COND_BAR = 18.0
    LOW_SUCTION_BAR = 1.5
    SCRAM_DISCHARGE_C = 140.0
    TAU = 20.0

    def __init__(self):
        self.s = RefrigState()

    def step(self, dt_s: float) -> list[tuple[str, int]]:
        if self.s.compressor_running:
            charge_factor = self.s.refrigerant_charge_pct / 100.0
            cond_factor = max(0.05, self.s.condenser_condition)  # guard: never zero
            # FIX #5: Explicit branch for zero charge — prevents evap artefact jump
            if charge_factor <= 0.0:
                t_evap, t_cond, t_suction = 20.0, 1.0, 0.0   # full refrigerant loss
                t_discharge, t_cool = 25.0, 0.0
            elif charge_factor > 0.3:
                t_evap      = self.NOMINAL_EVAP_C / charge_factor
                t_cond      = self.NOMINAL_COND_BAR / cond_factor
                t_suction   = self.NOMINAL_SUCTION_BAR * charge_factor
                t_discharge = 85.0 / cond_factor
                t_cool      = self.NOMINAL_COOLING_KW * charge_factor * cond_factor
            else:
                # Low charge (0 < charge <= 30%) — degraded but not zero
                t_evap      = 5.0
                t_cond      = self.NOMINAL_COND_BAR / cond_factor
                t_suction   = self.NOMINAL_SUCTION_BAR * charge_factor
                t_discharge = 85.0 / cond_factor
                t_cool      = self.NOMINAL_COOLING_KW * charge_factor * cond_factor
        else:
            t_evap, t_cond, t_suction = 5.0, 1.0, 1.0
            t_discharge, t_cool = 25.0, 0.0

        self.s.evap_temp_c += (t_evap - self.s.evap_temp_c) / self.TAU * dt_s
        self.s.condenser_pressure_bar += (t_cond - self.s.condenser_pressure_bar) / self.TAU * dt_s
        self.s.suction_pressure_bar += (t_suction - self.s.suction_pressure_bar) / self.TAU * dt_s
        self.s.discharge_temp_c += (t_discharge - self.s.discharge_temp_c) / self.TAU * dt_s
        self.s.cooling_kw += (t_cool - self.s.cooling_kw) / self.TAU * dt_s
        # Feature 1 — Safety clamping
        self.s.condenser_pressure_bar = max(0.0, min(self.s.condenser_pressure_bar, 30.0))
        self.s.suction_pressure_bar   = max(0.0, min(self.s.suction_pressure_bar, 10.0))
        self.s.discharge_temp_c       = max(-30.0, min(self.s.discharge_temp_c, 200.0))
        self.s.cooling_kw             = max(0.0, min(self.s.cooling_kw, self.NOMINAL_COOLING_KW * 1.1))
        self.s.refrigerant_charge_pct = max(0.0, min(self.s.refrigerant_charge_pct, 100.0))
        # v8: Bernoulli exponential refrigerant leak (replaces one-shot subtraction)
        if self.s.refrigerant_leak:
            self.s.refrigerant_charge_pct = apply_gas_charge_bernoulli_leak(
                self.s.refrigerant_charge_pct,
                max(0.1, self.s.suction_pressure_bar),
                dt_s,
                orifice_coeff=0.06,  # FIX: was 0.012 → alarm fires in ~5 min not 42 min
            )
        return self._eval_alarms()

    def _eval_alarms(self) -> list[tuple[str, int]]:
        ev = []
        if self.s.discharge_temp_c > self.HIGH_DISCHARGE_C and not self.s._high_discharge_latched:
            self.s._high_discharge_latched = True
            ev.append(("REFRIG_HIGH_DISCHARGE", 2))
        elif self.s.discharge_temp_c < self.HIGH_DISCHARGE_C - 10 and self.s._high_discharge_latched:
            self.s._high_discharge_latched = False
            ev.append(("REFRIG_HIGH_DISCHARGE", 0))

        if self.s.suction_pressure_bar < self.LOW_SUCTION_BAR and self.s.compressor_running and not self.s._low_suction_latched:
            self.s._low_suction_latched = True
            ev.append(("REFRIG_LOW_SUCTION", 2))
        elif self.s.suction_pressure_bar > self.LOW_SUCTION_BAR + 0.5 and self.s._low_suction_latched:
            self.s._low_suction_latched = False
            ev.append(("REFRIG_LOW_SUCTION", 0))

        if self.s.condenser_pressure_bar > self.HIGH_COND_BAR and not self.s._high_condenser_latched:
            self.s._high_condenser_latched = True
            ev.append(("REFRIG_HIGH_HEAD_PRESSURE", 2))
        elif self.s.condenser_pressure_bar < self.HIGH_COND_BAR - 2.0 and self.s._high_condenser_latched:
            self.s._high_condenser_latched = False
            ev.append(("REFRIG_HIGH_HEAD_PRESSURE", 0))

        # v7.0 STABLE: Low refrigerant charge alarm — fires immediately after leak injection
        LOW_CHARGE_PCT = 80.0
        if self.s.refrigerant_charge_pct < LOW_CHARGE_PCT and self.s.compressor_running and not self.s._low_charge_latched:
            self.s._low_charge_latched = True
            ev.append(("REFRIG_LOW_CHARGE", 2))
        elif self.s.refrigerant_charge_pct >= LOW_CHARGE_PCT + 5.0 and self.s._low_charge_latched:
            self.s._low_charge_latched = False
            ev.append(("REFRIG_LOW_CHARGE", 0))

        # Compressor trip alarm — v7 FIX: was missing; inject_compressor_trip()
        # stopped the compressor but fired no alarm so the scenario was invisible
        if not self.s.compressor_running and not self.s._compressor_trip_latched:
            self.s._compressor_trip_latched = True
            ev.append(("REFRIG_COMPRESSOR_TRIP", 3))
        elif self.s.compressor_running and self.s._compressor_trip_latched:
            self.s._compressor_trip_latched = False
            ev.append(("REFRIG_COMPRESSOR_TRIP", 0))

        return ev

    def get_state(self) -> dict:
        return {
            "compressor_running": self.s.compressor_running,
            "evap_temp_c": round(self.s.evap_temp_c, 1),
            "condenser_pressure_bar": round(self.s.condenser_pressure_bar, 2),
            "suction_pressure_bar": round(self.s.suction_pressure_bar, 2),
            "discharge_temp_c": round(self.s.discharge_temp_c, 1),
            "cooling_kw": round(self.s.cooling_kw, 1),
            "superheat_k": round(self.s.superheat_k, 1),
            "refrigerant_charge_pct": round(self.s.refrigerant_charge_pct, 1),
            "condenser_condition": round(self.s.condenser_condition, 2),
        }

    def inject_refrigerant_leak(self, loss_pct=30.0):
        """
        v8: Set the continuous Bernoulli leak flag.
        The initial 'loss_pct' argument is kept for API compatibility but
        is no longer applied as a one-shot subtraction — the exponential
        Bernoulli drain in step() handles the progressive charge loss.
        The interrupt_override in refrig_faults sets refrigerant_charge_pct
        immediately to the post-initial-loss value so the alarm fires on
        the very first tick.
        """
        self.s.refrigerant_leak = True

    def inject_condenser_fouling(self, severity=0.5):
        self.s.condenser_condition = max(0.4, 1.0 - severity)
        self.s.condenser_fouled = True

    def inject_compressor_trip(self):
        self.s.compressor_running = False

    def reset(self):
        self.s = RefrigState()
