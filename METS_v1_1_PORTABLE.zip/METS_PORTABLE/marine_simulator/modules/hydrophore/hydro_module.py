"""modules/hydrophore/hydro_module.py — Lab 5 Hydrophore System"""
from __future__ import annotations
from dataclasses import dataclass
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario, apply_fluid_pressure_bernoulli_leak


# ── Physics ──────────────────────────────────────────────────────────────────

@dataclass
class HydroState:
    tank_pressure_bar: float = 3.5
    tank_level_pct:    float = 60.0
    flow_ls:           float = 2.0
    air_charge_pct:    float = 35.0
    pump_running:      bool  = True
    demand_ls:         float = 2.0
    waterlogged:       bool  = False
    air_leak:          bool  = False
    _low_pressure_latched: bool = False
    _low_air_latched:      bool = False
    _pump_fault_latched:   bool = False


class HydroPhysics:
    NOMINAL_PRESSURE_BAR = 3.5
    LOW_PRESSURE_BAR     = 2.0
    HIGH_PRESSURE_BAR    = 5.0
    LOW_AIR_PCT          = 5.0
    TAU_P = 15.0
    TAU_L = 20.0

    def __init__(self):
        self.s = HydroState()

    def step(self, dt_s: float) -> list:
        s = self.s

        # Pump contribution
        pump_flow = 3.0 if s.pump_running else 0.0

        # Flow out
        s.flow_ls += (s.demand_ls - s.flow_ls) / self.TAU_L * dt_s
        s.flow_ls  = max(0.0, min(s.flow_ls, 8.0))

        # Pressure from air cushion + pump
        if s.waterlogged:
            air_cushion = 0.1   # almost no air — pressure wildly unstable
        else:
            air_cushion = s.air_charge_pct / 35.0

        net_flow = pump_flow - s.demand_ls
        # FIX BUG-5: Without a pump running, the air cushion alone cannot sustain
        # pressure against continuous demand. The original formula gave target_p ≈ 3.3
        # even with no pump, letting VERIFY_PRESSURE auto-complete before the student
        # started the standby pump. Now: pump contribution is required for pressure.
        if pump_flow > 0:
            target_p = self.NOMINAL_PRESSURE_BAR * air_cushion + net_flow * 0.1
        else:
            # No pump: pressure decays toward 0 as demand drains the tank
            target_p = max(0.0, s.tank_pressure_bar - s.demand_ls * 0.04 * dt_s)
        s.tank_pressure_bar += (target_p - s.tank_pressure_bar) / self.TAU_P * dt_s
        s.tank_pressure_bar  = max(0.0, min(s.tank_pressure_bar, self.HIGH_PRESSURE_BAR))

        # Level
        s.tank_level_pct += net_flow * 0.5 * dt_s
        s.tank_level_pct  = max(0.0, min(s.tank_level_pct, 100.0))

        # Air charge decay
        if s.air_leak:
            s.air_charge_pct = max(0.0, s.air_charge_pct - 0.3 * dt_s)

        if s.waterlogged:
            s.air_charge_pct = max(0.0, s.air_charge_pct - 0.1 * dt_s)

        s.air_charge_pct = max(0.0, min(s.air_charge_pct, 50.0))

        return self._eval_alarms()

    def _eval_alarms(self) -> list:
        s  = self.s
        ev = []
        if s.tank_pressure_bar < self.LOW_PRESSURE_BAR and not s._low_pressure_latched:
            s._low_pressure_latched = True
            ev.append(("HYDRO_LOW_PRESSURE", 2))
        elif s.tank_pressure_bar >= self.LOW_PRESSURE_BAR + 0.5 and s._low_pressure_latched:
            s._low_pressure_latched = False
            ev.append(("HYDRO_LOW_PRESSURE", 0))

        if s.air_charge_pct < self.LOW_AIR_PCT and not s._low_air_latched:
            s._low_air_latched = True
            ev.append(("HYDRO_LOW_AIR", 2))
        elif s.air_charge_pct >= self.LOW_AIR_PCT + 2 and s._low_air_latched:
            s._low_air_latched = False
            ev.append(("HYDRO_LOW_AIR", 0))

        if not s.pump_running and not s._pump_fault_latched:
            s._pump_fault_latched = True
            ev.append(("HYDRO_PUMP_FAULT", 2))
        elif s.pump_running and s._pump_fault_latched:
            s._pump_fault_latched = False
            ev.append(("HYDRO_PUMP_FAULT", 0))

        return ev

    def get_state(self) -> dict:
        s = self.s
        return {
            "tank_pressure_bar": round(s.tank_pressure_bar, 2),
            "tank_level_pct":    round(s.tank_level_pct, 1),
            "flow_ls":           round(s.flow_ls, 2),
            "air_charge_pct":    round(s.air_charge_pct, 1),
            "pump_running":      s.pump_running,
        }

    def inject_pump_failure(self):
        self.s.pump_running = False

    def inject_waterlogged(self):
        self.s.waterlogged    = True
        self.s.air_charge_pct = 2.0

    def inject_high_demand(self):
        self.s.demand_ls = 7.0

    def reset(self):
        self.s = HydroState()


# ── Procedure ─────────────────────────────────────────────────────────────────

from marine_simulator.core.base_procedure import BaseProcedure

class HydroProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM",      description_en="Acknowledge hydrophore alarm",
             description_ua="Підтвердити сигнал гідрофору", points=10, time_budget_s=30.0),
        dict(step_id="IDENTIFY_FAULT", description_en="Check pressure, level, pump status and air charge",
             description_ua="Перевірити тиск, рівень, насос та повітряний заряд", points=15, time_budget_s=45.0),
        dict(step_id="START_PUMP2",    description_en="Start standby pressure pump",
             description_ua="Запустити резервний насос тиску", points=15, time_budget_s=20.0),
        dict(step_id="RECHARGE_AIR",   description_en="Recharge air cushion via compressor",
             description_ua="Поповнити повітряну подушку через компресор", points=10, time_budget_s=60.0),
        dict(step_id="REDUCE_DEMAND",  description_en="Isolate non-essential consumers to reduce demand",
             description_ua="Ізолювати неосновних споживачів", points=10, time_budget_s=30.0),
        dict(step_id="VERIFY_PRESSURE",description_en="Confirm pressure stabilised 2.5–4.5 bar",
             description_ua="Переконатися у стабілізації тиску 2,5–4,5 бар", points=10, time_budget_s=90.0),
        dict(step_id="LOG_FAULT",      description_en="Record in machinery log",
             description_ua="Записати в машинний журнал", points=5, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE",  description_en="Notify bridge",
             description_ua="Повідомити місток", points=5, time_budget_s=60.0),
    ]


# ── Fault scenarios ───────────────────────────────────────────────────────────

FAULT_SCENARIOS: dict = {}

def _register():
    FAULT_SCENARIOS["hydro_pump_fail"] = FaultScenario(
        scenario_id="hydro_pump_fail",
        name_en="Pump Failure — Pressure Drop ★",
        name_ua="Відмова насоса — падіння тиску ★",
        description_en="Main pressure pump fails. Tank pressure drops.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_PUMP2","VERIFY_PRESSURE","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_pump_failure(),
        interrupt_overrides={"pump_running": False, "tank_pressure_bar": 1.5},
    )
    FAULT_SCENARIOS["hydro_waterlogged"] = FaultScenario(
        scenario_id="hydro_waterlogged",
        name_en="Waterlogged Tank — Air Cushion Lost ★★",
        name_ua="Заводнення танку — втрата повітряної подушки ★★",
        description_en="Air bladder ruptured. Tank fills with water. Pressure hunts wildly.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","RECHARGE_AIR","VERIFY_PRESSURE","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_waterlogged(),
        interrupt_overrides={"air_charge_pct": 2.0, "tank_pressure_bar": 1.8},
    )
    FAULT_SCENARIOS["hydro_high_demand"] = FaultScenario(
        scenario_id="hydro_high_demand",
        name_en="Excessive Demand — Crew Using All Showers ★★",
        name_ua="Надмірне споживання — екіпаж використовує всі душі ★★",
        description_en="Demand spikes above pump capacity. Pressure falls.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_PUMP2","REDUCE_DEMAND",
                        "VERIFY_PRESSURE","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_high_demand(),
        interrupt_overrides={"demand_ls": 7.0, "tank_pressure_bar": 1.6},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        # FIX-SCORE-2: VERIFY_PRESSURE auto-completes only after ACK (fault confirmed)
        # AND pressure has recovered — not on clean startup at nominal 3.5 bar.
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.tank_pressure_bar >= 2.5:
            procedure.auto_mark_done("VERIFY_PRESSURE")
        # FIX BUG-8: Irrelevant-scenario skips must also gate behind ACK.
        # Without this, START_PUMP2 auto-completes in hydro_high_demand
        # (pump_running=True) before the student even acknowledges the alarm.
        # FIX #21: START_PUMP2 is credited only via explicit start_pump(2) action
        # Removed auto-complete based on pump_running to avoid Pump1 being credited as Pump2
        if ack_done and state.air_charge_pct >= 25.0 and not state.waterlogged:
            procedure.auto_mark_done("RECHARGE_AIR")
        if ack_done and state.demand_ls <= 3.0:
            procedure.auto_mark_done("REDUCE_DEMAND")


# ── Module ────────────────────────────────────────────────────────────────────

class HydrophoreModule(BaseLabModule):
    module_id: str = "hydrophore"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = HydroPhysics()
        self._procedure = HydroProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _apply_power_state(self, available: bool):
        if not available:
            self._physics.s.pump_running = False

    def start_pump(self, pump_num: int = 1):
        self._physics.s.pump_running = True
        if pump_num == 2:
            self._procedure.mark_done("START_PUMP2")

    def stop_pump(self, pump_num: int = 1):
        self._physics.s.pump_running = False

    def recharge_air(self):
        # Recharging air cushion via compressor also fixes the waterlogged state:
        # the compressor forces air back into the bladder, displacing excess water.
        # Represents a full compressor recharge cycle → restores to nominal 35%.
        self._physics.s.waterlogged = False
        self._physics.s.air_charge_pct = 35.0
        self._procedure.mark_done("RECHARGE_AIR")

    def reduce_demand(self):
        self._physics.s.demand_ls = max(1.0, self._physics.s.demand_ls * 0.5)
        self._procedure.mark_done("REDUCE_DEMAND")
