"""modules/steering_gear/steer_module.py — GOLD v1.0
FIXES: #34 (steer_oil_leak missing NOTIFY_BRIDGE), #47 (add inject_oil_overtemp),
#52 (isolate_leak safe when oil_leak active regardless of pressure),
BUG-B (START_PUMP2 auto_advance now guards against non-applicable scenarios)
"""
from __future__ import annotations
from dataclasses import dataclass
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario, apply_fluid_pressure_bernoulli_leak
from marine_simulator.core.base_procedure import BaseProcedure


@dataclass
class SteerState:
    rudder_angle_deg:       float = 0.0
    ordered_angle_deg:      float = 0.0
    pump_running:           bool  = True
    pump2_running:          bool  = False
    hydraulic_pressure_bar: float = 180.0
    oil_level_pct:          float = 85.0
    oil_temp_c:             float = 38.0
    feedback_ok:            bool  = True
    oil_leak:               bool  = False
    subsystem_isolated:     bool  = False
    _low_pressure_latched:    bool = False
    _pump_fail_latched:       bool = False
    _feedback_fail_latched:   bool = False
    _high_oil_temp_latched:   bool = False


class SteerPhysics:
    NOMINAL_PRESSURE_BAR   = 180.0
    LOW_PRESSURE_BAR       = 80.0
    SCRAM_PRESSURE_BAR     = 30.0
    HIGH_OIL_TEMP_C        = 70.0
    MAX_OIL_TEMP_C         = 80.0
    RUDDER_RATE_1PUMP      = 2.32
    RUDDER_RATE_2PUMPS     = 4.64
    MAX_RUDDER_DEG         = 35.0
    TAU_P                  = 10.0

    def __init__(self):
        self.s = SteerState()

    def step(self, dt_s: float) -> list:
        s = self.s
        pumps_active = (1 if s.pump_running else 0) + (1 if s.pump2_running else 0)
        if pumps_active > 0 and s.hydraulic_pressure_bar > self.LOW_PRESSURE_BAR:
            rate = (self.RUDDER_RATE_2PUMPS if pumps_active >= 2 else self.RUDDER_RATE_1PUMP) * dt_s
            diff = s.ordered_angle_deg - s.rudder_angle_deg
            move = max(-rate, min(rate, diff))
            s.rudder_angle_deg += move
        s.rudder_angle_deg = max(-self.MAX_RUDDER_DEG, min(self.MAX_RUDDER_DEG, s.rudder_angle_deg))

        target_p = self.NOMINAL_PRESSURE_BAR if (s.pump_running or s.pump2_running) else 0.0
        if s.oil_leak and not s.subsystem_isolated:
            s.hydraulic_pressure_bar, s.oil_level_pct = apply_fluid_pressure_bernoulli_leak(
                s.hydraulic_pressure_bar, s.oil_level_pct, dt_s, orifice_coeff=0.02)
        elif s.subsystem_isolated:
            reduced_p = self.NOMINAL_PRESSURE_BAR * 0.6
            s.hydraulic_pressure_bar += (reduced_p - s.hydraulic_pressure_bar) / self.TAU_P * dt_s
        else:
            s.hydraulic_pressure_bar += (target_p - s.hydraulic_pressure_bar) / self.TAU_P * dt_s
        s.hydraulic_pressure_bar = max(0.0, min(s.hydraulic_pressure_bar, 250.0))
        s.oil_level_pct          = max(0.0, min(s.oil_level_pct, 100.0))

        if pumps_active > 0:
            s.oil_temp_c = min(s.oil_temp_c + 0.005 * dt_s * pumps_active, self.MAX_OIL_TEMP_C)
        else:
            s.oil_temp_c += (38.0 - s.oil_temp_c) * 0.001 * dt_s

        return self._eval_alarms()

    def _eval_alarms(self) -> list:
        s  = self.s
        ev = []
        if s.hydraulic_pressure_bar < self.LOW_PRESSURE_BAR and not s._low_pressure_latched:
            s._low_pressure_latched = True
            ev.append(("STEER_LOW_PRESSURE", 3))
        elif s.hydraulic_pressure_bar >= self.LOW_PRESSURE_BAR + 20 and s._low_pressure_latched:
            s._low_pressure_latched = False
            ev.append(("STEER_LOW_PRESSURE", 0))
        both_pumps_fail = not s.pump_running and not s.pump2_running
        if both_pumps_fail and not s._pump_fail_latched:
            s._pump_fail_latched = True
            ev.append(("STEER_PUMP_FAIL", 3))
        elif not both_pumps_fail and s._pump_fail_latched:
            s._pump_fail_latched = False
            ev.append(("STEER_PUMP_FAIL", 0))
        if not s.feedback_ok and not s._feedback_fail_latched:
            s._feedback_fail_latched = True
            ev.append(("STEER_FEEDBACK_FAIL", 2))
        elif s.feedback_ok and s._feedback_fail_latched:
            s._feedback_fail_latched = False
            ev.append(("STEER_FEEDBACK_FAIL", 0))
        if s.oil_temp_c >= self.HIGH_OIL_TEMP_C and not s._high_oil_temp_latched:
            s._high_oil_temp_latched = True
            ev.append(("STEER_HIGH_OIL_TEMP", 2))
        elif s.oil_temp_c < self.HIGH_OIL_TEMP_C - 5 and s._high_oil_temp_latched:
            s._high_oil_temp_latched = False
            ev.append(("STEER_HIGH_OIL_TEMP", 0))
        return ev

    def get_state(self) -> dict:
        s = self.s
        return {
            "rudder_angle_deg":       round(s.rudder_angle_deg, 1),
            "ordered_angle_deg":      round(s.ordered_angle_deg, 1),
            "hydraulic_pressure_bar": round(s.hydraulic_pressure_bar, 1),
            "oil_level_pct":          round(s.oil_level_pct, 1),
            "oil_temp_c":             round(s.oil_temp_c, 1),
            "pump_running":           s.pump_running,
            "pump2_running":          s.pump2_running,
            "feedback_ok":            s.feedback_ok,
            "subsystem_isolated":     s.subsystem_isolated,
        }

    def inject_pump_fail(self):       self.s.pump_running = False
    def inject_oil_leak(self):        self.s.oil_leak = True
    def inject_feedback_fail(self):   self.s.feedback_ok = False
    # FIX #47: Add injectable oil overtemp
    def inject_oil_overtemp(self):    self.s.oil_temp_c = 72.0
    def reset(self):                  self.s = SteerState()


class SteerProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM",       description_en="Acknowledge steering gear alarm",
             description_ua="Підтвердити сигнал рульового пристрою", points=10, time_budget_s=15.0),
        dict(step_id="NOTIFY_BRIDGE",   description_en="Immediately notify bridge — helm not responding",
             description_ua="Негайно повідомити місток", points=20, time_budget_s=10.0, critical=True),
        dict(step_id="IDENTIFY_FAULT",  description_en="Check pump status, hydraulic pressure, oil level and feedback",
             description_ua="Перевірити насос, тиск, рівень масла та зворотній зв'язок", points=15, time_budget_s=30.0),
        dict(step_id="START_PUMP2",     description_en="Start standby hydraulic pump unit",
             description_ua="Запустити резервний гідравлічний насос", points=15, time_budget_s=20.0),
        dict(step_id="ISOLATE_LEAK",    description_en="Isolate hydraulic leak — close isolating valves",
             description_ua="Ізолювати витік — закрити ізолюючі клапани", points=10, time_budget_s=30.0),
        dict(step_id="SWITCH_MANUAL",   description_en="Switch to manual steering on bridge if feedback failed",
             description_ua="Перейти на ручне управління, якщо відмова датчика", points=10, time_budget_s=20.0),
        dict(step_id="VERIFY_RUDDER",   description_en="Verify rudder responds to helm commands",
             description_ua="Переконатися що кермо реагує на команди", points=10, time_budget_s=30.0),
        dict(step_id="LOG_FAULT",       description_en="Record in machinery log",
             description_ua="Записати в журнал", points=5, time_budget_s=60.0),
    ]


FAULT_SCENARIOS: dict = {}

def _register():
    FAULT_SCENARIOS["steer_pump_fail"] = FaultScenario(
        scenario_id="steer_pump_fail",
        name_en="Steering Pump Failure — Loss of Rudder ★",
        name_ua="Відмова рульового насоса — втрата керма ★",
        description_en="Main steering pump fails. Pressure drops. Rudder jams.",
        difficulty=1,
        expected_steps=["ACK_ALARM","NOTIFY_BRIDGE","IDENTIFY_FAULT",
                        "START_PUMP2","VERIFY_RUDDER","LOG_FAULT"],
        _apply_fn=lambda p: p.inject_pump_fail(),
        interrupt_overrides={"pump_running": False, "hydraulic_pressure_bar": 20.0},
    )
    # FIX #34: Added NOTIFY_BRIDGE to steer_oil_leak expected_steps
    FAULT_SCENARIOS["steer_oil_leak"] = FaultScenario(
        scenario_id="steer_oil_leak",
        name_en="Hydraulic Oil Leak — Falling Pressure ★★",
        name_ua="Витік гідравлічного масла — падіння тиску ★★",
        description_en="Pipe joint failure. Oil leaks. Pressure and level fall gradually.",
        difficulty=2,
        expected_steps=["ACK_ALARM","NOTIFY_BRIDGE","IDENTIFY_FAULT",
                        "ISOLATE_LEAK","START_PUMP2","VERIFY_RUDDER","LOG_FAULT"],
        _apply_fn=lambda p: p.inject_oil_leak(),
        interrupt_overrides={"oil_leak": True, "hydraulic_pressure_bar": 65.0},
    )
    FAULT_SCENARIOS["steer_feedback_fail"] = FaultScenario(
        scenario_id="steer_feedback_fail",
        name_en="Rudder Feedback Failure — Blind Steering ★★",
        name_ua="Відмова датчика положення керма ★★",
        description_en="Feedback transducer fails. Bridge loses rudder position readout.",
        difficulty=2,
        expected_steps=["ACK_ALARM","NOTIFY_BRIDGE","IDENTIFY_FAULT",
                        "SWITCH_MANUAL","VERIFY_RUDDER","LOG_FAULT"],
        _apply_fn=lambda p: p.inject_feedback_fail(),
        interrupt_overrides={"feedback_ok": False},
    )
    # FIX #47: Add oil overtemp scenario
    FAULT_SCENARIOS["steer_oil_overtemp"] = FaultScenario(
        scenario_id="steer_oil_overtemp",
        name_en="Oil Cooler Failure — High Oil Temperature ★★",
        name_ua="Відмова охолодника масла — висока температура масла ★★",
        description_en="Oil cooler fails. Hydraulic oil temperature rises toward alarm.",
        difficulty=2,
        expected_steps=["ACK_ALARM","NOTIFY_BRIDGE","IDENTIFY_FAULT",
                        "VERIFY_RUDDER","LOG_FAULT"],
        _apply_fn=lambda p: p.inject_oil_overtemp(),
        interrupt_overrides={"oil_temp_c": 72.0},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        pumps_ok = state.pump_running or state.pump2_running
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.hydraulic_pressure_bar > 90.0 and pumps_ok:
            procedure.auto_mark_done("VERIFY_RUDDER")
        if ack_done and not state.oil_leak:
            procedure.auto_mark_done("ISOLATE_LEAK")
        if ack_done and state.feedback_ok:
            procedure.auto_mark_done("SWITCH_MANUAL")
        # FIX BUG-5: Was checking pump_running (pump 1) — should be pump2_running.
        # In steer_pump_fail pump1 is always False so this condition never fired.
        # FIX BUG-B: Guard against calling auto_mark_done for START_PUMP2 in scenarios
        # (e.g. steer_feedback_fail, steer_oil_overtemp) that don't include this step.
        has_start_pump2 = any(s.step_id == "START_PUMP2" for s in procedure._steps)
        if ack_done and has_start_pump2 and state.pump2_running and state.hydraulic_pressure_bar > 100.0:
            procedure.auto_mark_done("START_PUMP2")


class SteeringModule(BaseLabModule):
    module_id: str = "steering_gear"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = SteerPhysics()
        self._procedure = SteerProcedure()

    def _get_fault_scenarios(self):  return FAULT_SCENARIOS
    def _check_auto_advance(self):   AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _apply_power_state(self, available: bool):
        if not available:
            self._physics.s.pump_running = False

    def start_pump(self, pump_num: int = 1):
        if pump_num == 2:
            self._physics.s.pump2_running = True
            self._procedure.mark_done("START_PUMP2")
        else:
            self._physics.s.pump_running = True

    def stop_pump(self, pump_num: int = 1):
        if pump_num == 2:
            self._physics.s.pump2_running = False
        else:
            self._physics.s.pump_running = False

    def isolate_leak(self):
        # FIX #52: Safe to isolate when oil_leak is active (pressure FALLING)
        # Only block if no leak AND very high pressure (manual isolation risk)
        if (not self._physics.s.oil_leak
                and self._physics.s.pump_running
                and self._physics.s.hydraulic_pressure_bar > 100.0):
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("UNSAFE_ISOLATION_UNDER_PRESSURE")
            return
        self._physics.s.oil_leak = False
        self._physics.s.subsystem_isolated = True
        self._procedure.mark_done("ISOLATE_LEAK")

    def switch_manual(self):
        self._procedure.mark_done("SWITCH_MANUAL")

    def set_rudder_order(self, angle_deg: float):
        self._physics.s.ordered_angle_deg = max(-35.0, min(35.0, float(angle_deg)))

    def inform_bridge(self):
        self._procedure.mark_done("NOTIFY_BRIDGE")
