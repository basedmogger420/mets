"""modules/boiler/boiler_module.py — GOLD v1.0
FIXES: #4 (start_boiler dry drum guard), #44 (burner_locked_out respected)
"""
from __future__ import annotations
from marine_simulator.core.base_module import BaseLabModule
from .boiler_physics import BoilerPhysics
from .boiler_procedure import BoilerProcedure
from .boiler_faults import FAULT_SCENARIOS, AssessmentRules


class BoilerModule(BaseLabModule):
    module_id: str = "boiler"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = BoilerPhysics()
        self._procedure = BoilerProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        if self._physics.s.water_level_pct <= self._physics.SCRAM_WATER_PCT:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("BOILER_DANGEROUSLY_LOW_WATER")

    def _apply_power_state(self, available: bool):
        if not available:
            self._physics.s.running           = False
            self._physics.s.feed_pump_running = False
            self._physics.s.flame_on          = False

    # ── Operator actions ──────────────────────────────────────────────
    def start_boiler(self):
        # FIX #4: Hard fail if drum is dangerously dry
        if self._physics.s.water_level_pct <= self._physics.SCRAM_WATER_PCT:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("LETHAL_DRY_BOILER_START")
            return
        self._physics.s.running = True
        self._physics.s.fuel_valve_open = True
        # FIX #44: Don't override burner lockout — respect ESD
        if not self._physics.s.burner_locked_out:
            self._physics.s.flame_on = True

    def stop_boiler(self):
        self._physics.s.running = False
        self._physics.s.fuel_valve_open = False
        self._physics.s.flame_on = False

    def secure_fuel(self):
        self._physics.s.fuel_valve_open = False
        self._procedure.mark_done("SECURE_FUEL")

    def purge_furnace(self):
        self._physics.s.burner_locked_out = False
        self._procedure.mark_done("PURGE_FURNACE")

    def relight_burner(self):
        # FIX #48 (Safety): No relight with dry drum
        if self._physics.s.water_level_pct <= self._physics.SCRAM_WATER_PCT:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("LETHAL_DRY_BOILER_RELIGHT")
            return
        if not self._physics.s.burner_locked_out:
            self._physics.s.flame_on = True
            self._physics.s.fuel_valve_open = True
            self._procedure.mark_done("RELIGHT_BURNER")

    def start_standby_pump(self):
        self._physics.s.feed_pump_2_running = True
        self._procedure.mark_done("START_STANDBY_PUMP")

    def increase_firing(self):
        self._procedure.mark_done("INCREASE_FIRING")
