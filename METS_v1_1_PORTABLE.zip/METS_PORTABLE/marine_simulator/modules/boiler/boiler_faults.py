"""modules/boiler/boiler_faults.py — Lab 2 fault scenarios"""
from marine_simulator.core.base_faults import FaultScenario

FAULT_SCENARIOS: dict[str, FaultScenario] = {}

def _register():
    FAULT_SCENARIOS["boiler_flame_failure"] = FaultScenario(
        scenario_id="boiler_flame_failure",
        name_en="Flame Failure — Burner Trip ★",
        name_ua="Зрив полум'я — аварія пальника ★",
        description_en=(
            "Burner flame sensor detects loss of flame. Fuel valve closes, "
            "burner locks out. Steam pressure begins to fall. Operator must "
            "investigate cause, purge furnace, and re-light."
        ),
        difficulty=1,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "SECURE_FUEL",
                        "PURGE_FURNACE", "RELIGHT_BURNER", "VERIFY_STEAM",
                        "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_flame_failure(),
        # FIX PH-1: Previously interrupt_overrides was empty, so burner_locked_out
        # was only set True on the NEXT physics tick (by the step() lockout rule:
        # "no flame + fuel open + running → lock out").  A student who clicked
        # Re-light Burner in that one-tick window bypassed the purge procedure
        # entirely.  Setting both flags here makes the lockout atomic at
        # injection time, matching real boiler ESD interlock behaviour.
        interrupt_overrides={"flame_on": False, "burner_locked_out": True},
    )

    FAULT_SCENARIOS["boiler_feed_pump_failure"] = FaultScenario(
        scenario_id="boiler_feed_pump_failure",
        name_en="Feed Water Pump Trip — Falling Water Level ★★",
        name_ua="Зупинка живильного насоса — падіння рівня води ★★",
        description_en=(
            "Main feed pump trips. Water level drops. If level reaches 15%%, "
            "boiler must be emergency stopped. Start standby feed pump before "
            "water level reaches dangerous low."
        ),
        difficulty=2,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "START_STANDBY_PUMP",
                        "VERIFY_WATER_LEVEL", "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_feed_pump_trip(),
        # Immediate override so BOILER_FEED_PUMP_TRIP alarm fires on tick-0
        interrupt_overrides={"feed_pump_running": False},
    )

    FAULT_SCENARIOS["boiler_high_demand"] = FaultScenario(
        scenario_id="boiler_high_demand",
        name_en="Sudden Steam Demand Increase — Pressure Drop ★★",
        name_ua="Різке збільшення споживання пари — падіння тиску ★★",
        description_en=(
            "Cargo operations cause sudden high steam demand. Pressure drops "
            "rapidly. Burner goes to high fire but cannot keep up. Operator "
            "must manage load and potentially bring second boiler on line."
        ),
        difficulty=2,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "INCREASE_FIRING",
                        "VERIFY_STEAM", "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_high_demand(),
        # FIX-FI-2: Bypass the slow pressure accumulator. Drive steam_pressure
        # to just below the LOW_PRESSURE_BAR threshold (5.5 bar) immediately
        # so the alarm fires on the very next tick rather than after ~40 ticks.
        interrupt_overrides={"steam_pressure_bar": 5.0},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        # FIX-SCORE-2: VERIFY_* steps gate behind ACK to prevent startup auto-credit
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.steam_pressure_bar > 6.0 and state.flame_on:
            procedure.auto_mark_done("VERIFY_STEAM")
        # FIX BUG-11: accept either main OR standby feed pump running
        # In feed_pump_failure scenario, main pump is tripped and student
        # starts the standby — only feed_pump_2_running becomes True.
        any_feed_pump = state.feed_pump_running or state.feed_pump_2_running
        if ack_done and state.water_level_pct > 40.0 and any_feed_pump:
            procedure.auto_mark_done("VERIFY_WATER_LEVEL")
