"""modules/boiler/boiler_physics.py — GOLD v1.0
FIX #11: Safety valve hysteresis timer added.
"""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class BoilerState:
    running: bool = True
    steam_pressure_bar: float = 7.0
    water_level_pct: float = 60.0
    fuel_valve_open: bool = True
    flame_on: bool = True
    feed_pump_running: bool = True
    feed_pump_2_running: bool = False
    flue_temp_c: float = 280.0
    steam_demand_kg_s: float = 0.15
    safety_valve_lifted: bool = False
    burner_locked_out: bool = False
    _high_pressure_latched: bool = False
    _low_water_latched: bool = False
    _flame_fail_latched: bool = False
    _fuel_valve_stuck: bool = False
    _feed_pump_fault_latched: bool = False
    _low_pressure_latched: bool = False
    # FIX #11: Safety valve hysteresis timer
    _safety_valve_timer_s: float = 0.0


class BoilerPhysics:
    NOMINAL_PRESSURE_BAR = 7.0
    HIGH_PRESSURE_BAR = 8.0
    SAFETY_VALVE_BAR = 8.5
    LOW_WATER_PCT = 30.0
    VERY_LOW_WATER_PCT = 15.0
    TAU_PRESSURE = 25.0
    TAU_WATER = 40.0
    TAU_FLUE = 20.0
    SCRAM_WATER_PCT = 10.0

    def __init__(self):
        self.s = BoilerState()

    def step(self, dt_s: float) -> list[tuple[str, int]]:
        if self.s._fuel_valve_stuck and self.s.running and self.s.flame_on:
            target_p = self.SAFETY_VALVE_BAR + 1.5
        elif self.s.running and self.s.fuel_valve_open and self.s.flame_on and not self.s.burner_locked_out:
            target_p = self.NOMINAL_PRESSURE_BAR + self.s.steam_demand_kg_s * 3.0
        else:
            target_p = max(0.0, self.s.steam_pressure_bar - 0.05 * dt_s)
        self.s.steam_pressure_bar += (target_p - self.s.steam_pressure_bar) / self.TAU_PRESSURE * dt_s
        self.s.steam_pressure_bar -= self.s.steam_demand_kg_s * 0.05 * dt_s
        self.s.steam_pressure_bar = max(0.0, self.s.steam_pressure_bar)

        # FIX #11: Safety valve with confirmation timer (hysteresis)
        if self.s.steam_pressure_bar >= self.SAFETY_VALVE_BAR:
            self.s._safety_valve_timer_s = min(3.0, self.s._safety_valve_timer_s + dt_s)
            if self.s._safety_valve_timer_s >= 1.0:
                self.s.safety_valve_lifted = True
                self.s.steam_pressure_bar -= 0.5 * dt_s
        elif self.s.steam_pressure_bar < self.SAFETY_VALVE_BAR - 0.5:
            self.s._safety_valve_timer_s = 0.0
            self.s.safety_valve_lifted = False

        steam_consumption = 0.10 * dt_s if self.s.flame_on else 0.02 * dt_s
        feed_rate = 0.0
        if self.s.feed_pump_running:
            feed_rate += 0.10 * dt_s
        if self.s.feed_pump_2_running:
            feed_rate += 0.10 * dt_s
        self.s.water_level_pct += feed_rate - steam_consumption
        self.s.water_level_pct = max(0.0, min(100.0, self.s.water_level_pct))

        target_flue = 280.0 if self.s.flame_on and not self.s.burner_locked_out else 45.0
        self.s.flue_temp_c += (target_flue - self.s.flue_temp_c) / self.TAU_FLUE * dt_s

        if not self.s.flame_on and self.s.fuel_valve_open and self.s.running:
            self.s.burner_locked_out = True

        self.s.steam_pressure_bar  = max(0.0, min(self.s.steam_pressure_bar,  self.SAFETY_VALVE_BAR + 2.0))
        self.s.water_level_pct     = max(0.0, min(self.s.water_level_pct, 100.0))
        self.s.flue_temp_c         = max(0.0, min(self.s.flue_temp_c, 600.0))
        if self.s.water_level_pct <= 0.0:
            self.s.flame_on  = False
            self.s.steam_pressure_bar = max(0.0, self.s.steam_pressure_bar)

        return self._eval_alarms()

    def _eval_alarms(self) -> list[tuple[str, int]]:
        ev = []
        if self.s.steam_pressure_bar > self.HIGH_PRESSURE_BAR and not self.s._high_pressure_latched:
            self.s._high_pressure_latched = True
            ev.append(("BOILER_HIGH_PRESSURE", 2))
        elif self.s.steam_pressure_bar < self.HIGH_PRESSURE_BAR - 0.5 and self.s._high_pressure_latched:
            self.s._high_pressure_latched = False
            ev.append(("BOILER_HIGH_PRESSURE", 0))
        if self.s.water_level_pct < self.LOW_WATER_PCT and not self.s._low_water_latched:
            self.s._low_water_latched = True
            ev.append(("BOILER_LOW_WATER", 3))
        elif self.s.water_level_pct > self.LOW_WATER_PCT + 5.0 and self.s._low_water_latched:
            self.s._low_water_latched = False
            ev.append(("BOILER_LOW_WATER", 0))
        if not self.s.flame_on and self.s.running and not self.s._flame_fail_latched:
            self.s._flame_fail_latched = True
            ev.append(("BOILER_FLAME_FAILURE", 3))
        elif self.s.flame_on and self.s._flame_fail_latched:
            self.s._flame_fail_latched = False
            ev.append(("BOILER_FLAME_FAILURE", 0))
        if not self.s.feed_pump_running and self.s.running and not self.s._feed_pump_fault_latched:
            self.s._feed_pump_fault_latched = True
            ev.append(("BOILER_FEED_PUMP_TRIP", 2))
        elif self.s.feed_pump_running and self.s._feed_pump_fault_latched:
            self.s._feed_pump_fault_latched = False
            ev.append(("BOILER_FEED_PUMP_TRIP", 0))
        LOW_PRESSURE_BAR = 5.5
        if self.s.steam_pressure_bar < LOW_PRESSURE_BAR and self.s.running and not self.s._low_pressure_latched:
            self.s._low_pressure_latched = True
            ev.append(("BOILER_LOW_PRESSURE", 2))
        elif self.s.steam_pressure_bar >= LOW_PRESSURE_BAR + 0.5 and self.s._low_pressure_latched:
            self.s._low_pressure_latched = False
            ev.append(("BOILER_LOW_PRESSURE", 0))
        return ev

    def get_state(self) -> dict:
        return {
            "running": self.s.running,
            "steam_pressure_bar": round(self.s.steam_pressure_bar, 2),
            "water_level_pct": round(self.s.water_level_pct, 1),
            "fuel_valve_open": self.s.fuel_valve_open,
            "flame_on": self.s.flame_on,
            "feed_pump_running": self.s.feed_pump_running,
            # FIX BUG-6: feed_pump_2_running was missing from get_state() so the UI
            # could not show standby pump status in the feed_pump_failure scenario.
            "feed_pump_2_running": self.s.feed_pump_2_running,
            "flue_temp_c": round(self.s.flue_temp_c, 1),
            "safety_valve_lifted": self.s.safety_valve_lifted,
            "burner_locked_out": self.s.burner_locked_out,
        }

    def inject_flame_failure(self):
        self.s.flame_on = False

    def inject_feed_pump_trip(self):
        self.s.feed_pump_running = False

    def inject_high_demand(self):
        self.s.steam_demand_kg_s = 0.4

    def inject_fuel_valve_stuck(self):
        self.s.fuel_valve_open = True
        self.s._fuel_valve_stuck = True
        self.s.steam_demand_kg_s = 0.0

    def reset(self):
        self.s = BoilerState()
