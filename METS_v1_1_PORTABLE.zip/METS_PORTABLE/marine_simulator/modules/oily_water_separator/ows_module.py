"""modules/oily_water_separator/ows_module.py — GOLD v1.0
FIXES: #7 (Hard Fail stops separator), #28 (MARPOL hard fail at PPM > 15 with valve overboard)
"""
from __future__ import annotations
from marine_simulator.core.base_module import BaseLabModule
from .ows_physics import OWSPhysics
from .ows_procedure import OWSProcedure
from .ows_faults import FAULT_SCENARIOS, AssessmentRules


class OWSModule(BaseLabModule):
    module_id: str = "oily_water_separator"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics = OWSPhysics()
        self._procedure = OWSProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        # FIX #28: MARPOL violation — illegal discharge at any PPM > 15 with valve overboard
        if (self._physics.s.three_way_valve_overboard and
                self._physics.s.oil_content_ppm > self._physics.PPM_OVERBOARD_LIMIT and
                self._scenario_injected):
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail(
                    f"MARPOL_ILLEGAL_DISCHARGE_{self._physics.s.oil_content_ppm:.1f}_PPM"
                )
        elif self._physics.s.oil_content_ppm >= self._physics.SCRAM_PPM:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("ILLEGAL_DISCHARGE_HIGH_PPM")

    def start_separator(self):
        self._physics.s.running = True
        self._physics.s.separator_running = True
        self._procedure.mark_done("RESTART_SYSTEM")

    def stop_separator(self):
        self._physics.s.running = False
        self._physics.s.separator_running = False

    def switch_recirculate(self):
        self._physics.s.three_way_valve_overboard = False
        self._procedure.mark_done("SWITCH_RECIRC")
        self._procedure.mark_done("STOP_DISCHARGE")

    def switch_overboard(self):
        if self._physics.s.oil_content_ppm > self._physics.PPM_OVERBOARD_LIMIT:
            # FIX #7: Stop separator + hard fail on illegal discharge attempt
            self._physics.s.running = False
            self._physics.s.separator_running = False
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail(
                    f"ILLEGAL_DISCHARGE_ATTEMPTED_AT_"
                    f"{self._physics.s.oil_content_ppm:.1f}_PPM"
                )
            return
        self._physics.s.three_way_valve_overboard = True

    def restore_heater(self):
        self._physics.s.heater_on = True
        self._procedure.mark_done("RESTORE_HEATING")

    def clean_separator(self):
        self._physics.s.disc_stack_condition = 1.0
        self._physics.s.separator_running = False
        self._procedure.mark_done("CLEAN_SEPARATOR")
