from .ows_module import OWSModule
__all__ = ["OWSModule"]
