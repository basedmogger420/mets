"""modules/oily_water_separator/ows_faults.py — GOLD v1.0
FIX #27: expected_steps synchronized with lab01_ows.json step IDs.
FIX #28: MARPOL hard fail support in _check_hard_fail.
"""
from marine_simulator.core.base_faults import FaultScenario

FAULT_SCENARIOS: dict[str, FaultScenario] = {}

def _register():
    FAULT_SCENARIOS["ows_heater_failure"] = FaultScenario(
        scenario_id="ows_heater_failure",
        name_en="Heater Failure — Cold Fuel, Rising PPM ★",
        name_ua="Відмова нагрівача — холодне паливо, зростання PPM ★",
        description_en=(
            "Heater element fails. PPM rises above 15. "
            "Operator must identify heater fault and switch to standby heater."
        ),
        difficulty=1,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "STOP_DISCHARGE",
                        "RESTORE_HEATING", "VERIFY_PPM", "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_heater_failure(),
        interrupt_overrides={"oil_content_ppm": 18.0},
    )
    FAULT_SCENARIOS["ows_monitor_failure"] = FaultScenario(
        scenario_id="ows_monitor_failure",
        name_en="Oil Content Monitor Failure — False Clean Reading ★★",
        name_ua="Відмова монітора нафтовмісту — хибний чистий показник ★★",
        description_en=(
            "The 15 PPM oil content monitor fails. Three-way valve stays in overboard "
            "position despite actual PPM rising. Risk of illegal discharge."
        ),
        difficulty=2,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "STOP_DISCHARGE",
                        "SWITCH_RECIRC", "VERIFY_PPM", "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: (p.inject_monitor_failure(), p.inject_disc_blockage(0.4)),
        # FIX #28: valve stays overboard — hard fail fires immediately at PPM > 15
        interrupt_overrides={"three_way_valve_overboard": True},
    )
    FAULT_SCENARIOS["ows_disc_blockage"] = FaultScenario(
        scenario_id="ows_disc_blockage",
        name_en="Separator Disc Stack Blockage — Reduced Separation ★★",
        name_ua="Засмічення пакету дисків сепаратора ★★",
        description_en=(
            "Heavy sludge blocks disc stack. Flow drops and PPM rises. "
            "Operator must stop, clean discs, and restart."
        ),
        difficulty=2,
        expected_steps=["ACK_ALARM", "IDENTIFY_FAULT", "STOP_DISCHARGE",
                        "CLEAN_SEPARATOR", "RESTART_SYSTEM", "VERIFY_PPM",
                        "LOG_FAULT", "NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_disc_blockage(0.7),
        interrupt_overrides={"oil_content_ppm": 20.0},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.oil_content_ppm < 12.0 and state.separator_running:
            procedure.auto_mark_done("VERIFY_PPM")
        if ack_done and not state.three_way_valve_overboard:
            procedure.auto_mark_done("STOP_DISCHARGE")
