"""
modules/oily_water_separator/ows_physics.py
Lab 1 — Oily Water Separator (Hamworthy MK2)

Physics: gravity-disc separation with heater pre-treatment.
Tracks oil content (PPM), flow rate, heater temp, separator plate condition.
"""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class OWSState:
    running: bool = True
    separator_running: bool = True
    oil_content_ppm: float = 5.0
    flow_ls: float = 2.5
    heater_temp_c: float = 55.0
    heater_on: bool = True
    oil_tank_level_pct: float = 25.0
    bilge_pump_running: bool = True
    three_way_valve_overboard: bool = True
    monitor_functioning: bool = True
    disc_stack_condition: float = 1.0   # 1.0=clean, 0.3=blocked
    bowl_speed_pct: float = 100.0       # Feature 2: virtual RPM % (0-100); purification only at >=95%
    _high_ppm_latched: bool = False
    _low_flow_latched: bool = False
    _heater_fault_latched: bool = False
    _monitor_fault_latched: bool = False   # v7 FIX: was missing


class OWSPhysics:
    NOMINAL_FLOW_LS = 2.5
    PPM_LIMIT = 15.0
    PPM_OVERBOARD_LIMIT = 15.0
    HEATER_TARGET_C = 55.0
    TAU_PPM = 20.0
    TAU_FLOW = 5.0
    TAU_HEATER = 60.0
    SCRAM_PPM = 50.0

    def __init__(self):
        self.s = OWSState()

    def step(self, dt_s: float) -> list[tuple[str, int]]:
        # Flow depends on bilge pump, disc stack, and separator state
        if self.s.running and self.s.bilge_pump_running:
            target_flow = self.NOMINAL_FLOW_LS * self.s.disc_stack_condition
        else:
            target_flow = 0.0
        self.s.flow_ls += (target_flow - self.s.flow_ls) / self.TAU_FLOW * dt_s

        # Heater
        if self.s.heater_on and self.s.running:
            target_temp = self.HEATER_TARGET_C
        else:
            target_temp = 22.0
        self.s.heater_temp_c += (target_temp - self.s.heater_temp_c) / self.TAU_HEATER * dt_s

        # Feature 2 — RPM spin-up: separator needs to reach 95% bowl speed before purifying.
        # This prevents 'instant purification' on startup (realistic Alfa-Laval behaviour).
        TARGET_BOWL_PCT = 100.0 if (self.s.separator_running and self.s.bilge_pump_running) else 0.0
        TAU_BOWL = 30.0  # ~30 s to reach full speed
        self.s.bowl_speed_pct += (TARGET_BOWL_PCT - self.s.bowl_speed_pct) / TAU_BOWL * dt_s
        self.s.bowl_speed_pct = max(0.0, min(100.0, self.s.bowl_speed_pct))
        at_speed = self.s.bowl_speed_pct >= 95.0

        # Oil content: depends on separator state, heater, disc stack, AND bowl speed
        if self.s.separator_running and at_speed and self.s.heater_temp_c > 45.0:
            base_ppm = 5.0 / max(0.05, self.s.disc_stack_condition)  # FIX BUG-7: guard div-by-zero
        elif self.s.separator_running and at_speed:
            base_ppm = 18.0  # cold fuel, poor separation
        elif self.s.separator_running and not at_speed:
            base_ppm = 35.0  # spinning up — no effective separation yet
        else:
            base_ppm = 60.0  # no separation at all
        if not self.s.monitor_functioning:
            base_ppm = self.s.oil_content_ppm  # monitor frozen, no feedback
        self.s.oil_content_ppm += (base_ppm - self.s.oil_content_ppm) / self.TAU_PPM * dt_s

        # Three-way valve auto-recirculates above 15 PPM (if monitor works)
        if self.s.monitor_functioning and self.s.oil_content_ppm > self.PPM_OVERBOARD_LIMIT:
            self.s.three_way_valve_overboard = False
        elif self.s.monitor_functioning and self.s.oil_content_ppm < self.PPM_OVERBOARD_LIMIT - 3.0:
            self.s.three_way_valve_overboard = True

        # Tank fill
        if self.s.separator_running and self.s.running:
            self.s.oil_tank_level_pct = min(100.0, self.s.oil_tank_level_pct + 0.01 * dt_s)

        # Feature 1 — Safety clamping
        self.s.oil_content_ppm      = max(0.0, min(self.s.oil_content_ppm, 200.0))
        self.s.flow_ls              = max(0.0, min(self.s.flow_ls, self.NOMINAL_FLOW_LS * 2.0))
        self.s.heater_temp_c        = max(0.0, min(self.s.heater_temp_c, 90.0))
        self.s.oil_tank_level_pct   = max(0.0, min(self.s.oil_tank_level_pct, 100.0))
        return self._eval_alarms()

    def _eval_alarms(self) -> list[tuple[str, int]]:
        ev = []

        # High PPM
        if self.s.oil_content_ppm > self.PPM_LIMIT and not self.s._high_ppm_latched:
            self.s._high_ppm_latched = True
            ev.append(("OWS_HIGH_PPM", 2))
        elif self.s.oil_content_ppm < self.PPM_LIMIT - 3.0 and self.s._high_ppm_latched:
            self.s._high_ppm_latched = False
            ev.append(("OWS_HIGH_PPM", 0))

        # Low flow
        if self.s.flow_ls < 0.5 and self.s.running and not self.s._low_flow_latched:
            self.s._low_flow_latched = True
            ev.append(("OWS_LOW_FLOW", 2))
        elif self.s.flow_ls > 1.0 and self.s._low_flow_latched:
            self.s._low_flow_latched = False
            ev.append(("OWS_LOW_FLOW", 0))

        # Heater fault
        if not self.s.heater_on and self.s.running and not self.s._heater_fault_latched:
            self.s._heater_fault_latched = True
            ev.append(("OWS_HEATER_FAULT", 2))
        elif self.s.heater_on and self.s._heater_fault_latched:
            self.s._heater_fault_latched = False
            ev.append(("OWS_HEATER_FAULT", 0))

        # Monitor fault — v7 FIX: was missing; without this alarm the scenario
        # had no visible effect on the bridge and the procedure never started
        if not self.s.monitor_functioning and self.s.running and not self.s._monitor_fault_latched:
            self.s._monitor_fault_latched = True
            ev.append(("OWS_MONITOR_FAULT", 2))
        elif self.s.monitor_functioning and self.s._monitor_fault_latched:
            self.s._monitor_fault_latched = False
            ev.append(("OWS_MONITOR_FAULT", 0))

        return ev

    def get_state(self) -> dict:
        return {
            "running":              self.s.running,
            "separator_running":    self.s.separator_running,
            "oil_content_ppm":      round(self.s.oil_content_ppm, 1),
            "flow_ls":              round(self.s.flow_ls, 2),
            "heater_temp_c":        round(self.s.heater_temp_c, 1),
            "heater_on":            self.s.heater_on,
            "oil_tank_level_pct":   round(self.s.oil_tank_level_pct, 1),
            "bilge_pump_running":   self.s.bilge_pump_running,
            "three_way_valve_overboard": self.s.three_way_valve_overboard,
            "monitor_functioning":  self.s.monitor_functioning,
            "disc_stack_condition": round(self.s.disc_stack_condition, 2),
            "bowl_speed_pct": round(self.s.bowl_speed_pct, 1),
        }

    # ── Fault injection ───────────────────────────────────────────────
    def inject_heater_failure(self):
        self.s.heater_on = False

    def inject_monitor_failure(self):
        self.s.monitor_functioning = False

    def inject_disc_blockage(self, severity: float = 0.6):
        self.s.disc_stack_condition = max(0.2, 1.0 - severity)

    def inject_bilge_pump_trip(self):
        self.s.bilge_pump_running = False

    def reset(self):
        self.s = OWSState()
