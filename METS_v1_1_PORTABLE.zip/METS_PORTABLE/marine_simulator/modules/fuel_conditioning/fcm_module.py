"""modules/fuel_conditioning/fcm_module.py — GOLD v1.0
FIX #30: Added _check_hard_fail for SCRAM_VISC and fuel starvation.
FIX BUG-B2: START_PUMP2 auto_advance guards against non-applicable scenarios.
"""
from __future__ import annotations
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario
from marine_simulator.core.base_procedure import BaseProcedure
from .fcm_physics import FCMPhysics


class FCMProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM",        description_en="Acknowledge FCM alarm",
             description_ua="Підтвердити сигнал FCM", points=10, time_budget_s=30.0),
        dict(step_id="IDENTIFY_FAULT",   description_en="Check fuel temp, viscosity, pump status and viscometer",
             description_ua="Перевірити температуру, в'язкість, насос та в'язкомір", points=15, time_budget_s=45.0),
        dict(step_id="RESTORE_HEATING",  description_en="Restore or switch to standby heater",
             description_ua="Відновити або перемкнути на резервний нагрівач", points=10, time_budget_s=30.0),
        dict(step_id="START_PUMP2",      description_en="Start standby circulation pump",
             description_ua="Запустити резервний циркуляційний насос", points=15, time_budget_s=20.0),
        dict(step_id="BYPASS_VISCOMETER",description_en="Switch to manual temperature control if viscometer failed",
             description_ua="Перейти на ручний контроль температури при відмові в'язкоміра", points=10, time_budget_s=30.0),
        dict(step_id="VERIFY_VISCOSITY", description_en="Confirm viscosity within 10–15 cSt range",
             description_ua="Переконатися що в'язкість у діапазоні 10–15 сСт", points=15, time_budget_s=90.0),
        dict(step_id="LOG_FAULT",        description_en="Record in machinery log",
             description_ua="Записати в журнал", points=5, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE",    description_en="Notify bridge/CE",
             description_ua="Повідомити місток/ст.мех.", points=5, time_budget_s=60.0),
    ]


FAULT_SCENARIOS: dict = {}

def _register():
    FAULT_SCENARIOS["fcm_heater"] = FaultScenario(
        scenario_id="fcm_heater",
        name_en="Fuel Heater Failure — High Viscosity ★",
        name_ua="Відмова нагрівача — висока в'язкість ★",
        description_en="Steam heater fails. Fuel temp drops. Viscosity exceeds limit.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","RESTORE_HEATING",
                        "VERIFY_VISCOSITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_heater_failure(),
        interrupt_overrides={"heater_on": False, "fuel_temp_c": 95.0, "viscosity_cst": 28.0},
    )
    FAULT_SCENARIOS["fcm_pump"] = FaultScenario(
        scenario_id="fcm_pump",
        name_en="Circulation Pump Failure — No Flow ★★",
        name_ua="Відмова циркуляційного насоса — відсутність потоку ★★",
        description_en="Circulation pump trips. Fuel flow to ME stops. Risk of starvation.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_PUMP2",
                        "VERIFY_VISCOSITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_pump_failure(),
        interrupt_overrides={"supply_pump_running": False, "pressure_bar": 2.5, "lp_pressure_bar": 1.5},
    )
    FAULT_SCENARIOS["fcm_viscometer"] = FaultScenario(
        scenario_id="fcm_viscometer",
        name_en="Viscometer Fault — False Reading ★★",
        name_ua="Відмова в'язкоміра — хибні показання ★★",
        description_en="Viscometer fails. Risk of high viscosity ME fuel supply.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","BYPASS_VISCOMETER",
                        "VERIFY_VISCOSITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_viscometer_fault(),
        interrupt_overrides={"viscometer_ok": False, "viscosity_cst": 22.0},  # FIX BUG-K: push visc out of range so VERIFY_VISCOSITY doesn't auto-fire before student acts
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        # FIX BUG-K: VERIFY_VISCOSITY must not auto-fire immediately at inject.
        # In fcm_viscometer, viscosity starts at nominal (11.8 cSt) so it would fire right away.
        # Gate: the prerequisite step must be done first (BYPASS_VISCOMETER or RESTORE_HEATING).
        bypass_done  = any(s.step_id == "BYPASS_VISCOMETER" and s.done for s in procedure._steps)
        heating_done = any(s.step_id == "RESTORE_HEATING"   and s.done for s in procedure._steps)
        has_bypass   = any(s.step_id == "BYPASS_VISCOMETER"  for s in procedure._steps)
        has_heating  = any(s.step_id == "RESTORE_HEATING"    for s in procedure._steps)
        prereq_done  = (bypass_done if has_bypass else True) and (heating_done if has_heating else True)
        # Also gate START_PUMP2: if it's in steps, it must be done too
        pump2_done   = any(s.step_id == "START_PUMP2" and s.done for s in procedure._steps)
        has_pump2    = any(s.step_id == "START_PUMP2"  for s in procedure._steps)
        pump_prereq  = pump2_done if has_pump2 else True
        if ack_done and prereq_done and pump_prereq and 10.0 <= state.viscosity_cst <= 15.0:
            procedure.auto_mark_done("VERIFY_VISCOSITY")
        if ack_done and state.heater_on:
            procedure.auto_mark_done("RESTORE_HEATING")
        # FIX BUG-B2: Only auto-credit START_PUMP2 if this scenario includes that step
        # (fcm_heater and fcm_viscometer don't have START_PUMP2 in expected_steps)
        has_start_pump2 = any(s.step_id == "START_PUMP2" for s in procedure._steps)
        if ack_done and has_start_pump2 and state.supply_pump_running:
            procedure.auto_mark_done("START_PUMP2")
        if ack_done and state.viscometer_ok:
            procedure.auto_mark_done("BYPASS_VISCOMETER")


class FCMModule(BaseLabModule):
    module_id: str = "fuel_conditioning"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = FCMPhysics()
        self._procedure = FCMProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        # FIX #30: Critical viscosity → main engine seizure
        s = self._physics.s
        if s.viscosity_cst >= self._physics.SCRAM_VISC_CST:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail(
                    f"ME_FUEL_STARVATION_VISC_{s.viscosity_cst:.0f}CST"
                )
        # Zero pressure with no standby pump → fuel starvation
        if s.pressure_bar < 1.0 and s.running and not s.standby_pump_running:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("ME_FUEL_STARVATION_NO_FLOW")

    def _apply_power_state(self, available: bool):
        if not available:
            self._physics.s.running              = False
            self._physics.s.supply_pump_running  = False

    def restore_heating(self):
        self._physics.s.heater_on = True
        self._procedure.mark_done("RESTORE_HEATING")

    def start_pump(self):
        self._physics.s.supply_pump_running = True
        self._procedure.mark_done("START_PUMP2")

    def bypass_viscometer(self):
        # FIX BUG-2: Bypassing the viscometer means switching to manual temperature
        # control — the faulty sensor is no longer in the loop.  Set viscometer_ok=True
        # so that (a) the FCM_VISCOMETER_FAULT alarm clears, and (b) the auto-advance
        # rule for VERIFY_VISCOSITY can fire once viscosity returns to the normal band.
        # Without this the fcm_viscometer scenario was permanently blocked.
        self._physics.s.viscometer_ok = True
        self._procedure.mark_done("BYPASS_VISCOMETER")
