"""modules/fuel_conditioning/fcm_physics.py
Real parameters from Alfa Laval FCM One official brochure (MDD00057RU):
  - Low-pressure circuit: 4 bar (supply pumps)
  - High-pressure circuit: 6-16 bar nominal (typ. 8 bar before engine)
  - Controller EPC 60 maintains viscosity to engine manufacturer spec
  - Auto-standby pump start on supply pump failure
  - Auto-switch to diesel oil on heater failure
  - Viscosity target: 8-15 cSt (HFO for medium-speed diesel)

FIX LOG:
  FIX V-1: Removed upper viscosity clamp that prevented HIGH_VISC alarm
  FIX V-2: Smooth 80 deg C transition via blend zone (was 200 cSt jump)
  FIX V-3: Standby pump startup delay 3 s (was instant)
  FIX V-4: math.exp smooth_step -- no overshoot at large dt
  FIX V-5: Alarm confirmation timer 3 s -- no false triggers on transients
  FIX V-6: Diesel auto-switch delayed 4 s after confirmed alarm (EPC 60 hysteresis)
  FIX V-7: Pressure-viscosity coupling -- high viscosity reduces HP pressure
"""
from __future__ import annotations
import math
from dataclasses import dataclass


def _smooth_step(current: float, target: float, dt_s: float, tau: float) -> float:
    """FIX V-4: exponential smoothing, dt-independent, never overshoots."""
    if tau <= 0.0:
        return target
    alpha = 1.0 - math.exp(-dt_s / tau)
    return current + (target - current) * alpha


@dataclass
class FCMState:
    running:              bool  = True
    fuel_temp_c:          float = 130.0
    viscosity_cst:        float = 11.8
    lp_pressure_bar:      float = 4.0
    pressure_bar:         float = 8.0
    heater_on:            bool  = True
    supply_pump_running:  bool  = True
    standby_pump_running: bool  = False
    booster_pump_running: bool  = True
    viscometer_ok:        bool  = True
    on_diesel:            bool  = False
    auto_switched_diesel: bool  = False
    _high_visc_latched:        bool  = False
    _low_pressure_latched:     bool  = False
    _viscometer_fault_latched: bool  = False
    _heater_fail_latched:      bool  = False
    _standby_delay_s:          float = 0.0   # FIX V-3
    _high_visc_timer_s:        float = 0.0   # FIX V-5
    _diesel_delay_s:           float = 0.0   # FIX V-6


class FCMPhysics:
    TARGET_TEMP_HFO_C    = 130.0
    TARGET_TEMP_DO_C     = 40.0
    TARGET_VISC_CST      = 11.8
    TARGET_VISC_DO_CST   = 3.5
    LP_NOMINAL_BAR       = 4.0
    HP_NOMINAL_BAR       = 8.0
    HIGH_VISC_CST        = 20.0
    LOW_PRESSURE_BAR     = 3.0
    LOW_HP_PRESSURE_BAR  = 4.0
    SCRAM_VISC_CST       = 50.0
    TAU_TEMP             = 40.0
    TAU_VISC             = 30.0
    TAU_P                = 5.0
    STANDBY_PUMP_DELAY_S  = 3.0    # FIX V-3
    ALARM_CONFIRM_S       = 3.0    # FIX V-5
    DIESEL_SWITCH_DELAY_S = 4.0    # FIX V-6
    VISC_PRESSURE_FACTOR_MAX = 3.0 # FIX V-7

    def __init__(self):
        self.s = FCMState()

    def step(self, dt_s: float) -> list[tuple[str, int]]:
        s = self.s

        # FIX V-3: standby pump starts after 3 s confirmation delay
        if not s.supply_pump_running and not s.standby_pump_running:
            s._standby_delay_s += dt_s
            if s._standby_delay_s >= self.STANDBY_PUMP_DELAY_S:
                s.standby_pump_running = True
        else:
            s._standby_delay_s = 0.0

        active_pump = s.supply_pump_running or s.standby_pump_running

        # TEMPERATURE
        if s.on_diesel:
            target_temp = self.TARGET_TEMP_DO_C
        elif s.heater_on:
            target_temp = self.TARGET_TEMP_HFO_C
        else:
            target_temp = 25.0

        s.fuel_temp_c = _smooth_step(s.fuel_temp_c, target_temp, dt_s, self.TAU_TEMP)
        s.fuel_temp_c = max(0.0, min(s.fuel_temp_c, 200.0))

        # VISCOSITY
        # Walther equation calibrated to Alfa Laval HFO data:
        #   130 deg C -> 12 cSt, 100 deg C -> 32 cSt, 80 deg C -> 80 cSt  (<2% error)
        # FIX V-1: no upper clamp -> alarm at 20 cSt now reachable
        # FIX V-2: blend zone 75-95 deg C eliminates 200 cSt hard jump at 80 deg C
        if s.on_diesel:
            target_visc = self.TARGET_VISC_DO_CST
        else:
            t = max(30.0, s.fuel_temp_c)
            visc_formula = 29_407_209.0 / max(0.5, (t - 20.0) ** 3.13)
            if s.running and s.heater_on:
                blend = max(0.0, min(1.0, (s.fuel_temp_c - 75.0) / 20.0))
                target_visc = blend * self.TARGET_VISC_CST + (1.0 - blend) * visc_formula
                target_visc = max(8.0, target_visc)
            else:
                target_visc = min(800.0, visc_formula)

        s.viscosity_cst = _smooth_step(s.viscosity_cst, target_visc, dt_s, self.TAU_VISC)
        s.viscosity_cst = max(2.0, min(s.viscosity_cst, 1000.0))

        # PRESSURES with viscosity coupling (FIX V-7)
        # High viscosity -> higher hydraulic resistance -> lower pressure
        visc_factor = min(self.VISC_PRESSURE_FACTOR_MAX,
                          s.viscosity_cst / self.TARGET_VISC_CST)

        lp_nominal = self.LP_NOMINAL_BAR if active_pump else 0.0
        lp_target  = lp_nominal / max(1.0, visc_factor * 0.4)
        s.lp_pressure_bar = _smooth_step(s.lp_pressure_bar, lp_target, dt_s, self.TAU_P)

        if s.booster_pump_running and active_pump:
            hp_target = (s.lp_pressure_bar + 4.0) / visc_factor
        else:
            hp_target = s.lp_pressure_bar
        s.pressure_bar = _smooth_step(s.pressure_bar, hp_target, dt_s, self.TAU_P)

        s.lp_pressure_bar = max(0.0, min(s.lp_pressure_bar, 8.0))
        s.pressure_bar    = max(0.0, min(s.pressure_bar, 20.0))

        # AUTO-SWITCH TO DIESEL (FIX V-6: wait for confirmed alarm + 4 s delay)
        if (not s.heater_on
                and not s.on_diesel
                and s._high_visc_timer_s >= self.ALARM_CONFIRM_S):
            s._diesel_delay_s += dt_s
            if s._diesel_delay_s >= self.DIESEL_SWITCH_DELAY_S:
                s.on_diesel = True
                s.auto_switched_diesel = True
        elif s.on_diesel or s.heater_on:
            s._diesel_delay_s = 0.0

        return self._eval_alarms(dt_s)

    def _eval_alarms(self, dt_s: float) -> list[tuple[str, int]]:
        s  = self.s
        ev = []

        # FIX V-5: HIGH_VISC needs 3 s sustained exceedance before firing
        if s.viscosity_cst > self.HIGH_VISC_CST and s.running:
            s._high_visc_timer_s += dt_s
        else:
            s._high_visc_timer_s = max(0.0, s._high_visc_timer_s - dt_s)

        if (s._high_visc_timer_s >= self.ALARM_CONFIRM_S
                and s.running and not s._high_visc_latched):
            s._high_visc_latched = True
            ev.append(("FCM_HIGH_VISCOSITY", 2))
        elif s.viscosity_cst < self.HIGH_VISC_CST - 3.0 and s._high_visc_latched:
            s._high_visc_latched = False
            s._high_visc_timer_s = 0.0
            ev.append(("FCM_HIGH_VISCOSITY", 0))

        if s.pressure_bar < self.LOW_HP_PRESSURE_BAR and s.running and not s._low_pressure_latched:
            s._low_pressure_latched = True
            ev.append(("FCM_LOW_PRESSURE", 2))
        elif s.pressure_bar > self.LOW_HP_PRESSURE_BAR + 1.5 and s._low_pressure_latched:
            s._low_pressure_latched = False
            ev.append(("FCM_LOW_PRESSURE", 0))

        if not s.viscometer_ok and not s._viscometer_fault_latched:
            s._viscometer_fault_latched = True
            ev.append(("FCM_VISCOMETER_FAULT", 2))
        elif s.viscometer_ok and s._viscometer_fault_latched:
            s._viscometer_fault_latched = False
            ev.append(("FCM_VISCOMETER_FAULT", 0))

        if s.auto_switched_diesel and not s._heater_fail_latched:
            s._heater_fail_latched = True
            ev.append(("FCM_AUTO_DIESEL_SWITCH", 1))

        return ev

    def get_state(self) -> dict:
        # FIX BUG-4: derive flow_ls from pressure for UI gauge compatibility
        active_pump = self.s.supply_pump_running or self.s.standby_pump_running
        flow_ls = 1.5 * (self.s.pressure_bar / self.HP_NOMINAL_BAR) if active_pump else 0.0
        return {
            "running":              self.s.running,
            "fuel_temp_c":          round(self.s.fuel_temp_c, 1),
            "viscosity_cst":        round(self.s.viscosity_cst, 1),
            "lp_pressure_bar":      round(self.s.lp_pressure_bar, 2),
            "pressure_bar":         round(self.s.pressure_bar, 2),
            "flow_ls":              round(flow_ls, 2),
            "heater_on":            self.s.heater_on,
            "supply_pump_running":  self.s.supply_pump_running,
            "standby_pump_running": self.s.standby_pump_running,
            "on_diesel":            self.s.on_diesel,
            "auto_switched_diesel": self.s.auto_switched_diesel,
            "viscometer_ok":        self.s.viscometer_ok,
        }

    def inject_heater_failure(self):
        self.s.heater_on = False

    def inject_pump_failure(self):
        self.s.supply_pump_running = False

    def inject_viscometer_fault(self):
        self.s.viscometer_ok = False

    def reset(self):
        self.s = FCMState()
