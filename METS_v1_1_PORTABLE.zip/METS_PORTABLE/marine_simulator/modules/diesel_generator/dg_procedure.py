"""modules/diesel_generator/dg_procedure.py — Lab 6 training steps"""
from marine_simulator.core.base_procedure import BaseProcedure
class DGProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM", description_en="Press ACK on MSB alarm panel — note time and blackout status",
             description_ua="Натиснути ACK на панелі ГРЩ — зафіксувати час та стан блекауту", points=10, time_budget_s=15.0),
        dict(step_id="IDENTIFY_FAULT", description_en="Read MSB mimic panel: identify which DG tripped, check fault indicator lights",
             description_ua="Зчитати мімічну панель ГРЩ: визначити який ДГ зупинився та причину", points=10, time_budget_s=30.0),
        dict(step_id="START_DG2", description_en="Emergency-start DG2: turn key, press START, confirm speed rising on tachometer",
             description_ua="Аварійний запуск ДГ2", points=15, time_budget_s=20.0, critical=True),
        dict(step_id="SYNC_DG2", description_en="Match DG2 frequency to bus using governor — synchronise with synchroscope before closing CB",
             description_ua="Синхронізувати ДГ2 за допомогою синхроноскопа", points=15, time_budget_s=45.0),
        dict(step_id="CLOSE_CB2", description_en="Close DG2 main circuit breaker — confirm ammeter shows load transfer to DG2",
             description_ua="Замкнути автоматичний вимикач ДГ2 на шини", points=10, time_budget_s=15.0, critical=True),
        dict(step_id="TRANSFER_LOAD", description_en="Transfer load from DG1 to DG2 using load sharing",
             description_ua="Перевести навантаження з ДГ1 на ДГ2", points=10, time_budget_s=30.0),
        dict(step_id="OPEN_CB1", description_en="Open DG1 breaker and shut down faulty DG",
             description_ua="Вимкнути автомат ДГ1 та зупинити несправний ДГ", points=5, time_budget_s=20.0),
        dict(step_id="RESTORE_LOAD", description_en="Re-energise essential consumers in priority order: steering, fire pump, navigation lights",
             description_ua="Відновити основні споживачі після блекауту", points=10, time_budget_s=60.0, critical=True),
        dict(step_id="VERIFY_FREQUENCY", description_en="Confirm frequency and voltage stable",
             description_ua="Підтвердити стабільність частоти та напруги", points=5, time_budget_s=120.0),
        dict(step_id="LOG_FAULT", description_en="Record in machinery log",
             description_ua="Записати в машинний журнал", points=5, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE", description_en="Notify bridge — power status report",
             description_ua="Повідомити місток — звіт про стан живлення", points=5, time_budget_s=60.0),
    ]
