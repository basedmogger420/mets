"""modules/diesel_generator/dg_module.py — Lab 6 Diesel Generator
FIXES: BUG-H (dg_governor_fault missing START_DG2 in expected_steps)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario
from .dg_procedure import DGProcedure


# ── Physics ──────────────────────────────────────────────────────────────────

@dataclass
class GeneratorState:
    running:    bool  = False
    speed_rpm:  float = 0.0
    cb_closed:  bool  = False
    load_kw:    float = 0.0
    fault:      bool  = False
    # FIX PH-4: governor_fault moved onto the per-generator state so a fault
    # on DG1 doesn't penalise DG2 frequency when DG2 takes over the bus.
    governor_fault: bool = False


@dataclass
class DGState:
    dg1: GeneratorState = field(default_factory=lambda: GeneratorState(
        running=True, speed_rpm=750.0, cb_closed=True, load_kw=180.0
    ))
    dg2: GeneratorState = field(default_factory=GeneratorState)
    frequency_hz:   float = 50.0
    voltage_v:      float = 400.0
    load_kw:        float = 180.0
    bus_live:       bool  = True
    blackout:       bool  = False
    # FIX PH-4: removed global governor_fault — now lives on each GeneratorState
    _blackout_latched:  bool = False
    _overload_latched:  bool = False
    _gov_fault_latched: bool = False


class DGPhysics:
    NOMINAL_HZ   = 50.0
    NOMINAL_V    = 400.0
    NOMINAL_RPM  = 750.0
    OVERLOAD_KW  = 500.0
    TAU          = 8.0
    # Minimum RPM fraction before CB can be closed (prevents zero-RPM sync)
    MIN_SYNC_RPM_FRACTION = 0.92   # 92 % of nominal = ~690 RPM

    def __init__(self):
        self.s = DGState()

    def step(self, dt_s: float) -> list:
        s = self.s
        # FIX #51 (Safety): Reverse power / motoring protection.
        # If a generator is on the bus (cb_closed) but has stalled (RPM < 100),
        # the live bus backfeeds into it as a motor → winding damage, fire.
        # Real protection relay trips the breaker automatically.
        for g in (s.dg1, s.dg2):
            if g.cb_closed and g.speed_rpm < 100.0 and not g.running:
                g.cb_closed = False
                g.load_kw = 0.0

        gens_on = []
        if s.dg1.running and s.dg1.cb_closed:
            gens_on.append(s.dg1)
        if s.dg2.running and s.dg2.cb_closed:
            gens_on.append(s.dg2)

        if gens_on:
            s.bus_live = True
            s.blackout = False
            # FIX PH-4: governor penalty only from generators that are actually
            # on the bus — a tripped DG1 with governor_fault no longer drags
            # down DG2's frequency when DG2 is carrying the bus alone.
            gov_penalty = 3.0 if any(g.governor_fault for g in gens_on) else 0.0
            target_hz = self.NOMINAL_HZ - gov_penalty
            target_v  = self.NOMINAL_V
            per_gen_kw = s.load_kw / max(1, len(gens_on))
            for g in gens_on:
                g.load_kw += (per_gen_kw - g.load_kw) / self.TAU * dt_s
        else:
            s.bus_live = False
            s.blackout = True
            target_hz  = 0.0
            target_v   = 0.0

        s.frequency_hz += (target_hz - s.frequency_hz) / self.TAU * dt_s
        s.voltage_v    += (target_v  - s.voltage_v)    / self.TAU * dt_s
        s.frequency_hz  = max(0.0, min(s.frequency_hz, 55.0))
        s.voltage_v     = max(0.0, min(s.voltage_v,    450.0))

        for g, tgt in ((s.dg1, self.NOMINAL_RPM if s.dg1.running else 0.0),
                        (s.dg2, self.NOMINAL_RPM if s.dg2.running else 0.0)):
            g.speed_rpm += (tgt - g.speed_rpm) / self.TAU * dt_s
            g.speed_rpm  = max(0.0, min(g.speed_rpm, self.NOMINAL_RPM * 1.1))

        return self._eval_alarms()

    def _eval_alarms(self) -> list:
        s  = self.s
        ev = []
        if s.blackout and not s._blackout_latched:
            s._blackout_latched = True
            ev.append(("DG_BLACKOUT", 3))
        elif not s.blackout and s._blackout_latched:
            s._blackout_latched = False
            ev.append(("DG_BLACKOUT", 0))

        if s.load_kw > self.OVERLOAD_KW and not s._overload_latched:
            s._overload_latched = True
            ev.append(("DG_OVERLOAD", 2))
        elif s.load_kw <= self.OVERLOAD_KW and s._overload_latched:
            s._overload_latched = False
            ev.append(("DG_OVERLOAD", 0))

        # FIX PH-4: check per-generator governor_fault flag (was global)
        any_gov = s.dg1.governor_fault or s.dg2.governor_fault
        if any_gov and not s._gov_fault_latched:
            s._gov_fault_latched = True
            ev.append(("DG_GOVERNOR_FAULT", 2))
        elif not any_gov and s._gov_fault_latched:
            s._gov_fault_latched = False
            ev.append(("DG_GOVERNOR_FAULT", 0))

        return ev

    def get_state(self) -> dict:
        s = self.s
        return {
            "dg1_running":       s.dg1.running,
            "dg1_rpm":           round(s.dg1.speed_rpm, 0),
            "dg1_load_kw":       round(s.dg1.load_kw, 1),
            "dg1_governor_fault": s.dg1.governor_fault,
            "dg2_running":       s.dg2.running,
            "dg2_rpm":           round(s.dg2.speed_rpm, 0),
            "dg2_load_kw":       round(s.dg2.load_kw, 1),
            "frequency_hz":      round(s.frequency_hz, 2),
            "voltage_v":         round(s.voltage_v, 1),
            "load_kw":           round(s.load_kw, 1),
            "bus_live":          s.bus_live,
            "blackout":          s.blackout,
            # Expose sync readiness so UI can show a "ready to sync" indicator
            "dg2_sync_ready":    (
                s.dg2.speed_rpm >= self.NOMINAL_RPM * self.MIN_SYNC_RPM_FRACTION
            ),
        }

    def inject_blackout(self):
        self.s.dg1.running   = False
        self.s.dg1.cb_closed = False
        self.s.dg1.fault     = True

    def inject_governor_fault(self):
        # FIX PH-4: set fault only on DG1, not the global flag
        self.s.dg1.governor_fault = True

    def inject_overload(self):
        self.s.load_kw = 560.0

    def reset(self):
        self.s = DGState()


# ── Fault scenarios ───────────────────────────────────────────────────────────

FAULT_SCENARIOS: dict = {}

def _register_faults():
    FAULT_SCENARIOS["dg_blackout"] = FaultScenario(
        scenario_id="dg_blackout",
        name_en="Total Blackout — DG1 Trip ★",
        name_ua="Повне знеструмлення — зупинка ДГ1 ★",
        description_en="DG1 trips on overcurrent. Bus goes dead. Emergency start DG2.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_DG2","SYNC_DG2",
                        "CLOSE_CB2","TRANSFER_LOAD","OPEN_CB1","RESTORE_LOAD",
                        "VERIFY_FREQUENCY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_blackout(),
        interrupt_overrides={"blackout": True, "bus_live": False, "voltage_v": 0.0},
    )
    FAULT_SCENARIOS["dg_governor_fault"] = FaultScenario(
        scenario_id="dg_governor_fault",
        name_en="DG1 Governor Fault — Frequency Instability ★★",
        name_ua="Несправність регулятора ДГ1 — нестабільна частота ★★",
        description_en="Governor hunts. Frequency oscillates.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_DG2","SYNC_DG2","CLOSE_CB2",
                        "TRANSFER_LOAD","OPEN_CB1","VERIFY_FREQUENCY","LOG_FAULT","NOTIFY_BRIDGE"],  # FIX BUG-H: DG2 not running at fault inject, student must start it
        _apply_fn=lambda p: p.inject_governor_fault(),
        # FIX PH-4: old override set the removed global `governor_fault` field.
        # The field now lives on dg1 — but interrupt_overrides writes to
        # physics.s directly, so we target the dg1 sub-object via _apply_fn
        # instead.  No interrupt_override needed here; inject_governor_fault()
        # already sets dg1.governor_fault = True.
        interrupt_overrides={},
    )
    FAULT_SCENARIOS["dg_overload"] = FaultScenario(
        scenario_id="dg_overload",
        name_en="Bus Overload — Demand Exceeds Capacity ★★",
        name_ua="Перевантаження шини ★★",
        description_en="Load exceeds DG1 rated power. Start DG2 and share load.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","START_DG2","SYNC_DG2",
                        "CLOSE_CB2","TRANSFER_LOAD","VERIFY_FREQUENCY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_overload(),
        interrupt_overrides={"load_kw": 560.0},
    )

_register_faults()


class DGAssessmentRules:
    @staticmethod
    def check_auto_advance(state_dict: dict, procedure) -> None:
        # FIX-SCORE-2: VERIFY_FREQUENCY gates behind ACK — DG1 starts at 50Hz/400V.
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if (ack_done and state_dict.get("frequency_hz", 0) > 49.0
                and state_dict.get("voltage_v", 0) > 370.0):
            procedure.auto_mark_done("VERIFY_FREQUENCY")
        # FIX BUG-10: gate behind ack_done — prevents auto-credit before student acts
        if ack_done and state_dict.get("dg2_running") and state_dict.get("voltage_v", 0) > 370.0:
            procedure.auto_mark_done("RESTORE_LOAD")


# ── Module ────────────────────────────────────────────────────────────────────

class DGModule(BaseLabModule):
    module_id: str = "diesel_generator"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = DGPhysics()
        self._procedure = DGProcedure()

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        DGAssessmentRules.check_auto_advance(
            self._physics.get_state(), self._procedure
        )

    def _apply_power_state(self, available: bool):
        pass  # DG is the power source — never shuts itself down

    def set_power_available(self, available: bool):
        self._power_available = available  # record but don't act

    def get_state(self) -> dict:
        s = self._physics.get_state()
        s["procedure"]        = self._procedure.to_dict()
        s["power_available"]  = self._power_available
        s["scenario_id"]      = self._scenario_id
        s["active_alarms"]    = dict(self._active_alarms)
        return s

    # ── Operator actions ───────────────────────────────────────────────
    def start_dg(self, gen_num: int = 1):
        g = self._physics.s.dg1 if gen_num == 1 else self._physics.s.dg2
        g.running = True
        if gen_num == 2:
            self._procedure.mark_done("START_DG2")

    def stop_dg(self, gen_num: int = 1):
        g = self._physics.s.dg1 if gen_num == 1 else self._physics.s.dg2
        g.running = False

    def close_breaker(self, gen_num: int = 1):
        g = self._physics.s.dg1 if gen_num == 1 else self._physics.s.dg2
        min_rpm = self._physics.NOMINAL_RPM * self._physics.MIN_SYNC_RPM_FRACTION
        if not g.running:
            return
        # FIX #9: Out-of-sync CB close = hard fail (teaches correct seamanship)
        if g.speed_rpm < min_rpm:
            if not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail(
                    f"OUT_OF_SYNC_BREAKER_CLOSE_DG{gen_num}_RPM_{g.speed_rpm:.0f}"
                )
            return
        g.cb_closed = True
        if gen_num == 2:
            self._procedure.mark_done("CLOSE_CB2")

    def open_breaker(self, gen_num: int = 1):
        g = self._physics.s.dg1 if gen_num == 1 else self._physics.s.dg2
        g.cb_closed = False
        if gen_num == 1:
            self._procedure.mark_done("OPEN_CB1")

    def sync_dg2(self):
        self._procedure.mark_done("SYNC_DG2")

    def transfer_load(self):
        self._procedure.mark_done("TRANSFER_LOAD")
