"""modules/fw_generator/fwg_module.py — GOLD v1.0
FIXES: #17 (hard fail on high salinity while producing), #35 (add set_jw_temp method),
#27 (expected_steps synchronized with JSON)
"""
from __future__ import annotations
from dataclasses import dataclass
from marine_simulator.core.base_module import BaseLabModule
from marine_simulator.core.base_faults import FaultScenario
from marine_simulator.core.base_procedure import BaseProcedure


@dataclass
class FWGState:
    running:           bool  = True
    evaporator_temp_c: float = 45.0
    vacuum_mbar:       float = 71.0
    fw_production_th:  float = 1.08
    salinity_ppm:      float = 2.0
    jw_temp_c:         float = 80.0
    jw_temp_out_c:     float = 72.0
    ejector_running:   bool  = True
    ejector_pressure_mpa: float = 0.29
    tube_condition:    float = 1.0
    _low_vacuum_latched:   bool = False
    _high_saline_latched:  bool = False
    _low_prod_latched:     bool = False


class FWGPhysics:
    NOMINAL_VACUUM_MBAR   = 71.0
    LOW_VACUUM_MBAR       = 101.0
    NOMINAL_PROD_TH       = 1.08
    HIGH_SALINITY_PPM     = 5.0
    MIN_JW_TEMP_C         = 65.0
    NOMINAL_JW_TEMP_IN_C  = 80.0
    NOMINAL_JW_TEMP_OUT_C = 72.0
    NOMINAL_EVAP_TEMP_C   = 45.0
    EJECTOR_P_NOMINAL_MPA = 0.29
    TAU                   = 20.0

    def __init__(self):
        self.s = FWGState()

    def step(self, dt_s: float) -> list:
        s = self.s
        if s.ejector_running and s.running:
            target_vac = self.NOMINAL_VACUUM_MBAR
        else:
            target_vac = 1013.0
        s.vacuum_mbar += (target_vac - s.vacuum_mbar) / self.TAU * dt_s
        s.vacuum_mbar  = max(1.0, min(s.vacuum_mbar, 1013.0))
        s.jw_temp_out_c = s.jw_temp_c - 8.0
        if s.running and s.vacuum_mbar < 150.0:
            vac_quality  = max(0.0, 1.0 - (s.vacuum_mbar - self.NOMINAL_VACUUM_MBAR) / 300.0)
            jw_heat      = max(0.0, (s.jw_temp_c - self.MIN_JW_TEMP_C) / 20.0)
            target_evap  = self.NOMINAL_EVAP_TEMP_C * vac_quality * min(1.0, jw_heat)
        else:
            target_evap = 20.0
        s.evaporator_temp_c += (target_evap - s.evaporator_temp_c) / self.TAU * dt_s
        s.evaporator_temp_c  = max(0.0, min(s.evaporator_temp_c, 80.0))
        tube_eff   = s.tube_condition
        vac_factor = max(0.0, 1.0 - (s.vacuum_mbar - self.NOMINAL_VACUUM_MBAR) / 200.0)
        jw_factor  = max(0.0, (s.jw_temp_c - self.MIN_JW_TEMP_C) / 20.0)
        if s.running and s.ejector_running and s.jw_temp_c >= self.MIN_JW_TEMP_C and s.vacuum_mbar < 150.0:
            target_prod = self.NOMINAL_PROD_TH * tube_eff * vac_factor * min(1.0, jw_factor)
        else:
            target_prod = 0.0
        s.fw_production_th += (target_prod - s.fw_production_th) / self.TAU * dt_s
        s.fw_production_th  = max(0.0, min(s.fw_production_th, self.NOMINAL_PROD_TH * 1.05))
        if tube_eff < 0.5:
            target_sal = self.HIGH_SALINITY_PPM * 2.5 / max(0.1, tube_eff)
        elif s.evaporator_temp_c < 35.0 and s.running:
            target_sal = 4.5
        else:
            target_sal = 1.5
        s.salinity_ppm += (target_sal - s.salinity_ppm) / self.TAU * dt_s
        s.salinity_ppm  = max(0.0, min(s.salinity_ppm, 100.0))
        return self._eval_alarms()

    def _eval_alarms(self) -> list:
        s  = self.s
        ev = []
        if s.vacuum_mbar > 120.0 and not s._low_vacuum_latched:
            s._low_vacuum_latched = True
            ev.append(("FWG_LOW_VACUUM", 2))
        elif s.vacuum_mbar < 90.0 and s._low_vacuum_latched:
            s._low_vacuum_latched = False
            ev.append(("FWG_LOW_VACUUM", 0))
        if s.salinity_ppm > self.HIGH_SALINITY_PPM and not s._high_saline_latched:
            s._high_saline_latched = True
            ev.append(("FWG_HIGH_SALINITY", 2))
        elif s.salinity_ppm < self.HIGH_SALINITY_PPM - 3.0 and s._high_saline_latched:
            s._high_saline_latched = False
            ev.append(("FWG_HIGH_SALINITY", 0))
        if s.fw_production_th < 0.5 and s.running and not s._low_prod_latched:
            s._low_prod_latched = True
            ev.append(("FWG_LOW_PRODUCTION", 2))
        elif s.fw_production_th >= 0.7 and s._low_prod_latched:
            s._low_prod_latched = False
            ev.append(("FWG_LOW_PRODUCTION", 0))
        return ev

    def get_state(self) -> dict:
        s = self.s
        return {
            "running":              s.running,
            "vacuum_mbar":          round(s.vacuum_mbar, 1),
            "evaporator_temp_c":    round(s.evaporator_temp_c, 1),
            "fw_production_th":     round(s.fw_production_th, 3),
            "salinity_ppm":         round(s.salinity_ppm, 2),
            "jw_temp_c":            round(s.jw_temp_c, 1),
            "jw_temp_out_c":        round(s.jw_temp_out_c, 1),
            "ejector_running":      s.ejector_running,
            "ejector_pressure_mpa": round(s.ejector_pressure_mpa, 3),
            "production_rate_lh":   round(s.fw_production_th * 1000.0, 1),
            "jacket_water_temp_c":  round(s.jw_temp_c, 1),
        }

    def inject_ejector_failure(self):   self.s.ejector_running = False
    def inject_tube_leak(self):         self.s.tube_condition = 0.3
    def inject_jw_temp_drop(self):      self.s.jw_temp_c = 52.0
    def reset(self):                    self.s = FWGState()


class FWGProcedure(BaseProcedure):
    STEP_DEFINITIONS = [
        dict(step_id="ACK_ALARM",      description_en="Acknowledge FWG alarm",
             description_ua="Підтвердити сигнал ОПВ", points=10, time_budget_s=30.0),
        dict(step_id="IDENTIFY_FAULT", description_en="Check vacuum gauge, salinity meter, JW temp and production meter",
             description_ua="Перевірити вакуум, соленість, температуру ОО та продуктивність", points=15, time_budget_s=45.0),
        dict(step_id="STOP_PRODUCTION",description_en="Stop FW production and divert to bilge",
             description_ua="Зупинити виробництво ПВ та направити в льяло", points=10, time_budget_s=20.0, critical=True),
        dict(step_id="RESTORE_EJECTOR",description_en="Start standby ejector pump",
             description_ua="Запустити резервний ежекторний насос", points=15, time_budget_s=30.0),
        dict(step_id="CHECK_TUBES",    description_en="Inspect and clean evaporator tube bundle",
             description_ua="Перевірити та очистити трубний пучок", points=10, time_budget_s=60.0),
        dict(step_id="INCREASE_JW",    description_en="Restore jacket water temperature above 65°C",
             description_ua="Відновити температуру охолоджувальної води вище 65°C", points=10, time_budget_s=60.0),
        dict(step_id="VERIFY_SALINITY",description_en="Confirm salinity < 5 ppm before diverting to FW tank",
             description_ua="Переконатися що соленість < 5 ppm перед подачею в танк", points=15, time_budget_s=90.0),
        dict(step_id="LOG_FAULT",      description_en="Record in machinery log",
             description_ua="Записати в журнал", points=5, time_budget_s=60.0),
        dict(step_id="NOTIFY_BRIDGE",  description_en="Notify bridge",
             description_ua="Повідомити місток", points=5, time_budget_s=60.0),
    ]


FAULT_SCENARIOS: dict = {}

def _register():
    FAULT_SCENARIOS["fwg_ejector_failure"] = FaultScenario(
        scenario_id="fwg_ejector_failure",
        name_en="Ejector Pump Failure — Vacuum Loss ★",
        name_ua="Відмова ежекторного насоса — втрата вакууму ★",
        description_en="Ejector pump fails. Vacuum drops. Production stops.",
        difficulty=1,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","STOP_PRODUCTION","RESTORE_EJECTOR",
                        "VERIFY_SALINITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_ejector_failure(),
        interrupt_overrides={"ejector_running": False, "vacuum_mbar": 180.0},
    )
    FAULT_SCENARIOS["fwg_tube_leak"] = FaultScenario(
        scenario_id="fwg_tube_leak",
        name_en="Tube Leak — High Salinity ★★",
        name_ua="Витік через трубку — висока солоність ★★",
        description_en="Hairline crack in tube. Seawater ingress. Salinity rises.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","STOP_PRODUCTION","CHECK_TUBES",
                        "VERIFY_SALINITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_tube_leak(),
        interrupt_overrides={"tube_condition": 0.3, "salinity_ppm": 12.0},
    )
    FAULT_SCENARIOS["fwg_jw_temp_drop"] = FaultScenario(
        scenario_id="fwg_jw_temp_drop",
        name_en="JW Temperature Drop — Low Production ★★",
        name_ua="Падіння температури ОО — низька продуктивність ★★",
        description_en="JW supply temp drops below 65°C. Insufficient heat for evaporation.",
        difficulty=2,
        expected_steps=["ACK_ALARM","IDENTIFY_FAULT","STOP_PRODUCTION","INCREASE_JW",
                        "VERIFY_SALINITY","LOG_FAULT","NOTIFY_BRIDGE"],
        _apply_fn=lambda p: p.inject_jw_temp_drop(),
        interrupt_overrides={"jw_temp_c": 52.0, "fw_production_th": 0.3},
    )

_register()


class AssessmentRules:
    @staticmethod
    def check_auto_advance(state, procedure) -> None:
        ack_done = any(s.step_id == "ACK_ALARM" and s.done for s in procedure._steps)
        if ack_done and state.salinity_ppm < 5.0:
            procedure.auto_mark_done("VERIFY_SALINITY")
        if ack_done and state.ejector_running:
            procedure.auto_mark_done("RESTORE_EJECTOR")
        if ack_done and state.tube_condition >= 0.8:
            procedure.auto_mark_done("CHECK_TUBES")
        if ack_done and state.jw_temp_c >= 65.0:
            procedure.auto_mark_done("INCREASE_JW")


class FWGModule(BaseLabModule):
    module_id: str = "fw_generator"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._physics   = FWGPhysics()
        self._procedure = FWGProcedure()
        # FIX #17: Grace period counter
        self._high_sal_ticks: int = 0

    def _get_fault_scenarios(self):
        return FAULT_SCENARIOS

    def _check_auto_advance(self):
        AssessmentRules.check_auto_advance(self._physics.s, self._procedure)

    def _check_hard_fail(self):
        # FIX #17: Hard fail if producing at high salinity for more than 5 ticks
        if (self._physics.s.running and
                self._physics.s.salinity_ppm > self._physics.HIGH_SALINITY_PPM and
                self._scenario_injected):
            self._high_sal_ticks += 1
            if self._high_sal_ticks > 5 and not self._procedure.hard_fail:
                self._procedure.trigger_hard_fail("FW_CONTAMINATION_PRODUCTION_NOT_STOPPED")
        else:
            self._high_sal_ticks = 0

    def _apply_power_state(self, available: bool):
        if not available:
            self._physics.s.running         = False
            self._physics.s.ejector_running = False

    def stop_production(self):
        self._physics.s.running = False
        self._procedure.mark_done("STOP_PRODUCTION")

    def restore_ejector(self):
        self._physics.s.ejector_running = True
        self._procedure.mark_done("RESTORE_EJECTOR")

    def check_tubes(self):
        self._physics.s.tube_condition = 1.0
        self._procedure.mark_done("CHECK_TUBES")

    # FIX #35: Add method to increase JW temperature
    def increase_jw_temp(self):
        """Restore jacket water temperature by adjusting cooling system."""
        self._physics.s.jw_temp_c = min(80.0, self._physics.s.jw_temp_c + 15.0)
        self._procedure.mark_done("INCREASE_JW")

    def reset(self):
        # FIX BUG-3: _high_sal_ticks lives on the module (not on _physics) so
        # the parent reset() does not touch it.  After a reset + new inject_fault
        # a leftover counter could immediately trigger hard_fail on the first tick.
        super().reset()
        self._high_sal_ticks = 0
