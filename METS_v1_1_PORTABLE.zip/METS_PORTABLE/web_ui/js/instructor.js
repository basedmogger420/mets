/**
 * instructor.js — Instructor Dashboard Panel
 * Marine Engineering Training Simulator v1.0
 *
 * FIX (v7): Removed broken `import {sendCmd} from "./websocket.js"`.
 * sendCmd() is defined in app.js and exposed on window — we call it directly.
 * This file must be loaded AFTER app.js in index.html.
 */

export function initInstructor() {
  const panel = document.getElementById("instructorPanel");
  if (!panel) return;

  panel.innerHTML = `
    <h3 style="margin:0 0 12px 0; color:#e0e8ff;">🎓 Instructor Dashboard</h3>

    <div style="margin-bottom:10px;">
      <label style="font-size:12px; color:#8aa;">Active Module</label>
      <div id="instr-active-module" style="font-size:13px; color:#fff; font-weight:bold;">—</div>
    </div>

    <div style="margin-bottom:10px;">
      <label style="font-size:12px; color:#8aa;">Inject Fault</label>
      <select id="instr-fault-select" style="width:100%; margin-top:4px; background:#1a2a3a; color:#fff; border:1px solid #345; padding:4px; border-radius:4px;">
        <option value="">— select scenario —</option>
      </select>
      <button onclick="instructorInjectFault()"
        style="width:100%; margin-top:6px; padding:6px; background:#8b1a1a; color:#fff; border:none; border-radius:4px; cursor:pointer;">
        ⚡ Inject Selected Fault
      </button>
    </div>

    <div style="margin-bottom:10px;">
      <button onclick="instructorResetModule()"
        style="width:100%; padding:6px; background:#1a4a2a; color:#fff; border:none; border-radius:4px; cursor:pointer;">
        🔄 Reset Module
      </button>
    </div>

    <div style="margin-bottom:10px;">
      <button onclick="instructorDownloadLog()"
        style="width:100%; padding:6px; background:#1a2a4a; color:#fff; border:none; border-radius:4px; cursor:pointer;">
        💾 Download Research CSV
      </button>
    </div>

    <div>
      <button onclick="window.showReplayTimeline && window.showReplayTimeline()"
        style="width:100%; padding:6px; background:#1a3a2a; color:#7fdf9f; border:1px solid #2a5a3a; border-radius:4px; cursor:pointer;">
        📋 Review Session Timeline
      </button>
    </div>
  `;
}

/**
 * Called by app.js whenever the active lab changes.
 * Updates the module display and repopulates the fault scenario dropdown.
 */
export function updateInstructorPanel(moduleId, scenarios) {
  const label = document.getElementById("instr-active-module");
  if (label) label.textContent = moduleId || "—";

  const sel = document.getElementById("instr-fault-select");
  if (!sel) return;

  sel.innerHTML = '<option value="">— select scenario —</option>';
  if (Array.isArray(scenarios)) {
    scenarios.forEach(sc => {
      const opt = document.createElement("option");
      opt.value = sc.id;
      opt.textContent = `[${sc.difficulty}] ${sc.name_en}`;
      sel.appendChild(opt);
    });
  }
}

// ── Global handlers called by inline onclick attributes ────────────────────
// POINT 5: Use window.sendCmd (not bare `sendCmd`) so these handlers work
// correctly when called from onclick="" attributes in any browsing context,
// and to make the dependency on app.js explicit and traceable.

window.instructorInjectFault = function () {
  const sel = document.getElementById("instr-fault-select");
  if (!sel || !sel.value) {
    alert("Select a fault scenario first.");
    return;
  }
  if (typeof window.sendCmd === "function") {
    window.sendCmd(window._activeLab || null, "inject_fault", [sel.value]);
  } else {
    console.error("instructor.js: window.sendCmd not available — ensure app.js is loaded first");
  }
};

window.instructorResetModule = function () {
  const mod = window._activeLab;
  if (!mod) { alert("No active module selected."); return; }
  if (typeof window.sendCmd === "function") {
    window.sendCmd(mod, "reset", []);
  }
};

/**
 * Feature 2: Structured Research Report Logger
 * Generates a CSV-formatted report suitable for Excel / SPSS import.
 *
 * Summary section (human-readable header):
 *   - Session metadata (timestamp, module, scenario)
 *   - Total Simulation Ticks
 *   - Final Score and Grade
 *   - Total Alarms Triggered (ACTIVE events only)
 *   - Average Reaction Time (ms between first ACTIVE and first ACK)
 *
 * Data section (CSV, one row per alarm event):
 *   tick, wall_time, module, alarm_id, severity, status, reaction_time_ms
 *
 * CSV is UTF-8 with BOM so Excel auto-detects encoding.
 */
window.instructorDownloadLog = function () {
  const S       = window._S || {};
  const states  = window._moduleStates || {};
  const events  = window._alarmEventLog || [];
  const now     = new Date();
  const mod     = window._activeLab || "unknown";
  const state   = states[mod] || {};
  const proc    = state.procedure || {};
  const report  = proc.report || null;
  const ticks   = S.tick || 0;

  // ── 1. Compute summary statistics ─────────────────────────────────────
  const activeEvents = events.filter(e => e.status === "ACTIVE");
  const ackEvents    = events.filter(e => e.status === "ACK");
  const totalAlarms  = activeEvents.length;

  /**
   * Feature 1 (Research Fix): Per-alarm reaction time calculation.
   *
   * OLD (buggy): for each ACTIVE event, find the next ACK *regardless of alarm_id*.
   * With 5 simultaneous alarms this attributed the student's first ACK to ALL
   * 5 alarms, giving an average reaction time close to 0 ms — scientifically invalid.
   *
   * NEW (correct): for each ACTIVE event, find the first ACK event where
   * ack.alarm_id === active.alarm_id AND ack.timestamp_ms >= active.timestamp_ms.
   * This is a strict 1-to-1 match.  An alarm that was never individually
   * acknowledged gets reaction_time_ms = "not_acked" in the CSV row.
   *
   * The result is a per-alarm reaction time table suitable for ANOVA/SPSS analysis.
   */
  const reactionByAlarm = new Map();  // alarm_id → {active_ts, ack_ts, rt_ms}
  for (const ae of activeEvents) {
    if (reactionByAlarm.has(ae.alarm_id)) continue;  // use first ACTIVE only
    // Find the first ACK for this exact alarm_id that came after the ACTIVE event
    const ack = ackEvents.find(
      a => a.alarm_id === ae.alarm_id && a.timestamp_ms >= ae.timestamp_ms
    );
    reactionByAlarm.set(ae.alarm_id, {
      active_ts: ae.timestamp_ms,
      ack_ts:    ack ? ack.timestamp_ms : null,
      rt_ms:     ack ? (ack.timestamp_ms - ae.timestamp_ms) : null,
      tick:      ae.tick,
    });
  }

  const reactionTimes = [...reactionByAlarm.values()]
    .map(r => r.rt_ms)
    .filter(rt => rt !== null);

  const avgReactionMs = reactionTimes.length > 0
    ? Math.round(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length)
    : null;
  const minReactionMs = reactionTimes.length > 0 ? Math.min(...reactionTimes) : null;
  const maxReactionMs = reactionTimes.length > 0 ? Math.max(...reactionTimes) : null;

  const finalScore   = report ? `${report.score}/${report.max_score}` : "in_progress";
  const finalGrade   = report ? report.grade   : "N/A";
  const passPct      = report ? report.pass_score_pct : "N/A";
  const elapsedS     = report ? report.elapsed_s : (ticks || "N/A");
  const penalties    = report ? report.penalties : "N/A";
  const progress     = proc.progress_pct != null ? proc.progress_pct.toFixed(1) + "%" : "N/A";

  // ── 2. Build summary section (human-readable, hash-prefixed for Excel skip) ─
  const summaryLines = [
    "# ============================================================",
    "# MARINE ENGINEERING TRAINING SIMULATOR v7.0 STABLE",
    "# Research Report — Session Data Export",
    "# ============================================================",
    `# Generated:             ${now.toISOString()}`,
    `# Module:                ${mod}`,
    `# Scenario:              ${state.scenario_id || "none"}`,
    "#",
    "# ── SESSION SUMMARY ──────────────────────────────────────────",
    `# Total Simulation Ticks:  ${ticks}`,
    `# Procedure Progress:      ${progress}`,
    `# Final Score:             ${finalScore}  (pass threshold: ${passPct}%)`,
    `# Grade:                   ${finalGrade}`,
    `# Session Duration (s):    ${elapsedS}`,
    `# Total Penalties:         ${penalties}`,
    "#",
    "# ── ALARM STATISTICS ─────────────────────────────────────────",
    `# Total Alarms Triggered:  ${totalAlarms}`,
    `# Acknowledgements:        ${ackEvents.length}`,
    `# Avg Reaction Time (ms):  ${avgReactionMs != null ? avgReactionMs : "no_ack_recorded"}`,
    `# Avg Reaction Time (s):   ${avgReactionMs != null ? (avgReactionMs / 1000).toFixed(2) : "no_ack_recorded"}`,
    `# Min Reaction Time (ms):  ${minReactionMs != null ? minReactionMs : "N/A"}`,
    `# Max Reaction Time (ms):  ${maxReactionMs != null ? maxReactionMs : "N/A"}`,
    `# Alarms Acknowledged:     ${reactionTimes.length} / ${totalAlarms}`,
    "#",
    "# ── PER-ALARM REACTION TIMES ─────────────────────────────────",
    "# alarm_id, active_tick, active_ts_ms, ack_ts_ms, reaction_time_ms",
    "#",
    "# ── PROCEDURE STEPS ──────────────────────────────────────────",
  ];

  if (proc.steps && proc.steps.length > 0) {
    summaryLines.push("# step_id, points, penalty, done");
    for (const step of proc.steps) {
      summaryLines.push(`# ${step.step_id}, ${step.points}, ${step.penalty}, ${step.done}`);
    }
  } else {
    summaryLines.push("# No procedure steps recorded.");
  }

  summaryLines.push("#");
  summaryLines.push("# ── RAW ALARM EVENT LOG (CSV) ────────────────────────────");
  summaryLines.push("# Columns: tick, wall_time, module, alarm_id, severity, status, reaction_time_ms");
  summaryLines.push("# Import into Excel/SPSS: open as CSV, skip lines starting with #");
  summaryLines.push("#");

  // ── 3. Build CSV data rows ────────────────────────────────────────────────
  const csvHeader = "tick,wall_time,module,alarm_id,severity,status,reaction_time_ms";
  const csvRows   = [csvHeader];

  for (const ev of events) {
    // Feature 1: Use per-alarm map for accurate reaction time (no cross-contamination)
    let rt = "";
    if (ev.status === "ACTIVE") {
      const r = reactionByAlarm.get(ev.alarm_id);
      if (r && r.rt_ms !== null && r.active_ts === ev.timestamp_ms) {
        rt = String(r.rt_ms);
      } else if (r && r.rt_ms !== null) {
        rt = "";          // not the first ACTIVE — a repeat fire, skip RT
      } else {
        rt = "not_acked";
      }
    }
    // CSV-escape any field that might contain commas
    const row = [
      ev.tick ?? "",
      `"${ev.wall_time || ""}"`,
      ev.module || "",
      ev.alarm_id || "",
      ev.severity ?? "",
      ev.status || "",
      rt,
    ].join(",");
    csvRows.push(row);
  }

  // ── 4. Append final module state snapshot ────────────────────────────────
  const stateLines = [
    "",
    "# ── FINAL MODULE STATE SNAPSHOTS ────────────────────────────",
  ];
  for (const [mid, st] of Object.entries(states)) {
    stateLines.push(`# --- ${mid} ---`);
    if (st) {
      for (const [k, v] of Object.entries(st)) {
        if (k !== "procedure") {
          stateLines.push(`# ${k}: ${JSON.stringify(v)}`);
        }
      }
    }
  }

  // ── 5. Assemble and trigger download ─────────────────────────────────────
  // UTF-8 BOM (\uFEFF) ensures Excel opens as UTF-8 correctly
  const content = "\uFEFF"
    + summaryLines.join("\n") + "\n"
    + csvRows.join("\n") + "\n"
    + stateLines.join("\n") + "\n";

  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const a    = document.createElement("a");
  a.href     = URL.createObjectURL(blob);
  a.download = `SimResearch_${mod}_${now.toISOString().replace(/[:.]/g, "-")}.csv`;
  a.click();
};
