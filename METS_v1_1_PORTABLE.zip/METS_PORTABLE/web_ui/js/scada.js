/**
 * scada.js — METS v1.0 SCADA / P&ID Schematic Renderer
 * =====================================================
 * Generates high-fidelity, Transas-style P&ID diagrams for all 10 labs.
 * Each lab has a hand-crafted layout with proper ISO symbols, colour-coded
 * piping, animated flow, real-time state overlay, and instrument panel.
 *
 * Entry point:  SCADA.render(moduleId, container, state)
 * Update call:  SCADA.update(moduleId, container, state)
 */

const SCADA = (() => {

  // ── FIX #18/#40: Safe number formatter — prevents .toFixed() crash on NaN ──
  const _n = (v, d, fb) => {
    d  = (d  === undefined) ? 1   : d;
    fb = (fb === undefined) ? '—' : fb;
    const num = parseFloat(v);
    if (isNaN(num) || !isFinite(num)) return fb;
    return Math.abs(num) >= 100 ? Math.round(num).toString() : num.toFixed(d);
  };

  // ── Colour palette ──────────────────────────────────────────────────────
  const C = {
    bg: "#1a2535",
    panel: "#0e1f33",
    panelBdr: "#1a3355",
    pipe_water: "#1565c0",
    pipe_oil: "#7a3500",
    pipe_ref: "#00838f",
    pipe_fuel: "#e6a800",
    pipe_hyd: "#8e24aa",
    pipe_gas: "#558b2f",
    pipe_elec: "#f9a825",
    pipe_steam: "#b0bec5",
    pipe_air: "#546e7a",
    on: "#22c55e",
    warn: "#eab308",
    alarm: "#ef4444",
    off: "#334155",
    text: "#94a3b8",
    textHi: "#e2e8f0",
    cyan: "#06b6d4",
    muted: "#475569",
    gridLine: "#243550",
  };

  // ── SVG helpers ─────────────────────────────────────────────────────────

  function svgOpen(id, W, H) {
    return `<svg id="${id}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio="xMidYMid meet" overflow="hidden"
      style="width:100%;height:100%;display:block;position:absolute;top:0;left:0;font-family:'Share Tech Mono',monospace,sans-serif;font-size:10px;overflow:hidden">
      <defs>
        <!-- ── PIPE FLOW ARROWS (userSpaceOnUse = fixed pixel size, not scaled by stroke-width) ── -->
        <marker id="ar_w" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_water}" opacity=".85"/></marker>
        <marker id="ar_o" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_oil}" opacity=".85"/></marker>
        <marker id="ar_s" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_steam}" opacity=".85"/></marker>
        <marker id="ar_r" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_ref}" opacity=".85"/></marker>
        <marker id="ar_f" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_fuel}" opacity=".85"/></marker>
        <marker id="ar_h" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_hyd}" opacity=".85"/></marker>
        <marker id="ar_e" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_elec}" opacity=".85"/></marker>
        <marker id="ar_g" markerWidth="5" markerHeight="4" refX="4" refY="2" orient="auto" markerUnits="userSpaceOnUse">
          <polygon points="0 0,5 2,0 4" fill="${C.pipe_gas}" opacity=".85"/></marker>

        <!-- ── FILTERS ── -->
        <filter id="glow"><feGaussianBlur stdDeviation="2.5" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        <filter id="glow_s"><feGaussianBlur stdDeviation="1.5" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>

        <!-- ═══════════════════════════════════════════════════════════════
             ISA 5.1 / ISO 10628 P&ID SYMBOL LIBRARY
             All symbols drawn on 40×40 grid, origin at centre (20,20)
             Use: <use href="#sym_pump_c" x="CX-20" y="CY-20" stroke="COLOR"/>
        ═══════════════════════════════════════════════════════════════ -->

        <!-- Centrifugal pump (ISA: circle + triangle impeller) -->
        <symbol id="sym_pump_c" viewBox="0 0 40 40">
          <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" stroke-width="2"/>
          <line x1="20" y1="2" x2="20" y2="20" stroke="currentColor" stroke-width="2"/>
          <line x1="20" y1="20" x2="34" y2="28" stroke="currentColor" stroke-width="2"/>
          <line x1="20" y1="20" x2="6" y2="28" stroke="currentColor" stroke-width="2"/>
        </symbol>

        <!-- sym_pump_run removed: animateTransform inside <symbol>+<use> is broken in browsers -->

        <!-- Globe valve (ISA: bowtie) -->
        <symbol id="sym_valve_globe" viewBox="0 0 32 32">
          <polygon points="2,2 16,16 2,30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="30,2 16,16 30,30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <line x1="16" y1="0" x2="16" y2="8" stroke="currentColor" stroke-width="2"/>
          <circle cx="16" cy="4" r="3" fill="none" stroke="currentColor" stroke-width="1.5"/>
        </symbol>

        <!-- Gate valve (ISA: bowtie filled) -->
        <symbol id="sym_valve_gate" viewBox="0 0 32 32">
          <polygon points="2,2 16,16 2,30" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" opacity=".6"/>
          <polygon points="30,2 16,16 30,30" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" opacity=".6"/>
        </symbol>

        <!-- Check valve (ISA: line + triangle) -->
        <symbol id="sym_valve_check" viewBox="0 0 32 20">
          <line x1="0" y1="10" x2="32" y2="10" stroke="currentColor" stroke-width="2"/>
          <polygon points="10,2 10,18 22,10" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>
          <line x1="22" y1="2" x2="22" y2="18" stroke="currentColor" stroke-width="2"/>
        </symbol>

        <!-- Safety/relief valve (ISA: bowtie + spring) -->
        <symbol id="sym_valve_relief" viewBox="0 0 32 40">
          <polygon points="2,10 16,24 2,38" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="30,10 16,24 30,38" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <path d="M16,10 L16,0 M13,0 L19,0" stroke="currentColor" stroke-width="2" fill="none"/>
          <path d="M13,4 Q16,2 19,4 Q16,6 13,4" stroke="currentColor" stroke-width="1.5" fill="none"/>
        </symbol>

        <!-- 3-way valve (ISA: T-bowtie) -->
        <symbol id="sym_valve_3way" viewBox="0 0 40 40">
          <polygon points="2,2 20,20 2,38" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="38,2 20,20 38,38" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <line x1="20" y1="0" x2="20" y2="20" stroke="currentColor" stroke-width="2"/>
          <circle cx="20" cy="20" r="3" fill="currentColor"/>
        </symbol>

        <!-- Heat exchanger / Heater (ISA: rectangle with S-coil) -->
        <symbol id="sym_hx" viewBox="0 0 60 40">
          <rect x="2" y="2" width="56" height="36" rx="4" fill="none" stroke="currentColor" stroke-width="2"/>
          <path d="M12,20 Q16,12 20,20 Q24,28 28,20 Q32,12 36,20 Q40,28 44,20 Q48,12 52,20"
            fill="none" stroke="currentColor" stroke-width="2"/>
        </symbol>

        <!-- Shell & tube heat exchanger (ISA: rectangle + tubes) -->
        <symbol id="sym_hx_shell" viewBox="0 0 80 40">
          <rect x="2" y="8" width="76" height="24" rx="4" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="78" cy="20" rx="6" ry="12" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="2" cy="20" rx="6" ry="12" fill="none" stroke="currentColor" stroke-width="2"/>
          <line x1="15" y1="12" x2="65" y2="12" stroke="currentColor" stroke-width="1.5"/>
          <line x1="15" y1="20" x2="65" y2="20" stroke="currentColor" stroke-width="1.5"/>
          <line x1="15" y1="28" x2="65" y2="28" stroke="currentColor" stroke-width="1.5"/>
        </symbol>

        <!-- Pressure vessel / Tank (ISA: vertical cylinder) -->
        <symbol id="sym_vessel_v" viewBox="0 0 40 70">
          <rect x="4" y="12" width="32" height="46" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="20" cy="12" rx="16" ry="6" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="20" cy="58" rx="16" ry="6" fill="none" stroke="currentColor" stroke-width="2"/>
        </symbol>

        <!-- Separator / Centrifuge (ISA: vertical vessel + spin lines) -->
        <symbol id="sym_separator" viewBox="0 0 50 80">
          <rect x="5" y="15" width="40" height="50" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="25" cy="15" rx="20" ry="7" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="25" cy="65" rx="20" ry="7" fill="none" stroke="currentColor" stroke-width="2"/>
          <!-- Spin indicator lines -->
          <line x1="15" y1="30" x2="35" y2="30" stroke="currentColor" stroke-width="1.5" opacity=".6"/>
          <line x1="12" y1="38" x2="38" y2="38" stroke="currentColor" stroke-width="1.5" opacity=".6"/>
          <line x1="15" y1="46" x2="35" y2="46" stroke="currentColor" stroke-width="1.5" opacity=".6"/>
          <line x1="12" y1="54" x2="38" y2="54" stroke="currentColor" stroke-width="1.5" opacity=".6"/>
        </symbol>

        <!-- Boiler / Steam generator (ISA: horizontal drum + furnace) -->
        <symbol id="sym_boiler" viewBox="0 0 100 60">
          <ellipse cx="20" cy="30" rx="12" ry="22" fill="none" stroke="currentColor" stroke-width="2"/>
          <rect x="20" y="8" width="68" height="44" fill="none" stroke="currentColor" stroke-width="2"/>
          <ellipse cx="88" cy="30" rx="12" ry="22" fill="none" stroke="currentColor" stroke-width="2"/>
          <!-- Tubes inside -->
          <line x1="30" y1="20" x2="78" y2="20" stroke="currentColor" stroke-width="1.5" opacity=".5"/>
          <line x1="30" y1="30" x2="78" y2="30" stroke="currentColor" stroke-width="1.5" opacity=".5"/>
          <line x1="30" y1="40" x2="78" y2="40" stroke="currentColor" stroke-width="1.5" opacity=".5"/>
        </symbol>

        <!-- Compressor (ISA: circle + triangle pointing right) -->
        <symbol id="sym_compressor" viewBox="0 0 40 40">
          <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" stroke-width="2"/>
          <polygon points="8,10 8,30 32,20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
        </symbol>

        <!-- Expansion valve (ISA: two triangles tip-to-tip) -->
        <symbol id="sym_exp_valve" viewBox="0 0 32 32">
          <polygon points="2,2 16,16 2,30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="30,2 16,16 30,30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <circle cx="16" cy="16" r="2.5" fill="currentColor"/>
        </symbol>

        <!-- Flow meter (ISA: diamond) -->
        <symbol id="sym_flowmeter" viewBox="0 0 36 36">
          <polygon points="18,2 34,18 18,34 2,18" fill="none" stroke="currentColor" stroke-width="2"/>
          <text x="18" y="22" text-anchor="middle" font-size="9" fill="currentColor" font-family="monospace">FT</text>
        </symbol>

        <!-- Temperature sensor (ISA: circle TI) -->
        <symbol id="sym_ti" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="16" fill="none" stroke="currentColor" stroke-width="2"/>
          <text x="18" y="22" text-anchor="middle" font-size="10" fill="currentColor" font-family="monospace">TI</text>
        </symbol>

        <!-- Pressure indicator (ISA: circle PI) -->
        <symbol id="sym_pi" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="16" fill="none" stroke="currentColor" stroke-width="2"/>
          <text x="18" y="22" text-anchor="middle" font-size="10" fill="currentColor" font-family="monospace">PI</text>
        </symbol>

        <!-- Level gauge (ISA: rectangle LG) -->
        <symbol id="sym_lg" viewBox="0 0 20 60">
          <rect x="2" y="2" width="16" height="56" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>
          <line x1="6" y1="15" x2="14" y2="15" stroke="currentColor" stroke-width="1"/>
          <line x1="6" y1="25" x2="14" y2="25" stroke="currentColor" stroke-width="1"/>
          <line x1="6" y1="35" x2="14" y2="35" stroke="currentColor" stroke-width="1"/>
          <line x1="6" y1="45" x2="14" y2="45" stroke="currentColor" stroke-width="1"/>
        </symbol>

        <!-- Burner / flame (ISA: nozzle + flame shape) -->
        <symbol id="sym_burner" viewBox="0 0 30 40">
          <rect x="10" y="25" width="10" height="12" fill="none" stroke="currentColor" stroke-width="2"/>
          <path d="M15,25 Q8,16 12,8 Q15,4 15,0 Q20,8 22,14 Q26,20 15,25Z"
            fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>
        </symbol>

        <!-- Hydraulic actuator / RAM (ISA: rectangle with arrow) -->
        <symbol id="sym_actuator" viewBox="0 0 80 36">
          <rect x="2" y="4" width="76" height="28" rx="3" fill="none" stroke="currentColor" stroke-width="2"/>
          <rect x="30" y="8" width="20" height="20" rx="2" fill="currentColor" opacity=".3" stroke="currentColor" stroke-width="1.5"/>
          <line x1="50" y1="18" x2="76" y2="18" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
        </symbol>

        <!-- Ejector / Venturi (ISA: converging nozzle) -->
        <symbol id="sym_ejector" viewBox="0 0 50 30">
          <polygon points="2,2 22,10 22,20 2,28" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="48,6 22,10 22,20 48,24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <line x1="0" y1="15" x2="2" y2="15" stroke="currentColor" stroke-width="3"/>
        </symbol>

        <!-- Solenoid valve (ISA: valve + square actuator) -->
        <symbol id="sym_valve_sol" viewBox="0 0 32 44">
          <polygon points="2,14 16,28 2,42" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <polygon points="30,14 16,28 30,42" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
          <rect x="8" y="2" width="16" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>
          <line x1="16" y1="14" x2="16" y2="20" stroke="currentColor" stroke-width="2"/>
        </symbol>

        <!-- Motor (ISA: circle M) -->
        <symbol id="sym_motor" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="16" fill="none" stroke="currentColor" stroke-width="2"/>
          <text x="18" y="22" text-anchor="middle" font-size="12" fill="currentColor" font-family="monospace" font-weight="700">M</text>
        </symbol>

        <!-- Rudder / steering vane -->
        <symbol id="sym_rudder" viewBox="0 0 30 60">
          <line x1="15" y1="0" x2="15" y2="20" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
          <polygon points="3,20 27,20 22,55 8,55" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
        </symbol>

      </defs>`;
  }

  // Background + grid
  function bg(W, H) {
    // Darker dot grid like Transas: small dots at intersections
    let s = `<rect width="${W}" height="${H}" fill="${C.bg}"/>`;
    // Fine grid
    for (let x = 0; x <= W; x += 40)
      s += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${C.gridLine}" stroke-width=".4"/>`;
    for (let y = 0; y <= H; y += 40)
      s += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${C.gridLine}" stroke-width=".4"/>`;
    // Subtle vignette
    s += `<rect width="${W}" height="${H}" fill="none" stroke="rgba(0,0,0,.15)" stroke-width="40"/>`;
    return s;
  }

  // Instrument panel background
  function panelBox(x, y, w, h, title) {
    const titleFs = w < 70 ? 9 : 11;
    const t = L(title);  // Auto-translate panel header
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${C.panel}" stroke="${C.panelBdr}"
      stroke-width="2" rx="4"/>
      <rect x="${x + 1}" y="${y + 1}" width="${w - 2}" height="2" fill="rgba(255,255,255,.06)" rx="2"/>
      <rect x="${x}" y="${y}" width="${w}" height="22" fill="${C.panelBdr}" rx="4"/>
      <rect x="${x}" y="${y + 15}" width="${w}" height="7" fill="${C.panelBdr}"/>
      <text x="${x + w / 2}" y="${y + 15}" text-anchor="middle" fill="${C.textHi}" font-size="${titleFs}" font-weight="700" letter-spacing=".5">${t}</text>`;
  }

  // ── G1 FIX: Label pill — semi-transparent dark backdrop for in-diagram values ──
  // Ensures text is always readable regardless of what's behind it (tank fills,
  // pipe colors, equipment boundaries). Use for ALL numeric values on the diagram.
  function labelPill(x, y, text, col, fontSize) {
    const fs = fontSize || 9;
    const est = text.length * fs * 0.56;
    return `<rect x="${x - est / 2 - 4}" y="${y - fs - 1}" width="${est + 8}" height="${fs + 5}" rx="3"
        fill="rgba(6,16,30,0.82)" stroke="none"/>
      <text x="${x}" y="${y}" text-anchor="middle" fill="${col || C.textHi}" font-size="${fs}"
        font-weight="700">${text}</text>`;
  }

  // ── G3 FIX: Inactive state colors ──
  // Old: C.muted (#4a5a5e) — invisible on dark panels (dark-on-dark)
  // New: light wash at reduced opacity — faint but always readable
  const C_INACTIVE_LED = "rgba(160,185,200,0.25)";
  const C_INACTIVE_TEXT = "rgba(160,185,200,0.45)";

  // ── G4 FIX: Pipe crossing gap — ISA standard break at non-connected pipe intersections ──
  function pipeCrossGap(x, y, size) {
    const s = size || 8;
    return `<rect x="${x - s / 2}" y="${y - s / 2}" width="${s}" height="${s}" fill="${C.bg}" stroke="none"/>`;
  }

  // ── G6 FIX: SCADA label translation (DSTU-compliant Ukrainian terminology) ──
  // Merged approach: key-based lookup (our code) + full-string lookup (user's SCADA_LABELS).
  const _T_KEYS = {
    bilge_tank: "BILGE TANK", heater: "HEATER", separator: "OWS", disc_stack: "Disc Stack",
    oil_tank: "OIL TANK", bilge_pump: "BILGE PUMP", monitor: "MONITOR", overboard: "OVERBOARD",
    recirc: "RECIRC", steam_drum: "STEAM DRUM", furnace: "FURNACE", fw_tank: "FW TANK",
    steam_consumers: "STEAM CONSUMERS", steam_space: "STEAM SPACE", hfo: "HFO",
    separator_vessel: "SEPARATOR", evaporator: "EVAPORATOR", ejector: "EJECTOR", pump: "PUMP",
    fw_pump: "FW PUMP", fw_tank_s: "FW TANK", sea_chest: "SEA CHEST", brine: "BRINE",
    condenser: "CONDENSER", compressor: "COMP", exp_valve: "EXP. VALVE",
    fw_supply: "FW SUPPLY", hydro_tank: "HYDROPHORE", accomm: "ACCOMM.", galley: "GALLEY",
    engine_rm: "ENGINE RM", dg1: "DG - 1", dg2: "DG - 2", msb: "MAIN SWITCHBOARD BUS",
    steering: "STEERING", navigation: "NAVIGATION", pumps: "PUMPS", lighting: "LIGHTING",
    other: "OTHER", bunker_tank: "BUNKER TANK", service_tank: "SERVICE TANK", sludge: "SLUDGE",
    hpu: "HPU", oil_sump: "OIL SUMP", actuator: "2-RAM ACTUATOR", rfpu: "RFPU",
    helm_order: "HELM ORDER", rudder: "RUDDER", supply_pump: "SUPPLY PUMP",
    heater_epc: "HEATER EPC-60", viscometer: "VM", pcv: "PCV", engine: "ENGINE",
    hfo_tank: "HFO SERVICE TANK", cooler: "COOLER", sw_pump: "SW PUMP",
  };
  const _T_UA = {
    bilge_tank: "ЛЬЯЛЬНИЙ ТАНК", heater: "НАГРІВАЧ", separator: "СНВ", disc_stack: "Дисковий пакет",
    oil_tank: "НАФТ. ТАНК", bilge_pump: "ЛЬЯЛЬНИЙ НАСОС", monitor: "МОНІТОР", overboard: "ЗА БОРТ",
    recirc: "РЕЦИРК.", steam_drum: "ПАРОВИЙ БАРАБАН", furnace: "ТОПКА", fw_tank: "ЖИВИЛЬНИЙ БАК",
    steam_consumers: "ДО СПОЖИВАЧІВ", steam_space: "ПАРОВИЙ ПРОСТІР", hfo: "МАЗУТ",
    separator_vessel: "СЕПАРАТОР", evaporator: "ВИПАРНИК", ejector: "ЕЖЕКТОР", pump: "НАСОС",
    fw_pump: "НАСОС ПВ", fw_tank_s: "БАК ПВ", sea_chest: "КІНГСТОН", brine: "РОЗСІЛ",
    condenser: "КОНДЕНСАТОР", compressor: "КОМП", exp_valve: "ТРВ",
    fw_supply: "ПОДАЧА ПВ", hydro_tank: "ГІДРОФОР", accomm: "КАЮТИ", galley: "КАМБУЗ",
    engine_rm: "МКВ", dg1: "ДГ - 1", dg2: "ДГ - 2", msb: "ГОЛОВНИЙ РОЗПОДІЛЬНИЙ ЩИТ",
    steering: "КЕРМО", navigation: "НАВІГАЦІЯ", pumps: "НАСОСИ", lighting: "ОСВІТЛ.",
    other: "ІНШЕ", bunker_tank: "БУНКЕР", service_tank: "ВИТР. ТАНК", sludge: "ШЛАМ",
    hpu: "ГРА", oil_sump: "МАСЛ. ЄМНІСТЬ", actuator: "РУЛЬОВА МАШИНА", rfpu: "ДЗПК",
    helm_order: "ЗАМОВЛ. КУРС", rudder: "ПЕРО КЕРМА", supply_pump: "ЦИР. НАСОС",
    heater_epc: "НАГРІВАЧ ЕРС-60", viscometer: "ВМ", pcv: "КРТ", engine: "ДВИГУН",
    hfo_tank: "ВИТР. ТАНК МАЗУТУ", cooler: "ОХОЛОДЖУВАЧ", sw_pump: "НАСОС МВ",
  };
  // Full-string translations for panel headers and complex labels (from user contribution)
  const SCADA_LABELS = {
    "BILGE\\nTANK": "ЛЬЯЛЬНИЙ\\nТАНК", "BILGE PUMP": "ЛЬЯЛЬНИЙ НАСОС", "HEATER": "НАГРІВАЧ",
    "MONITOR": "МОНІТОР", "3-WAY": "3-ХОДОВИЙ", "OVERBOARD": "ЗА БОРТ", "RECIRC": "РЕЦИРК.",
    "OIL PPM": "ВМІСТ НАФТИ", "FLOW": "ВИТРАТА", "HEATER TEMPERATURE": "ТЕМП. НАГРІВАЧА",
    "OIL TANK LEVEL": "РІВЕНЬ НАФТИ", "DISC STACK": "ПАКЕТ ТАРІЛОК", "SYSTEM STATUS": "СТАТУС СИСТЕМИ",
    "INSTRUMENTS": "ПРИЛАДИ", "PRESSURE": "ТИСК", "WATER LEVEL": "РІВЕНЬ ВОДИ",
    "FLUE GAS TEMP": "ТЕМП. ГАЗІВ", "BURNER STATUS": "СТАТУС ПАЛЬНИКА",
    "STEAM DRUM": "ПАРОВИЙ БАРАБАН", "FW TANK": "БАК ПЖВ",
    "SEA CHEST": "КІНГСТОН", "EJECTOR": "ЕЖЕКТОР", "CONDENSER": "КОНДЕНСАТОР",
    "EVAPORATOR": "ВИПАРНИК", "FW PUMP": "НАСОС ПЖВ", "VACUUM %": "ВАКУУМ %",
    "SALINITY": "СОЛОНІСТЬ", "FW PRODUCTION": "ПРОДУКТИВНІСТЬ", "JW TEMP": "ТЕМП. ОХОЛ.",
    "EVAPORATOR TEMP": "ТЕМП. ВИПАРНИКА", "COMPRESSOR": "КОМПРЕСОР", "EXP. VALVE": "ТРВ",
    "SUCT": "ВСМОКТ.", "HEAD": "НАГНІТ.", "DISCH": "НАГН.Т.", "COOL": "ХОЛОД. kW",
    "COMPRESSOR STATUS": "СТАТУС КОМПРЕСОРА", "FLOW RATE": "ВИТРАТА",
    "MAIN SWITCHBOARD BUS": "ГОЛОВНИЙ РОЗПОДІЛЬНИЙ ЩИТ", "TOTAL LOAD:": "ЗАВАНТА.:",
    "MSB INSTRUMENTS": "ПРИЛАДИ ГРЩ", "BUS STATUS": "СТАТУС ШИН",
    "BUNKER\\nTANK": "БУНКЕР\\nТАНК", "SERVICE TANK": "ВИТР. ТАНК",
    "SLUDGE": "ШЛАМ", "RPM": "ОБ/ХВ", "SEPARATOR INSTRUMENTS": "ПРИЛАДИ СЕПАРАТОРА",
    "HPU": "ГРА", "OIL SUMP": "КАРТЕР", "2-RAM ACTUATOR": "РУЛЬОВА МАШИНА",
    "HELM ORDER:": "ЗАДАНА КОМАНДА:", "RUDDER ANGLE": "КУТ РУЛЯ", "HYD. PRESSURE": "ГІДР. ТИСК",
    "OIL LEVEL": "РІВЕНЬ МАСЛА", "STEERING INSTRUMENTS": "ПРИЛАДИ РУЛЬОВОЇ",
    "SUPPLY PUMP": "ЦИР. НАСОС", "HEATER EPC-60": "НАГРІВАЧ EPC-60", "VM": "В'ЯЗКОМІР",
    "PCV": "КРТ", "FCM INSTRUMENTS": "ПРИЛАДИ FCM", "HP bar": "ТИСК bar",
    "SW PUMP P1": "НАСОС ЗВ 1", "SW PUMP P2": "НАСОС ЗВ 2", "ENGINE": "ДВИГУН",
    "COOLING SYSTEM INSTRUMENTS": "ПРИЛАДИ ОХОЛ.", "COOLER EFFICIENCY (UA)": "ЕФЕКТИВНІСТЬ (UA)",
    "COOLER": "ОХОЛОДЖУВАЧ", "ACTIVE ALARMS": "АКТИВНІ АВАРІЇ", "ALARMS": "АВАРІЇ", "ALERTS": "АВАРІЇ",
    "STATUS": "СТАТУС",
    "PUMP P1": "НАСОС П1",
    "PUMP P2": "НАСОС П2",
    "FW\\nSUPPLY": "ПОДАЧА\\nПЖВ",
    "OIL\\nTANK": "НАФТ.\\nТАНК",
    "RUNNING": "ПРАЦЮЄ",
    "STOPPED": "ЗУПИНЕНО",
    "FW\\nTANK": "БАК\\nПЖВ",
    "ACCOMM.": "КАЮТИ", "GALLEY": "КАМБУЗ", "ENGINE RM": "МКВ",
    "STEERING": "КЕРМО", "NAVIGATION": "НАВІГАЦІЯ", "PUMPS": "НАСОСИ",
    "LIGHTING": "ОСВІТЛ.", "OTHER": "ІНШЕ",
    "HYDROPHORE PANEL": "ПАНЕЛЬ ГІДРОФОРА",
    "HFO SERVICE TANK": "ВИТР. ТАНК\nМАЗУТУ",
    "BOILER INSTRUMENTS": "ПРИЛАДИ КОТЛА",
    "FWG CONTROL PANEL": "ПАНЕЛЬ КЕРУВ. ОПУ",
    "REFRIGERATION INSTRUMENTS": "ПРИЛАДИ ХОЛОД.",
    "SLUDGE %": "ШЛАМ %",
    "SCΔp": "ПЕРЕПАД SC", "HXΔp": "ПЕРЕПАД HX",
    "bar": "ТИСК", "air%": "ПОВІТРЯ %",
    "⚠ MOTOR FAULT": "⚠ НЕСПРАВН. ДВИГУНА",
    "FIRING": "ГОРІННЯ", "BURNER OFF": "ПАЛЬНИК ВИМК.",
    "⚠ LOCKED OUT": "⚠ БЛОКУВАННЯ",
    "● BUS LIVE": "● ШИНИ ПІД НАПРУГОЮ", "○ BUS DEAD": "○ ШИНИ ЗНЕСТР.",
    "⚠ BLACKOUT": "⚠ ЗНЕСТРУМЛЕННЯ",
    "ALL NORMAL": "ВСЕ В НОРМІ", "✓ ALL NORMAL": "✓ ВСЕ В НОРМІ",
  };
  function L(keyOrString) {
    if (!keyOrString) return "";
    const lang = (typeof LangSwitch !== "undefined") ? LangSwitch.get() : "en";
    if (lang !== "ua") {
      // English: resolve short key to EN label, then check full-string table, or pass through
      return _T_KEYS[keyOrString] || SCADA_LABELS[keyOrString] || keyOrString;
    }
    // Ukrainian: try key lookup first, then full-string lookup
    if (_T_UA[keyOrString]) return _T_UA[keyOrString];
    if (SCADA_LABELS[keyOrString]) return SCADA_LABELS[keyOrString];
    const clean = String(keyOrString).replace(/\n/g, " ");
    if (SCADA_LABELS[clean]) return SCADA_LABELS[clean];
    return keyOrString;
  }


  // Pipe (horizontal or vertical, with flow animation)
  // FIX: animation only when flowing===true; stopped pipes are static/dim
  function pipe(x1, y1, x2, y2, col, id, flowing) {
    const mc = col === C.pipe_water ? "ar_w" : col === C.pipe_oil ? "ar_o" :
      col === C.pipe_steam ? "ar_s" : col === C.pipe_ref ? "ar_r" :
        col === C.pipe_fuel ? "ar_f" : col === C.pipe_hyd ? "ar_h" :
          col === C.pipe_elec ? "ar_e" : col === C.pipe_gas ? "ar_g" : "ar_w"; // ar_w as neutral fallback
    const anim = flowing ? '<animate attributeName="stroke-dashoffset" from="0" to="-18" dur=".85s" repeatCount="indefinite"/>' : '';
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"
        stroke="${col}" stroke-width="5" stroke-opacity=".22" stroke-linecap="round"/>
      <line id="fp_${id}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"
        stroke="${col}" stroke-width="4" stroke-linecap="round"
        stroke-dasharray="${flowing ? '8,10' : '4,8'}" marker-end="url(#${mc})"
        opacity="${flowing ? .9 : .32}" class="scada-flow">${anim}
      </line>`;
  }

  // Pipe elbow/corner
  // FIX: animation only when flowing===true
  function elbowH(x1, y1, xCorner, y2, col, id, flowing) {
    const mc = col === C.pipe_water ? "ar_w" : col === C.pipe_oil ? "ar_o" :
      col === C.pipe_steam ? "ar_s" : col === C.pipe_ref ? "ar_r" :
        col === C.pipe_fuel ? "ar_f" : col === C.pipe_hyd ? "ar_h" :
          col === C.pipe_elec ? "ar_e" : col === C.pipe_gas ? "ar_g" : "ar_w"; // ar_w as neutral fallback
    const d = `M${x1},${y1} L${xCorner},${y1} L${xCorner},${y2}`;
    const anim = flowing ? '<animate attributeName="stroke-dashoffset" from="0" to="-18" dur=".85s" repeatCount="indefinite"/>' : '';
    return `<path d="${d}" fill="none" stroke="${col}" stroke-width="5" stroke-opacity=".22" stroke-linecap="round" stroke-linejoin="round"/>
      <path id="fp_${id}" d="${d}" fill="none" stroke="${col}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"
        stroke-dasharray="${flowing ? '8,10' : '4,8'}" marker-end="url(#${mc})"
        opacity="${flowing ? .9 : .32}" class="scada-flow">${anim}
      </path>`;
  }

  // LED indicator
  function led(x, y, on, id) {
    const col = on ? C.on : C.off;
    const glow = on ? 'filter="url(#glow_s)"' : "";
    return `<circle id="led_${id}" cx="${x}" cy="${y}" r="6" fill="${col}" ${glow}/>
      <circle cx="${x}" cy="${y}" r="6" fill="none" stroke="#000" stroke-width=".8"/>
      <circle cx="${x - 1.5}" cy="${y - 1.5}" r="2" fill="rgba(255,255,255,0.4)"/>`;
  }

  // Analog gauge (circular) with live needle
  function gauge(cx, cy, r, val, min, max, unit, label, id, warnHigh, critHigh) {
    const range = max - min || 1;
    const pct = Math.max(0, Math.min(1, (val - min) / range));
    const startA = -225, sweep = 270;
    const needleA = (startA + pct * sweep) * Math.PI / 180;
    const needleLen = r * 0.72;
    const nx = cx + needleLen * Math.cos(needleA);
    const ny = cy + needleLen * Math.sin(needleA);
    const arcR = r * 0.82;
    const arcW = Math.max(1.5, r * 0.08);
    const tickOuter = r * 0.94;
    const tickInner = r * 0.78;
    const tickMinor = r * 0.86;
    const labelR = r * 0.56;
    const dotR = Math.max(1.5, r * 0.06);
    const wPct = (warnHigh != null) ? Math.max(0, Math.min(1, (warnHigh - min) / range)) : null;
    const cPct = (critHigh != null) ? Math.max(0, Math.min(1, (critHigh - min) / range)) : null;
    const needleColor = (critHigh != null && val >= critHigh) ? C.alarm
      : (warnHigh != null && val >= warnHigh) ? C.warn : C.cyan;
    function arcSvg(sp, ep, color) {
      if (ep <= sp + 0.001) return "";
      const a1 = (startA + sp * sweep) * Math.PI / 180;
      const a2 = (startA + ep * sweep) * Math.PI / 180;
      const x1 = cx + arcR * Math.cos(a1), y1 = cy + arcR * Math.sin(a1);
      const x2 = cx + arcR * Math.cos(a2), y2 = cy + arcR * Math.sin(a2);
      const large = (ep - sp) * sweep > 180 ? 1 : 0;
      return `<path d="M${x1},${y1} A${arcR},${arcR} 0 ${large},1 ${x2},${y2}" fill="none" stroke="${color}" stroke-width="${arcW}" stroke-linecap="round" opacity=".7"/>`;
    }
    let zones = "";
    if (wPct !== null && cPct !== null && cPct < wPct) {
      zones += arcSvg(0, cPct, C.alarm) + arcSvg(cPct, wPct, C.warn) + arcSvg(wPct, 1, C.on);
    } else if (wPct !== null) {
      zones += arcSvg(0, wPct, C.on);
      zones += arcSvg(wPct, cPct != null ? cPct : 1, C.warn);
      if (cPct != null) zones += arcSvg(cPct, 1, C.alarm);
    } else {
      zones += arcSvg(0, 1, C.cyan);
    }
    let ticks = "";
    const nT = 10;
    const fmtV = v => Math.abs(v) >= 10 ? Math.round(v).toString() : v.toFixed(1);
    for (let i = 0; i <= nT; i++) {
      const tp = i / nT, a = (startA + tp * sweep) * Math.PI / 180;
      const maj = (i % 2 === 0);
      const oR = maj ? tickOuter : tickMinor, iR = maj ? tickInner : tickMinor - r * 0.03;
      ticks += `<line x1="${cx + oR * Math.cos(a)}" y1="${cy + oR * Math.sin(a)}" x2="${cx + iR * Math.cos(a)}" y2="${cy + iR * Math.sin(a)}" stroke="${maj ? '#7a8a8e' : '#3a4a4e'}" stroke-width="${maj ? 1 : .5}"/>`;
      if (maj && r >= 16) {
        const lx = cx + labelR * Math.cos(a), ly = cy + labelR * Math.sin(a);
        ticks += `<text x="${lx}" y="${ly + 1}" text-anchor="middle" dominant-baseline="middle" fill="#5a6a6e" font-size="${Math.max(4.5, r * 0.22)}" font-family="monospace">${fmtV(min + tp * range)}</text>`;
      }
    }
    const dispVal = typeof val === "number" && isFinite(val)
      ? (Math.abs(val) >= 100 ? Math.round(val).toString() : val.toFixed(1)) : "\u2013";
    const valFs = Math.max(8, Math.min(12, r * 0.45));
    return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#0a1828" stroke="${C.panelBdr}" stroke-width="1.5"/>
      ${zones}${ticks}
      <line id="ndl_${id}" x1="${cx}" y1="${cy}" x2="${nx}" y2="${ny}"
        stroke="${needleColor}" stroke-width="${Math.max(1.5, r * 0.07)}" stroke-linecap="round" filter="url(#glow_s)"/>
      <circle cx="${cx}" cy="${cy}" r="${dotR}" fill="${needleColor}"/>
      <text id="val_${id}" x="${cx}" y="${cy + r + 5}" text-anchor="middle"
        fill="${needleColor}" font-size="${valFs}" font-weight="700" font-family="monospace">${dispVal}</text>
      ${unit ? `<text x="${cx}" y="${cy + r + 13}" text-anchor="middle" fill="${C.text}" font-size="6">${unit}</text>` : ""}
      ${label ? `<text x="${cx}" y="${cy - r - 3}" text-anchor="middle" fill="${C.muted}" font-size="7" font-weight="600">${label}</text>` : ""}`;
  }


  function updateGauge(svg, id, val, min, max, r, cx, cy, warnHigh, critHigh) {
    const ndl = svg.querySelector(`#ndl_${id}`);
    const valEl = svg.querySelector(`#val_${id}`);
    if (!ndl || !valEl) return;
    const pct = Math.max(0, Math.min(1, (val - min) / (max - min)));
    const needleA = (-225 + pct * 270) * Math.PI / 180;
    const needleLen = r * 0.72;
    const nx = cx + needleLen * Math.cos(needleA);
    const ny = cy + needleLen * Math.sin(needleA);
    ndl.setAttribute("x2", nx);
    ndl.setAttribute("y2", ny);
    const c = (critHigh != null && val >= critHigh) ? C.alarm : (warnHigh != null && val >= warnHigh) ? C.warn : C.cyan;
    ndl.setAttribute("stroke", c);
    const dispVal = typeof val === "number" && isFinite(val)
      ? (Math.abs(val) >= 100 ? Math.round(val).toString() : val.toFixed(1)) : "–";
    valEl.textContent = dispVal;
    valEl.setAttribute("fill", c);
  }

  // Digital display
  function digDisplay(x, y, w, h, val, unit, label, id, alarmColor) {
    const col = alarmColor || C.on;
    const disp = typeof val === "number" && isFinite(val)
      ? (Math.abs(val) >= 1000 ? Math.round(val).toString()
        : Math.abs(val) >= 100 ? val.toFixed(1) : val.toFixed(2))
      : (typeof val === "boolean" ? (val ? "ON" : "OFF") : "–");
    return `<rect x="${x + 1}" y="${y + 1}" width="${w - 1}" height="${h - 1}" rx="2" fill="rgba(0,0,0,.4)" stroke="none"/>
      <rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#010c04" rx="3" stroke="${col}" stroke-width="1.5" stroke-opacity=".5"/>
      <text x="${x + w / 2}" y="${y + 10}" text-anchor="middle" fill="${C.muted}" font-size="8">${label}</text>
      <text id="dig_${id}" x="${x + w / 2}" y="${y + h - 7}" text-anchor="middle"
        fill="${col}" font-size="15" font-weight="700" font-family="monospace" filter="url(#glow_s)">${disp}</text>
      <text x="${x + w - 4}" y="${y + h - 5}" text-anchor="end" fill="${C.muted}" font-size="7" opacity=".5">${unit}</text>`;
  }

  function updateDig(svg, id, val, alarmColor) {
    const el = svg.querySelector(`#dig_${id}`);
    if (!el) return;
    const disp = typeof val === "number" && isFinite(val)
      ? (Math.abs(val) >= 1000 ? Math.round(val).toString()
        : Math.abs(val) >= 100 ? val.toFixed(1) : val.toFixed(2))
      : (typeof val === "boolean" ? (val ? "ON" : "OFF") : "–");
    el.textContent = disp;
    if (alarmColor) el.setAttribute("fill", alarmColor);
  }

  // Pump symbol (circle with P) — action/tip optional for interactivity
  function pumpSym(cx, cy, r, running, id, label, action, tip, alarm) {
    const col = alarm ? C.alarm : running ? C.on : C.off;
    const glow = (running || alarm) ? 'filter="url(#glow_s)"' : "";
    const stateStr = alarm ? "FAULT" : running ? "RUNNING" : "STOPPED";
    const tipText = tip ? `${tip} [${stateStr}]` : stateStr;
    const handlers = action
      ? `onclick='window._scadaClick&&window._scadaClick(${JSON.stringify(action)})'
         onmouseover="window._scadaTip&&window._scadaTip(event,${JSON.stringify(tipText)})"
         onmouseout="window._scadaHide&&window._scadaHide()"
         style="cursor:pointer"`
      : tip
        ? `onmouseover="window._scadaTip&&window._scadaTip(event,${JSON.stringify(tipText)})"
         onmouseout="window._scadaHide&&window._scadaHide()"
         style="cursor:crosshair"`
        : "";
    const faultBadge = alarm ? `
      <circle cx="${cx + r - 2}" cy="${cy - r + 2}" r="7" fill="${C.alarm}" opacity=".92"/>
      <text x="${cx + r - 2}" y="${cy - r + 3}" text-anchor="middle" dominant-baseline="central"
        fill="#fff" font-size="8" font-weight="700">!</text>` : "";
    // ISA 5.1 centrifugal pump — 3 impeller blades, STATIC (no rotation)
    // All rotation animations (SMIL and CSS) cause "flying star" artifact during
    // 1Hz innerHTML replacement. Real SCADA systems use glow+LED to show running state.
    const bladeOp = running && !alarm ? ".9" : ".5";
    const blades = `<line x1="${cx}" y1="${cy}" x2="${cx}" y2="${cy - r * 0.8}" stroke="${col}" stroke-width="2.5" stroke-linecap="round" opacity="${bladeOp}"/>
         <line x1="${cx}" y1="${cy}" x2="${cx + r * 0.69}" y2="${cy + r * 0.4}" stroke="${col}" stroke-width="2.5" stroke-linecap="round" opacity="${bladeOp}"/>
         <line x1="${cx}" y1="${cy}" x2="${cx - r * 0.69}" y2="${cy + r * 0.4}" stroke="${col}" stroke-width="2.5" stroke-linecap="round" opacity="${bladeOp}"/>`;
    return `<g ${handlers}><title>${tipText}</title>
      <circle cx="${cx + 1}" cy="${cy + 2}" r="${r}" fill="rgba(0,0,0,.3)" stroke="none"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="#06111e" stroke="${col}" stroke-width="2.5" ${glow}/>
      ${blades}
      <circle cx="${cx}" cy="${cy}" r="${r * 0.14}" fill="${col}" opacity=".9"/>
      <text x="${cx}" y="${cy + r + 13}" text-anchor="middle" fill="${C.text}" font-size="9" font-weight="600">${label}</text>
      ${faultBadge}
    </g>`;
  }

  // Vessel / tank symbol
  function vessel(x, y, w, h, label, col) {
    const c = col || C.pipe_water;
    const lines = label.split("\n");
    const lineH = 13, startY = (y + h / 2) - (lines.length - 1) * lineH / 2;
    let textLines = lines.map((ln, i) =>
      `<text x="${x + w / 2}" y="${startY + i * lineH}" text-anchor="middle" dominant-baseline="central"
        fill="${c}" font-size="10" font-weight="700">${ln}</text>`).join('');
    return `<rect x="${x + 2}" y="${y + 3}" width="${w - 2}" height="${h - 2}" rx="6" fill="rgba(0,0,0,.35)" stroke="none"/>
      <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="6" fill="#071020"
        stroke="${c}" stroke-width="2.5"/>
      <rect x="${x + 2}" y="${y + 2}" width="${w - 4}" height="4" rx="3" fill="rgba(255,255,255,.06)"/>
      <rect x="${x + 3}" y="${y + 3}" width="${w - 6}" height="${h - 6}" rx="4" fill="none"
        stroke="${c}" stroke-width=".5" opacity=".25"/>
      ${textLines}`;
  }

  // Valve symbol — ISA 5.1 globe valve (bowtie)
  function valveSym(cx, cy, open, id, label) {
    const col = open ? C.on : C.alarm;
    const glow = open ? 'filter="url(#glow_s)"' : "";
    // ISA globe valve: two triangles tip-to-tip with stem
    return `<g id="valv_${id}" ${glow}>
      <polygon points="${cx - 12},${cy - 11} ${cx + 12},${cy - 11} ${cx},${cy + 2}"
        fill="#06111e" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>
      <polygon points="${cx - 12},${cy + 13} ${cx + 12},${cy + 13} ${cx},${cy}"
        fill="#06111e" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>
      <line x1="${cx}" y1="${cy - 11}" x2="${cx}" y2="${cy - 18}" stroke="${col}" stroke-width="2"/>
      <circle cx="${cx}" cy="${cy - 20}" r="4" fill="#06111e" stroke="${col}" stroke-width="1.5"/>
      <circle cx="${cx}" cy="${cy + 1}" r="2.5" fill="${col}"/>
    </g>
    <text x="${cx}" y="${cy + 26}" text-anchor="middle" fill="${C.text}" font-size="9">${label}</text>`;
  }

  // Separator vessel — ISA disc stack symbol
  function separatorVessel(cx, cy, rx, ry, cond, id, label) {
    const col = cond > 0.7 ? C.on : cond > 0.4 ? C.warn : C.alarm;
    const w = rx * 2, h = ry * 2;
    return `<g id="sep_${id}">
      <!-- ISA separator: rectangle with horizontal partition lines -->
      <rect x="${cx - rx}" y="${cy - ry}" width="${w}" height="${h}" rx="6"
        fill="#06111e" stroke="${col}" stroke-width="2"/>
      <ellipse cx="${cx}" cy="${cy - ry}" rx="${rx}" ry="6"
        fill="#06111e" stroke="${col}" stroke-width="2"/>
      <ellipse cx="${cx}" cy="${cy + ry}" rx="${rx}" ry="6"
        fill="#06111e" stroke="${col}" stroke-width="2"/>
      <!-- Disc stack lines -->
      ${[-0.5, -0.25, 0, 0.25, 0.5].map(f => `
        <line x1="${cx - rx * 0.75}" y1="${cy + f * ry}" x2="${cx + rx * 0.75}" y2="${cy + f * ry}"
          stroke="${col}" stroke-width="1.2" opacity="${0.35 + cond * 0.4}"/>`).join('')}
      <text x="${cx}" y="${cy + 3}" text-anchor="middle" dominant-baseline="central"
        fill="${col}" font-size="11" font-weight="700">${label}</text>
    </g>
    ${labelPill(cx, cy + ry + 18, '(' + _n(cond * 100, 0) + '%)', col, 9)}`;
  }

  // ── ISA 5.1 HELPER FUNCTIONS ───────────────────────────────────────────

  // ISA compressor symbol (circle + triangle)
  function compressorSym(cx, cy, r, running, label) {
    const col = running ? C.on : C.off;
    const glow = running ? 'filter="url(#glow_s)"' : "";
    return `<circle cx="${cx + 1}" cy="${cy + 2}" r="${r}" fill="rgba(0,0,0,.3)"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="#06111e" stroke="${col}" stroke-width="2.5" ${glow}/>
      <polygon points="${cx - r * 0.5},${cy - r * 0.65} ${cx - r * 0.5},${cy + r * 0.65} ${cx + r * 0.7},${cy}"
        fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round" opacity="${running ? .9 : .5}"/>
      <text x="${cx}" y="${cy + r + 13}" text-anchor="middle" fill="${C.text}" font-size="9">${label}</text>`;
  }

  // ISA heat exchanger coil symbol
  function heatExSym(x, y, w, h, on, id, label, tempStr) {
    const col = on ? C.pipe_steam : C.off;
    const coilY = y + h * 0.5;
    let coil = '';
    const steps = Math.floor((w - 16) / 12);
    for (let i = 0; i < steps; i++) {
      const cx2 = x + 8 + i * 12 + 6;
      coil += `<path d="M${cx2 - 6},${coilY} Q${cx2},${coilY - 7} ${cx2 + 6},${coilY} Q${cx2},${coilY + 7} ${cx2 - 6},${coilY}" fill="none" stroke="${col}" stroke-width="1.8"/>`;
    }
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="5"
        fill="#06111e" stroke="${col}" stroke-width="2" id="eq_${id}"/>
      ${coil}
      <text x="${x + w / 2}" y="${y + h + 13}" text-anchor="middle" fill="${C.text}" font-size="9">${label}</text>
      ${tempStr ? `<text x="${x + w / 2}" y="${y + h + 24}" text-anchor="middle" fill="${col}" font-size="9" font-weight="700">${tempStr}</text>` : ''}`;
  }

  // ISA check valve (arrow + bar)
  function checkValveSym(cx, cy, horiz, col) {
    const c = col || C.pipe_water;
    if (horiz) {
      return `<polygon points="${cx - 5},${cy - 8} ${cx - 5},${cy + 8} ${cx + 7},${cy}"
          fill="${c}" stroke="${c}" stroke-width="1.5" stroke-linejoin="round"/>
        <line x1="${cx + 7}" y1="${cy - 9}" x2="${cx + 7}" y2="${cy + 9}" stroke="${c}" stroke-width="2.5"/>`;
    }
    return `<polygon points="${cx - 8},${cy - 5} ${cx + 8},${cy - 5} ${cx},${cy + 7}"
        fill="${c}" stroke="${c}" stroke-width="1.5" stroke-linejoin="round"/>
      <line x1="${cx - 9}" y1="${cy + 7}" x2="${cx + 9}" y2="${cy + 7}" stroke="${c}" stroke-width="2.5"/>`;
  }

  // ISA safety/relief valve
  function safetyValveSym(cx, cy, open, id) {
    const col = open ? C.alarm : C.muted;
    return `<g id="sv_${id}">
      <polygon points="${cx - 10},${cy - 9} ${cx + 10},${cy - 9} ${cx},${cy + 7}"
        fill="#06111e" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>
      <polygon points="${cx - 10},${cy + 9} ${cx + 10},${cy + 9} ${cx},${cy - 7}"
        fill="#06111e" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>
      <line x1="${cx}" y1="${cy - 9}" x2="${cx}" y2="${cy - 22}" stroke="${col}" stroke-width="2"/>
      <path d="M${cx - 5},${cy - 18} Q${cx},${cy - 14} ${cx + 5},${cy - 18}" fill="none" stroke="${col}" stroke-width="2"/>
      <text x="${cx}" y="${cy - 28}" text-anchor="middle" fill="${col}" font-size="8" font-weight="700">SV</text>
    </g>`;
  }

  // ISA vertical level gauge
  function levelGaugeSym(x, y, w, h, level, col, id) {
    const c = col || C.pipe_water;
    const fillH = Math.max(2, (h - 4) * Math.min(1, level / 100));
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="3"
        fill="#030a12" stroke="${c}" stroke-width="2" id="lg_${id}"/>
      <rect x="${x + 2}" y="${y + h - 2 - fillH}" width="${w - 4}" height="${fillH}" rx="2"
        fill="${c}" opacity=".5"/>`;
  }

  // Boiler/vessel shape
  function boilerVessel(cx, cy, w, h, running, id, label) {
    const col = running ? C.on : C.off;
    return `<rect x="${cx - w / 2}" y="${cy - h / 2}" width="${w}" height="${h * 0.7}" rx="4"
      fill="#0a1828" stroke="${col}" stroke-width="2" id="eq_${id}"/>
      <ellipse cx="${cx}" cy="${cy - h / 2}" rx="${w / 2}" ry="8" fill="#0a1828" stroke="${col}" stroke-width="2"/>
      <text x="${cx}" y="${cy - 4}" text-anchor="middle" fill="${col}" font-size="10" font-weight="600">${label}</text>`;
  }

  // Flow value label on pipe
  function pipeLabel(x, y, val, unit) {
    return `<rect x="${x - 20}" y="${y - 9}" width="40" height="16" rx="3" fill="#0a1828" opacity=".85"/>
      <text x="${x}" y="${y + 3}" text-anchor="middle" fill="${C.cyan}" font-size="10" font-family="monospace">${val}${unit}</text>`;
  }

  // Section divider
  function divider(x, y1, y2) {
    return `<line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}" stroke="${C.panelBdr}" stroke-width="1.5" stroke-dasharray="4,4"/>`;
  }

  // Invisible tooltip/click rectangle over any area
  function tipRect(x, y, w, h, tip, action) {
    const safeT = JSON.stringify(String(tip));
    const click = action
      ? `onclick='window._scadaClick&&window._scadaClick(${JSON.stringify(action)})' style="cursor:pointer"`
      : `style="cursor:crosshair"`;
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="transparent" rx="2"
      ${click}
      onmouseover="window._scadaTip&&window._scadaTip(event,${safeT})"
      onmouseout="window._scadaHide&&window._scadaHide()"/>`;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 1 — OWS (Oily Water Separator)
  // ════════════════════════════════════════════════════════════════════════

  function renderOWS(W, H, st, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const pumpRun = !!s.bilge_pump_running;
    const heatOn = !!s.heater_on;
    const sepRun = !!s.separator_running;
    const monOk = s.monitor_functioning !== false;
    const overboard = !!s.three_way_valve_overboard;
    const ppm = typeof s.oil_content_ppm === "number" ? s.oil_content_ppm : 0;
    const flow = typeof s.flow_ls === "number" ? s.flow_ls : 0;
    const hTemp = typeof s.heater_temp_c === "number" ? s.heater_temp_c : 0;
    const oilTank = typeof s.oil_tank_level_pct === "number" ? s.oil_tank_level_pct : 0;
    const discCond = typeof s.disc_stack_condition === "number" ? s.disc_stack_condition : 1;
    const flowing = pumpRun && flow > 0.3;
    const PD = W - 220; // dynamic panel divider

    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);

    // ── Title ──────────────────────────────────────────────────────────────
    svg += `<text x="12" y="20" fill="${C.cyan}" font-size="13" font-weight="700" opacity=".8">
      OWS — OILY WATER SEPARATOR  /  СЕПАРАТОР НАФТОВМІСНИХ ВОД</text>`;

    // ── LEGEND ─────────────────────────────────────────────────────────────
    svg += legend(PD, H, [
      { color: C.pipe_water, label: "Bilge / Льяльна вода" },
      { color: C.pipe_oil, label: "Oily water / Нафтовмісна" },
      { color: C.pipe_steam, label: "Steam / Пара", dashed: true },
      { color: C.on, label: "Clean effluent / Чиста вода" },
    ]);

    // ── BILGE TANK ─────────────────────────────────────────────────────────
    const BT = { x: 20, y: 120, w: 64, h: 90 };
    svg += vessel(BT.x, BT.y, BT.w, BT.h, L("bilge_tank"), C.pipe_water);
    svg += `<text x="${BT.x + BT.w / 2}" y="${BT.y + BT.h / 2 + 14}" text-anchor="middle"
      fill="${C.muted}" font-size="8">льяло</text>`;

    // ── PIPE: Bilge → Pump ─────────────────────────────────────────────────
    svg += pipe(BT.x + BT.w, BT.y + BT.h / 2, 140, BT.y + BT.h / 2, C.pipe_water, "bt_pump", flowing);

    // ── BILGE PUMP ─────────────────────────────────────────────────────────
    const PX = 158, PY = BT.y + BT.h / 2;
    svg += `<g id="${pfx}pump_grp">` + pumpSym(PX, PY, 18, pumpRun, `${pfx}pump`, L("bilge_pump")) + `</g>`;
    svg += led(PX + 24, PY - 20, pumpRun, `${pfx}pump_led`);

    // ── PIPE: Pump → Heater ────────────────────────────────────────────────
    svg += pipe(PX + 18, PY, 222, PY, C.pipe_water, "pump_heat", flowing);

    // ── STEAM HEATER — ISA heat exchanger symbol ─────────────────────────
    const HX = 222, HY = PY - 28;
    svg += heatExSym(HX, HY, 62, 56, heatOn, `${pfx}heater`, L("heater"), null);
    svg += `<text x="${HX + 31}" y="${HY + 54}" text-anchor="middle" fill="${C.muted}" font-size="8">нагрівач</text>`;
    svg += led(HX + 60, HY + 4, heatOn, `${pfx}heat_led`);

    // ── STEAM SUPPLY (dashed, top) ─────────────────────────────────────────
    svg += `<line x1="${HX + 30}" y1="${HY}" x2="${HX + 30}" y2="${HY - 25}"
      stroke="${heatOn ? C.pipe_steam : C.muted}" stroke-width="2" stroke-dasharray="5,3"/>
      <text x="${HX + 35}" y="${HY - 12}" fill="${C.pipe_steam}" font-size="8">STEAM</text>`;

    // ── PIPE: Heater → Separator ───────────────────────────────────────────
    svg += pipe(HX + 60, PY, 318, PY, C.pipe_oil, "heat_sep", flowing);

    // ── OWS SEPARATOR ──────────────────────────────────────────────────────
    const SEX = 360, SEY = PY;
    svg += separatorVessel(SEX, SEY, 42, 55, discCond, `${pfx}sep`, "OWS");
    svg += `<text x="${SEX}" y="${SEY - 55 - 14}" text-anchor="middle" fill="${C.text}" font-size="9">Disc Stack</text>`;

    // ── OIL DRAIN (bottom of separator → oil tank) ─────────────────────────
    const OTX = SEX - 30, OTY = SEY + 100;
    svg += elbowH(SEX - 10, SEY + 55, OTX, OTY, C.pipe_oil, "sep_oiltank", flowing);
    svg += vessel(OTX - 28, OTY, 56, 44, L("oil_tank"), C.pipe_oil);
    svg += `<text x="${OTX}" y="${OTY + 54}" text-anchor="middle" fill="${C.muted}" font-size="8">${_n(oilTank, 0)}%</text>`;

    // ── PIPE: Separator → Monitor ──────────────────────────────────────────
    svg += pipe(SEX + 42, PY, 440, PY, C.on, "sep_mon", flowing);

    // ── 15ppm MONITOR ──────────────────────────────────────────────────────
    const MX = 458, MY = PY;
    const monCol = !monOk ? C.alarm : (ppm > 15 ? C.alarm : ppm > 10 ? C.warn : C.on);
    svg += `<rect x="${MX - 18}" y="${MY - 18}" width="36" height="36" rx="4"
      fill="#0a1828" stroke="${monCol}" stroke-width="2" id="${pfx}monitor" transform="rotate(45 ${MX} ${MY})"/>`;
    svg += `<text x="${MX}" y="${MY - 2}" text-anchor="middle" fill="${monCol}" font-size="9" font-weight="700">15</text>`;
    svg += `<text x="${MX}" y="${MY + 9}" text-anchor="middle" fill="${monCol}" font-size="8">ppm</text>`;
    svg += `<text x="${MX}" y="${MY + 30}" text-anchor="middle" fill="${C.text}" font-size="9">MONITOR</text>`;
    svg += led(MX + 22, MY - 22, monOk, `${pfx}mon_led`);

    // ── PIPE: Monitor → 3-way valve ────────────────────────────────────────
    svg += pipe(MX + 18, PY, 510, PY, C.on, "mon_valve", flowing);

    // ── THREE-WAY VALVE ────────────────────────────────────────────────────
    const TVX = 526, TVY = PY;
    svg += `<polygon points="${TVX - 14},${TVY - 14} ${TVX + 14},${TVY - 14} ${TVX},${TVY + 14}"
      fill="#0a1828" stroke="${C.on}" stroke-width="2"/>
      <polygon points="${TVX - 14},${TVY + 14} ${TVX + 14},${TVY + 14} ${TVX},${TVY - 14}"
      fill="#0a1828" stroke="${C.on}" stroke-width="2"/>
      <circle cx="${TVX}" cy="${TVY}" r="4" fill="${overboard ? C.on : C.warn}"/>
      <text x="${TVX}" y="${TVY + 26}" text-anchor="middle" fill="${C.text}" font-size="8">3-WAY</text>`;

    // ── OVERBOARD (up & right) ─────────────────────────────────────────────
    const OBY = PY - 60;
    svg += elbowH(TVX, TVY - 14, TVX, OBY, overboard ? C.on : C.muted, "valve_ob", flowing && overboard);
    svg += pipe(TVX, OBY, PD - 20, OBY, overboard ? C.on : C.muted, "ob_out", flowing && overboard);
    svg += `<text x="${PD - 4}" y="${OBY - 6}" text-anchor="end" fill="${overboard ? C.on : C.muted}" font-size="9" font-weight="700">⯈ SEA</text>`;
    svg += valveSym(TVX + 30, OBY, overboard, `${pfx}ob_valve`, L("overboard"));

    // Recirculate — 3-way valve bottom → back to pump SUCTION pipe (before pump)
    // Suction pipe runs from BT.x+BT.w (84) to 140 at y=PY; join at midpoint x=112
    const rcOn = !overboard;
    const rcActive = flowing && rcOn;
    const RCY = TVY + 68;
    const rcJoinX = BT.x + BT.w + 14; // x=98: on the suction pipe, between tank outlet and pump inlet
    svg += elbowH(TVX, TVY + 14, TVX, RCY, rcOn ? C.pipe_water : C.muted, "valve_rc", rcActive);
    svg += pipe(TVX, RCY, rcJoinX, RCY, rcOn ? C.pipe_water : C.muted, "rc_back", rcActive);
    svg += elbowH(rcJoinX, RCY, rcJoinX, PY, rcOn ? C.pipe_water : C.muted, "rc_join", rcActive);
    // Tee dot on suction pipe
    svg += `<circle cx="${rcJoinX}" cy="${PY}" r="4" fill="${rcOn ? C.pipe_water : C.muted}" opacity=".8"/>`;
    svg += valveSym(TVX - 30, RCY, rcOn, `${pfx}rc_valve`, L("recirc"));
    // Label above the return pipe, centred between rcJoinX and TVX
    const rcLabelX = rcJoinX + (TVX - rcJoinX) / 2;
    svg += `<text x="${rcLabelX}" y="${RCY - 8}" text-anchor="middle"
      fill="${rcOn ? C.pipe_water : C.muted}" font-size="8">↩ RECIRC</text>`;

    // ── DIVIDER ────────────────────────────────────────────────────────────
    svg += divider(PD, 25, H - 25);

    // ── INSTRUMENT PANEL (right, compact digital) ───────────────────────────
    const PW = W - PD - 10;
    const PL = PD + 5;     // panel left edge
    const ppmColor = ppm >= 30 ? C.alarm : ppm >= 15 ? C.warn : C.on;
    const flowColor = flow < 0.5 ? C.warn : C.on;
    const tempColor = hTemp < 35 ? C.alarm : hTemp < 45 ? C.warn : C.on;

    svg += `<text x="${PL + PW / 2}" y="20" text-anchor="middle" fill="${C.cyan}"
      font-size="11" font-weight="700">INSTRUMENTS</text>`;

    // Row 1: PPM + Flow side by side as digital readouts with gauge
    const halfW = (PW - 8) / 2;
    svg += panelBox(PL + 2, 25, halfW, 95, "OIL PPM");
    svg += digDisplay(PL + 6, 42, halfW - 8, 30, ppm, "PPM", "", `${pfx}ppm`, ppmColor);
    svg += gauge(PL + 2 + halfW / 2, 95, 18, ppm, 0, 50, "", "", `${pfx}gppm`, 15, 30);

    svg += panelBox(PL + halfW + 6, 25, halfW, 95, "FLOW");
    svg += digDisplay(PL + halfW + 10, 42, halfW - 8, 30, flow, "L/s", "", `${pfx}flow`, flowColor);
    svg += gauge(PL + halfW + 6 + halfW / 2, 95, 18, flow, 0, 4, "", "", `${pfx}gflow`, 0.5);

    // Row 2: Heater temp
    let py = 128;
    svg += panelBox(PL, py, PW - 2, 45, "HEATER TEMPERATURE");
    svg += led(PL + 8, py + 32, heatOn, `${pfx}heat2_led`);
    svg += `<text x="${PL + 20}" y="${py + 36}" fill="${C.text}" font-size="9">${heatOn ? "ON" : "OFF"}</text>`;
    svg += digDisplay(PL + 50, py + 20, PW - 58, 22, hTemp, "°C", "", `${pfx}htemp`, tempColor);

    // Row 3: Oil tank level bar
    py = 180;
    svg += panelBox(PL, py, PW - 2, 42, "OIL TANK LEVEL");
    const oilBarW = (PW - 22) * Math.min(1, oilTank / 100);
    const oilBarColor = oilTank > 80 ? C.alarm : oilTank > 60 ? C.warn : C.on;
    svg += `<rect x="${PL + 8}" y="${py + 25}" width="${PW - 18}" height="12" rx="2" fill="#0a1020" stroke="${C.panelBdr}" stroke-width="1"/>`;
    svg += `<rect x="${PL + 8}" y="${py + 25}" width="${(PW - 18) * Math.min(1, oilTank / 100)}" height="12" rx="2" fill="${oilBarColor}" opacity=".7"/>`;
    svg += `<text x="${PL + PW / 2}" y="${py + 35}" text-anchor="middle" fill="${oilBarColor}" font-size="10" font-weight="700" font-family="monospace">${_n(oilTank, 0)}%</text>`;

    // Row 4: Disc stack condition bar
    py = 229;
    svg += panelBox(PL, py, PW - 2, 42, "DISC STACK");
    const dBarW = (PW - 22) * discCond;
    const dBarColor = discCond > 0.7 ? C.on : discCond > 0.4 ? C.warn : C.alarm;
    svg += `<rect x="${PL + 8}" y="${py + 25}" width="${PW - 22}" height="12" rx="2" fill="#0a1020" stroke="${C.panelBdr}" stroke-width="1"/>`;
    svg += `<rect x="${PL + 8}" y="${py + 25}" width="${dBarW}" height="12" rx="2" fill="${dBarColor}" opacity=".7"/>`;
    svg += `<text x="${PL + PW / 2}" y="${py + 35}" text-anchor="middle"
      fill="${dBarColor}" font-size="10" font-weight="700" font-family="monospace">${_n(discCond * 100, 0)}%</text>`;

    // Row 5: Status LEDs
    py = 278;
    svg += panelBox(PL, py, PW - 2, 76, "SYSTEM STATUS");
    const statItems = [
      { label: L("bilge_pump"), on: pumpRun },
      { label: L("heater"), on: heatOn },
      { label: "SEPARATOR", on: sepRun },
      { label: L("monitor"), on: monOk },
      { label: L("overboard"), on: overboard },
    ];
    statItems.forEach((it, i) => {
      const sx = PL + 10, sy = py + 24 + i * 11;
      svg += led(sx, sy, it.on, `${pfx}st_${i}`);
      svg += `<text x="${sx + 10}" y="${sy + 4}" fill="${it.on ? C.textHi : C_INACTIVE_TEXT}" font-size="8.5">${it.label}</text>`;
    });

    if (ppm >= 15) {
      svg += `<rect x="${PL + PW - 52}" y="${py}" width="46" height="24" rx="4"
        fill="${C.alarm}" opacity=".2" stroke="${C.alarm}" stroke-width="1.5"/>
        <text x="${PL + PW - 29}" y="${py + 16}" text-anchor="middle" fill="${C.alarm}"
          font-size="8" font-weight="700">⚠ HIGH PPM</text>`;
    }

    svg += `</svg>`;
    return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 2 — BOILER
  // ════════════════════════════════════════════════════════════════════════

  function renderBoiler(W, H, st, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const running = !!s.running;
    const flameOn = !!s.flame_on;
    const fuelOpen = !!s.fuel_valve_open;
    const feedPump = !!s.feed_pump_running;
    const feedPump2 = !!s.feed_pump_2_running;
    const safetyV = !!s.safety_valve_lifted;
    const burnerLO = !!s.burner_locked_out;
    const press = typeof s.steam_pressure_bar === "number" ? s.steam_pressure_bar : 0;
    const level = typeof s.water_level_pct === "number" ? s.water_level_pct : 0;
    const flueT = typeof s.flue_temp_c === "number" ? s.flue_temp_c : 0;
    const steamFlow = running && flameOn;
    const feedFlow = running && feedPump;
    const PD = W - 220;

    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);

    // ─ Title bar ─────────────────────────────────────────────────────────
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_steam}" font-size="11" font-weight="700">
      ДОПОМІЖНИЙ КОТЕЛ AQ-10 / AUXILIARY BOILER</text>`;
    svg += `<text x="${PD - 10}" y="15" text-anchor="end" fill="${C.muted}" font-size="9">
      ${press.toFixed(1)} bar  |  ${level.toFixed(0)}% level  |  ${flueT.toFixed(0)}°C flue</text>`;

    const steamCol = steamFlow ? C.pipe_steam : "#2a3a4a";
    const waterCol = feedFlow ? C.pipe_water : "#1a2a3a";

    // ═══════════════════════════════════════════════════════════════
    // P&ID MAIN DIAGRAM — shifted right to centre in PD area
    // ═══════════════════════════════════════════════════════════════
    const OX = 70; // horizontal offset to centre content in 740px-wide area

    // ── FEED WATER TANK (bottom-left) ────────────────────────────────────
    const FWT = { x: 22 + OX, y: 310, w: 70, h: 60 };
    svg += `<rect x="${FWT.x}" y="${FWT.y}" width="${FWT.w}" height="${FWT.h}" rx="0"
      fill="#08142a" stroke="${C.pipe_water}" stroke-width="2"/>`;
    // Water fill inside tank
    svg += `<rect x="${FWT.x + 2}" y="${FWT.y + FWT.h * 0.4}" width="${FWT.w - 4}" height="${FWT.h * 0.58}"
      fill="${C.pipe_water}" opacity=".18"/>`;
    svg += `<text x="${FWT.x + FWT.w / 2}" y="${FWT.y + FWT.h / 2 + 2}" text-anchor="middle"
      fill="${C.pipe_water}" font-size="9" font-weight="600">FW TANK</text>`;
    svg += `<text x="${FWT.x + FWT.w / 2}" y="${FWT.y + FWT.h / 2 + 13}" text-anchor="middle"
      fill="${C.muted}" font-size="8">живильний бак</text>`;

    // ── FEED PUMP 1 ───────────────────────────────────────────────────────
    const FP1 = { x: 145 + OX, y: 337 };
    // Pipe from tank to pump
    svg += pipe(FWT.x + FWT.w, FWT.y + FWT.h / 2, FP1.x - 18, FWT.y + FWT.h / 2, C.pipe_water, "tank_fp1", feedFlow);
    // Pump circle (ISO symbol)
    svg += `<circle cx="${FP1.x}" cy="${FP1.y}" r="18" fill="#06111e"
      stroke="${feedPump ? C.on : C.off}" stroke-width="2.5"
      ${feedPump ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<circle cx="${FP1.x}" cy="${FP1.y}" r="18" fill="none"
      stroke="${feedPump ? C.on : C.muted}" stroke-width="1" opacity=".4" stroke-dasharray="${feedPump ? "0" : "4,3"}"/>`;
    // Pump triangle inside
    svg += `<polygon points="${FP1.x - 8},${FP1.y + 8} ${FP1.x - 8},${FP1.y - 8} ${FP1.x + 10},${FP1.y}"
      fill="${feedPump ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${FP1.x}" y="${FP1.y + 32}" text-anchor="middle" fill="${C.text}" font-size="8">FP-1</text>`;
    svg += led(FP1.x + 22, FP1.y - 22, feedPump, `${pfx}fp1_led`);

    // ── FEED PUMP 2 (standby) ─────────────────────────────────────────────
    // FP2 pipe: vertical from tank top-centre up to FP2 level, then horizontal to pump inlet
    const FP2 = { x: 145 + OX, y: 280 };
    svg += pipe(FWT.x + FWT.w / 2, FWT.y, FWT.x + FWT.w / 2, FP2.y, C.pipe_water, "tank_fp2", feedFlow && feedPump2);
    svg += pipe(FWT.x + FWT.w / 2, FP2.y, FP2.x - 18, FP2.y, C.pipe_water, "elb_fp2", feedFlow && feedPump2);
    svg += `<circle cx="${FP2.x}" cy="${FP2.y}" r="18" fill="#06111e"
      stroke="${feedPump2 ? C.on : C.off}" stroke-width="2.5"/>`;
    svg += `<polygon points="${FP2.x - 8},${FP2.y + 8} ${FP2.x - 8},${FP2.y - 8} ${FP2.x + 10},${FP2.y}"
      fill="${feedPump2 ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${FP2.x}" y="${FP2.y - 26}" text-anchor="middle" fill="${C.text}" font-size="8">FP-2</text>`;
    svg += led(FP2.x + 22, FP2.y - 22, feedPump2, `${pfx}fp2_led`);

    // ── FEED CONTROL VALVE ────────────────────────────────────────────────
    const FCV = { x: 210 + OX, y: 337 };
    svg += pipe(FP1.x + 18, FP1.y, FCV.x - 12, FCV.y, C.pipe_water, "fp1_fcv", feedFlow);
    // ISO gate valve symbol (two triangles)
    svg += `<polygon points="${FCV.x - 10},${FCV.y - 10} ${FCV.x + 10},${FCV.y - 10} ${FCV.x},${FCV.y + 10}"
      fill="#06111e" stroke="${C.pipe_water}" stroke-width="1.5"/>`;
    svg += `<polygon points="${FCV.x - 10},${FCV.y + 10} ${FCV.x + 10},${FCV.y + 10} ${FCV.x},${FCV.y - 10}"
      fill="#06111e" stroke="${C.pipe_water}" stroke-width="1.5"/>`;
    svg += `<line x1="${FCV.x}" y1="${FCV.y - 10}" x2="${FCV.x}" y2="${FCV.y - 22}"
      stroke="${C.pipe_water}" stroke-width="1.5"/>`;
    svg += `<circle cx="${FCV.x}" cy="${FCV.y - 26}" r="5" fill="#06111e"
      stroke="${C.pipe_water}" stroke-width="1.5"/>`;
    svg += `<text x="${FCV.x}" y="${FCV.y + 22}" text-anchor="middle" fill="${C.text}" font-size="8">FCV</text>`;
    svg += tipRect(FCV.x - 16, FCV.y - 16, 32, 32, `Feed Control Valve FCV  ${feedPump ? "OPEN" : "CLOSED"}  Press:${press.toFixed(1)}bar`, feedPump ? "close_feed_valve" : "open_feed_valve");

    // ── STEAM DRUM (main vessel) ──────────────────────────────────────────
    const DRX = 260 + OX, DRY = 80, DRW = 240, DRH = 140;
    // Drum body
    svg += `<rect x="${DRX}" y="${DRY}" width="${DRW}" height="${DRH}" rx="4"
      fill="#07121f" stroke="${running ? C.pipe_steam : C.off}" stroke-width="2.5"/>`;
    // Left cap
    svg += `<ellipse cx="${DRX}" cy="${DRY + DRH / 2}" rx="14" ry="${DRH / 2}"
      fill="#08182a" stroke="${running ? C.pipe_steam : C.off}" stroke-width="2"/>`;
    // Right cap
    svg += `<ellipse cx="${DRX + DRW}" cy="${DRY + DRH / 2}" rx="14" ry="${DRH / 2}"
      fill="#08182a" stroke="${running ? C.pipe_steam : C.off}" stroke-width="2"/>`;
    // Water fill (animated by level %)
    const wFill = DRH * 0.88 * (level / 100);
    const wTop = DRY + DRH - wFill - 4;
    const wCol = level < 10 ? C.alarm : level < 30 ? C.warn : C.pipe_water;
    if (wFill > 0) {
      svg += `<rect x="${DRX + 4}" y="${wTop}" width="${DRW - 8}" height="${wFill}" rx="2"
        fill="${wCol}" opacity=".14" id="${pfx}drum_water"/>`;
    }
    // Water level line
    svg += `<line x1="${DRX + 4}" y1="${wTop}" x2="${DRX + DRW - 4}" y2="${wTop}"
      stroke="${wCol}" stroke-width="1.5" stroke-dasharray="4,3" id="${pfx}drum_wline"/>`;
    // Drum labels
    svg += `<text x="${DRX + DRW / 2}" y="${DRY + DRH / 2 - 10}" text-anchor="middle"
      fill="${running ? C.pipe_steam : C.off}" font-size="12" font-weight="700">${L("steam_drum")}</text>`;
    svg += `<text x="${DRX + DRW / 2}" y="${DRY + DRH / 2 + 6}" text-anchor="middle"
      fill="${C.muted}" font-size="9">паровий барабан</text>`;
    // Steam space label
    svg += `<text x="${DRX + DRW / 2}" y="${DRY + 30}" text-anchor="middle"
      fill="${steamCol}" font-size="8" opacity=".7">~ STEAM SPACE ~</text>`;
    svg += labelPill(DRX + DRW / 2, DRY + DRH - 8, 'LEVEL: ' + level.toFixed(0) + '%', wCol, 9);

    // ── SAFETY VALVE — ISA spring-loaded SV symbol ─────────────────────
    const SVX = DRX + DRW * 0.65, SVY = DRY;
    svg += `<line x1="${SVX}" y1="${SVY - 40}" x2="${SVX}" y2="${SVY}" stroke="${safetyV ? C.alarm : C.muted}" stroke-width="2"/>`;
    svg += safetyValveSym(SVX, SVY - 40, safetyV, `${pfx}sv`);
    if (safetyV) {
      svg += `<text x="${SVX + 30}" y="${SVY - 60}" fill="${C.alarm}" font-size="9" font-weight="700">⚠ OPEN</text>`;
    }

    // Pressure gauge on drum top
    const PGX = DRX + DRW * 0.35, PGY = DRY;
    svg += `<line x1="${PGX}" y1="${PGY - 28}" x2="${PGX}" y2="${PGY}" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<circle cx="${PGX}" cy="${PGY - 38}" r="10" fill="#06111e" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<text x="${PGX}" y="${PGY - 34}" text-anchor="middle" fill="${C.pipe_steam}" font-size="7" font-weight="700">PI</text>`;
    svg += `<text x="${PGX}" y="${PGY - 50}" text-anchor="middle" fill="${C.pipe_steam}" font-size="9">${press.toFixed(1)}</text>`;
    svg += `<text x="${PGX}" y="${PGY - 41}" text-anchor="middle" fill="${C.muted}" font-size="7">bar</text>`;

    // Level gauge glass (right side of drum)
    const LGX = DRX + DRW + 18, LGY1 = DRY + 36, LGY2 = DRY + DRH * 0.85; // Опустили стекло ниже паровой трубы
    svg += `<line x1="${LGX}" y1="${LGY1}" x2="${DRX + DRW + 14}" y2="${LGY1}" stroke="${wCol}" stroke-width="1.5"/>`;
    svg += `<line x1="${LGX}" y1="${LGY2}" x2="${DRX + DRW + 14}" y2="${LGY2}" stroke="${wCol}" stroke-width="1.5"/>`;
    svg += `<rect x="${LGX}" y="${LGY1}" width="10" height="${LGY2 - LGY1}" rx="2"
      fill="#06111e" stroke="${wCol}" stroke-width="1.5"/>`;
    const LFill = (LGY2 - LGY1) * (level / 100);
    svg += `<rect x="${LGX + 1}" y="${LGY2 - LFill}" width="8" height="${LFill}" rx="1"
      fill="${wCol}" opacity=".5" id="${pfx}lg_fill"/>`;
    svg += `<text x="${LGX + 5}" y="${LGY2 + 12}" text-anchor="middle" fill="${wCol}" font-size="7">LG</text>`;


    // ── STEAM MAIN: exits drum top-right, well above level gauge (LGX=DRX+DRW+18)
    // Route: vertical riser from drum top → horizontal steam main → stop valve → consumers
    const SMX_DRUM = DRX + DRW * 0.72;       // exit point on drum top (right of centre)
    const SMY      = DRY - 22;                // 22px above drum top — clear of level gauge
    const SMX_END  = DRX + DRW + 120;
    svg += pipe(SMX_DRUM, DRY, SMX_DRUM, SMY, C.pipe_steam, "steam_riser", steamFlow);
    svg += pipe(SMX_DRUM, SMY, SMX_END, SMY, C.pipe_steam, "steam_main", steamFlow);

    // Steam stop valve
    const SSTV = { x: DRX + DRW + 60, y: SMY };
    svg += `<polygon points="${SSTV.x - 9},${SSTV.y - 9} ${SSTV.x + 9},${SSTV.y - 9} ${SSTV.x},${SSTV.y + 9}"
      fill="${steamFlow ? '#06111e' : '#030a12'}" stroke="${steamFlow ? C.pipe_steam : C.muted}" stroke-width="1.5"/>` ;
    svg += `<polygon points="${SSTV.x - 9},${SSTV.y + 9} ${SSTV.x + 9},${SSTV.y + 9} ${SSTV.x},${SSTV.y - 9}"
      fill="${steamFlow ? '#06111e' : '#030a12'}" stroke="${steamFlow ? C.pipe_steam : C.muted}" stroke-width="1.5"/>` ;
    svg += `<text x="${SSTV.x + 18}" y="${SMY - 18}" fill="${steamFlow ? C.pipe_steam : C.muted}"
      font-size="10" font-weight="700">⯈ STEAM CONSUMERS</text>`;
    svg += `<text x="${SSTV.x + 18}" y="${SMY - 6}" fill="${C.muted}" font-size="8">до споживачів</text>`;
    // ── CONDENSATE RETURN: T-junction on steam main, drops to FW tank ──
    // T-junction point: midway along the steam main (not at the right edge)
    const COND_X = SMX_DRUM + (SMX_END - SMX_DRUM) * 0.45;  // ~45% along steam main
    const COND_LOW_Y = FWT.y + FWT.h + 30;
    const COND_TANK_X = FWT.x + FWT.w / 2;
    // T-junction dot on steam main
    svg += `<circle cx="${COND_X}" cy="${SMY}" r="4" fill="${steamFlow ? C.pipe_steam : C.muted}" opacity=".8"/>`;
    // Vertical drop from T-junction down to routing line
    svg += pipe(COND_X, SMY, COND_X, COND_LOW_Y, C.pipe_water, "cond_ret_v", steamFlow);
    // Horizontal routing below FW tank
    svg += pipe(COND_X, COND_LOW_Y, COND_TANK_X, COND_LOW_Y, C.pipe_water, "cond_ret_h", steamFlow);
    // Vertical up into FW tank
    svg += pipe(COND_TANK_X, COND_LOW_Y, COND_TANK_X, FWT.y + FWT.h, C.pipe_water, "cond_ret_up", steamFlow);
    svg += `<circle cx="${COND_TANK_X}" cy="${FWT.y + FWT.h}" r="4" fill="${C.pipe_water}" opacity=".7"/>`;
    // Label at T-junction
    svg += `<text x="${COND_X}" y="${SMY + 18}" fill="${steamFlow ? C.pipe_water : C.muted}" font-size="8" text-anchor="middle">↓COND</text>`;

    // ── FEED WATER IN (left side of drum) ────────────────────────────────
    const FWX = DRX, FWY = DRY + DRH * 0.75;
    svg += pipe(FCV.x + 12, FCV.y, FCV.x + 60, FCV.y, C.pipe_water, "fcv_drum_h", feedFlow);
    svg += elbowH(FCV.x + 60, FCV.y, FCV.x + 60, FWY, C.pipe_water, "fcv_drum_v", feedFlow);
    svg += pipe(FCV.x + 60, FWY, FWX - 14, FWY, C.pipe_water, "fw_drum_in", feedFlow);
    // Non-return valve on feed line
    svg += `<polygon points="${FCV.x + 80},${FWY - 8} ${FCV.x + 80},${FWY + 8} ${FCV.x + 96},${FWY}"
      fill="#06111e" stroke="${C.pipe_water}" stroke-width="1.5"/>`;
    svg += `<line x1="${FCV.x + 96}" y1="${FWY - 8}" x2="${FCV.x + 96}" y2="${FWY + 8}"
      stroke="${C.pipe_water}" stroke-width="2"/>`;

    // ── FURNACE + BURNER ──────────────────────────────────────────────────
    const FNX = DRX + 20, FNY = DRY + DRH + 8, FNW = DRW - 40, FNH = 80;
    const burnerCol = burnerLO ? C.alarm : flameOn ? C.warn : C.off;
    // Furnace refractory brick pattern
    svg += `<rect x="${FNX}" y="${FNY}" width="${FNW}" height="${FNH}" rx="2"
      fill="#050d18" stroke="${burnerCol}" stroke-width="2"/>`;
    // Brick pattern inside furnace
    for (let bx = 0; bx < 8; bx++) {
      for (let by = 0; by < 3; by++) {
        const bw = FNW / 8, bh = FNH / 3;
        svg += `<rect x="${FNX + bx * bw + 1}" y="${FNY + by * bh + 1}" width="${bw - 2}" height="${bh - 2}" rx="1"
          fill="none" stroke="${burnerLO ? "#3a0808" : "#0c1a2a"}" stroke-width=".5"/>`;
      }
    }
    // Flame / burner visualization — static cones (no SMIL animation)
    if (flameOn && !burnerLO) {
      for (let i = 0; i < 4; i++) {
        const fx = FNX + FNW * 0.15 + i * (FNW * 0.22);
        svg += `<path d="M${fx},${FNY + FNH - 5} Q${fx + 8},${FNY + FNH * 0.4} ${fx + 12},${FNY + 10}"
          fill="none" stroke="#ff8800" stroke-width="3" opacity=".7"/>`;
        svg += `<path d="M${fx + 4},${FNY + FNH - 5} Q${fx + 12},${FNY + FNH * 0.45} ${fx + 16},${FNY + 18}"
          fill="none" stroke="#ffcc00" stroke-width="2" opacity=".5"/>`;
      }
    }
    if (burnerLO) {
      svg += `<text x="${FNX + FNW / 2}" y="${FNY + FNH / 2 + 4}" text-anchor="middle"
        fill="${C.alarm}" font-size="11" font-weight="700">⚠ LOCKED OUT</text>`;
      svg += `<text x="${FNX + FNW / 2}" y="${FNY + FNH / 2 + 18}" text-anchor="middle"
        fill="${C.alarm}" font-size="9">PURGE REQUIRED / продути топку</text>`;
    } else if (!flameOn) {
      svg += `<text x="${FNX + FNW / 2}" y="${FNY + FNH / 2 + 4}" text-anchor="middle"
        fill="${C.off}" font-size="10">BURNER OFF</text>`;
    }
    // Furnace label
    svg += `<text x="${FNX + FNW / 2}" y="${FNY + FNH + 14}" text-anchor="middle"
      fill="${C.text}" font-size="9">${L("furnace")} / топка</text>`;

    // ── FLUE GAS UPTAKE (left side, goes up) ─────────────────────────────
    const FLX = DRX - 30, FLY1 = DRY + DRH, FLY2 = DRY + DRH - 60;
    svg += `<rect x="${FLX - 10}" y="${FLY2}" width="20" height="${DRH + 8 + FNH + 8}" rx="2"
      fill="none" stroke="${flameOn ? "#7a6a3a" : C.muted}" stroke-width="1.5" stroke-dasharray="3,3"/>`;
    svg += `<line x1="${FLX}" y1="${FLY2}" x2="${FLX}" y2="${FLY2 - 35}"
      stroke="${flameOn ? "#7a6a3a" : C.muted}" stroke-width="2"/>`;
    // Chimney symbol
    svg += `<polygon points="${FLX - 8},${FLY2 - 35} ${FLX + 8},${FLY2 - 35} ${FLX + 5},${FLY2 - 55} ${FLX - 5},${FLY2 - 55}"
      fill="#06111e" stroke="${flameOn ? C.pipe_air : C.muted}" stroke-width="1.5"/>`;
    svg += `<text x="${FLX}" y="${FLY2 - 58}" text-anchor="middle"
      fill="${flameOn ? C.pipe_air : C.muted}" font-size="8">▲ FLUE</text>`;
    // Temperature indicator on flue
    const TIX = FLX + 18, TIY = DRY + 35;
    svg += `<line x1="${FLX + 10}" y1="${TIY}" x2="${TIX}" y2="${TIY}" stroke="${C.muted}" stroke-width="1"/>`;
    svg += `<circle cx="${TIX + 8}" cy="${TIY}" r="8" fill="#06111e" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<text x="${TIX + 8}" y="${TIY + 4}" text-anchor="middle" fill="${C.pipe_steam}" font-size="7" font-weight="700">TI</text>`;
    svg += `<text x="${TIX + 20}" y="${TIY + 4}" fill="${C.pipe_steam}" font-size="9">${flueT.toFixed(0)}°</text>`;

    // FIX: Fuel line runs WAY BELOW furnace and FW Tank (Y=395)
    const FUX1 = 22, FUY = 395; // Жестко опустили на самый низ экрана
    const riserX = FNX + 28; // Координата горелки

    // Сплошная труба с закруглением прямо в топку
    svg += elbowH(FUX1, FUY, riserX, FNY + FNH, C.pipe_fuel, "fuel_line", flameOn && fuelOpen);

    // Фильтр STR
    svg += `<rect x="${FUX1 + 40}" y="${FUY - 8}" width="18" height="16" rx="2"
      fill="#06111e" stroke="${C.pipe_fuel}" stroke-width="1.5"/>`;
    svg += `<text x="${FUX1 + 49}" y="${FUY + 4}" text-anchor="middle" fill="${C.pipe_fuel}" font-size="7">STR</text>`;

    // Клапан FV-1 (Переехал вниз вместе с трубой)
    const FVX = FUX1 + 100, FVY = FUY;
    svg += `<polygon points="${FVX - 9},${FVY - 9} ${FVX + 9},${FVY - 9} ${FVX},${FVY + 9}"
      fill="${fuelOpen ? "#0a1e10" : "#06111e"}" stroke="${fuelOpen ? C.on : C.alarm}" stroke-width="1.5"/>`;
    svg += `<polygon points="${FVX - 9},${FVY + 9} ${FVX + 9},${FVY + 9} ${FVX},${FVY - 9}"
      fill="${fuelOpen ? "#0a1e10" : "#06111e"}" stroke="${fuelOpen ? C.on : C.alarm}" stroke-width="1.5"/>`;
    svg += `<line x1="${FVX}" y1="${FVY - 9}" x2="${FVX}" y2="${FVY - 20}"
      stroke="${fuelOpen ? C.on : C.alarm}" stroke-width="1.5"/>`;
    svg += `<text x="${FVX}" y="${FVY + 20}" text-anchor="middle"
      fill="${fuelOpen ? C.on : C.alarm}" font-size="8">FV-1</text>`;

    // Тексты HFO
    svg += `<text x="${FUX1 - 2}" y="${FUY - 12}" fill="${C.pipe_fuel}" font-size="9" font-weight="600">HFO ⯈</text>`;
    svg += `<text x="${FUX1 - 2}" y="${FUY + 18}" fill="${C.muted}" font-size="8">важке паливо</text>`;

    // ── STEAM CONNECTIONS FROM DRUM ───────────────────────────────────────
    // Saturated steam riser lines (inside drum - symbolic)
    for (let i = 0; i < 5; i++) {
      const rx = DRX + 20 + i * (DRW - 40) / 4;
      svg += `<line x1="${rx}" y1="${wTop + 5}" x2="${rx}" y2="${DRY + 24}"
        stroke="${steamCol}" stroke-width="1" opacity=".3" stroke-dasharray="2,2"/>`;
    }

    // ═══════════════════════════════════════════════════════════════
    // INSTRUMENT PANEL (right side)
    // ═══════════════════════════════════════════════════════════════
    svg += divider(PD, 22, H - 5);
    const PW = W - PD - 8;
    const PL = PD + 5;
    const pCol = press > 8 ? C.alarm : press > 7.5 ? C.warn : C.on;
    const lCol = level < 10 ? C.alarm : level < 30 ? C.warn : C.on;
    const tCol = flueT > 380 ? C.alarm : C.on;

    svg += `<text x="${PD + PW / 2}" y="18" text-anchor="middle" fill="${C.pipe_steam}"
      font-size="10" font-weight="700" letter-spacing="1">BOILER INSTRUMENTS</text>`;

    // Row 1: Pressure gauge + Water level digital — side by side
    const halfW = (PW - 8) / 2;
    svg += panelBox(PL, 24, halfW, 110, "PRESSURE");
    svg += gauge(PL + halfW / 2, 75, 24, press, 0, 10, "", "", `${pfx}press`, 7.5, 8.5);

    svg += panelBox(PL + halfW + 4, 24, halfW, 110, "WATER LEVEL");
    // Vertical level bar inside its box — starts below header (y=44) to y=112
    const lvlX = PL + halfW + 4 + halfW / 2;
    const lvlY1 = 44, lvlY2 = 112;
    const lvlH = lvlY2 - lvlY1, lvlFill = lvlH * (level / 100);
    svg += `<rect x="${lvlX - 10}" y="${lvlY1}" width="20" height="${lvlH}" rx="2"
      fill="#030a12" stroke="${lCol}" stroke-width="1.5"/>`;
    svg += `<rect x="${lvlX - 9}" y="${lvlY2 - lvlFill}" width="18" height="${lvlFill}" rx="1"
      fill="${lCol}" opacity=".5"/>`;
    // Scale marks
    for (let p = 0; p <= 100; p += 25) {
      const my = lvlY2 - lvlH * (p / 100);
      svg += `<line x1="${lvlX + 11}" y1="${my}" x2="${lvlX + 15}" y2="${my}" stroke="${C.muted}" stroke-width="1"/>`;
      svg += `<text x="${lvlX + 17}" y="${my + 3}" fill="${C.muted}" font-size="7">${p}%</text>`;
    }
    svg += `<text x="${lvlX - 2}" y="${lvlY2 + 12}" text-anchor="middle"
      fill="${lCol}" font-size="10" font-weight="700">${level.toFixed(0)}%</text>`;

    // Row 2: Flue temp
    let py = 141;
    svg += panelBox(PL, py, PW - 2, 38, "FLUE GAS TEMP");
    svg += digDisplay(PL + 6, py + 18, 65, 18, flueT, "°C", "", `${pfx}flue`, tCol);
    const tBarW = Math.min(1, flueT / 500) * (PW - 82);
    svg += `<rect x="${PL + 76}" y="${py + 18}" width="${PW - 82}" height="18" rx="2"
      fill="#030a12" stroke="${C.panelBdr}" stroke-width="1"/>`;
    svg += `<rect x="${PL + 76}" y="${py + 18}" width="${tBarW}" height="18" rx="2"
      fill="${tCol}" opacity=".6"/>`;
    svg += `<text x="${PL + 76 + tBarW / 2 + 2}" y="${py + 31}" fill="${tCol}" font-size="8"
      font-weight="700">${flueT.toFixed(0)}°C</text>`;

    // Row 3: Burner status
    py = 185;
    svg += panelBox(PL, py, PW - 2, 40, "BURNER STATUS");
    if (burnerLO) {
      svg += `<rect x="${PL + 8}" y="${py + 20}" width="${PW - 18}" height="16" rx="2"
        fill="${C.alarm}" opacity=".15" stroke="${C.alarm}" stroke-width="1"/>`;
      svg += `<text x="${PD + PW / 2}" y="${py + 32}" text-anchor="middle"
        fill="${C.alarm}" font-size="9" font-weight="700">⚠ LOCKED OUT</text>`;
    } else {
      const bCol = flameOn ? C.warn : C.muted;
      svg += `<circle cx="${PL + 18}" cy="${py + 31}" r="7" fill="${flameOn ? "#2a1500" : "#06111e"}"
        stroke="${bCol}" stroke-width="1.5"/>`;
      svg += `<text x="${PL + 18}" y="${py + 34}" text-anchor="middle" fill="${bCol}" font-size="8">
        ${flameOn ? "🔥" : "○"}</text>`;
      svg += `<text x="${PL + 33}" y="${py + 34}" fill="${bCol}" font-size="10" font-weight="700">
        ${flameOn ? "FIRING" : L("BURNER OFF")}</text>`;
    }

    // Row 4: Status LEDs
    py = 231;
    svg += panelBox(PL, py, PW - 2, 100, "SYSTEM STATUS");
    const statItems = [
      { label: "Boiler Running", on: running, fault: false },
      { label: "Flame ON", on: flameOn, fault: false },
      { label: "Fuel Valve Open", on: fuelOpen, fault: false },
      { label: "Feed Pump 1", on: feedPump, fault: false },
      { label: "Feed Pump 2 (SBY)", on: feedPump2, fault: false },
      { label: "Safety Valve", on: safetyV, fault: true },
      { label: "Burner Lockout", on: burnerLO, fault: true },
    ];
    statItems.forEach((it, i) => {
      const col = it.fault ? (it.on ? C.alarm : C_INACTIVE_LED) : (it.on ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PL + 10}" cy="${py + 20 + i * 11}" r="3.5" fill="${col}" ${it.on && it.fault ? 'filter="url(#glow_s)"' : ""}/>`;
      svg += `<text x="${PL + 19}" y="${py + 24 + i * 11}" fill="${it.on ? C.textHi : C_INACTIVE_TEXT}" font-size="8">${it.label}</text>`;
    });

    // Row 5: Alerts
    py = 338;
    svg += panelBox(PL, py, PW - 2, 50, "ALARMS");
    const alerts = [];
    if (press > 8.0) alerts.push({ txt: "HIGH PRESSURE", col: C.alarm });
    if (press < 5.5 && running) alerts.push({ txt: "LOW PRESSURE", col: C.warn });
    if (level < 30) alerts.push({ txt: "LOW WATER LEVEL", col: C.alarm });
    if (safetyV) alerts.push({ txt: "SAFETY VALVE OPEN", col: C.alarm });
    if (burnerLO) alerts.push({ txt: "BURNER LOCKED OUT", col: C.alarm });
    if (!flameOn && running && !burnerLO) alerts.push({ txt: "FLAME FAILURE", col: C.alarm });
    if (alerts.length === 0) {
      svg += `<text x="${PD + PW / 2}" y="${py + 36}" text-anchor="middle" fill="${C.on}" font-size="9">✓ ALL NORMAL</text>`;
    } else {
      alerts.slice(0, 3).forEach((a, i) => {
        svg += `<text x="${PL + 8}" y="${py + 28 + i * 12}" fill="${a.col}" font-size="8" font-weight="700">⚑ ${a.txt}</text>`;
      });
    }

    svg += legend(PD, H, [
      { color: C.pipe_water, label: "Feed Water / Живильна вода" },
      { color: C.pipe_steam, label: "Steam / Пара" },
      { color: C.pipe_fuel, label: "Fuel / Паливо" },
    ]);
    svg += `</svg>`;
    return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  GENERIC FALLBACK (Labs 3–10 until dedicated renderers are built)
  //  Uses the existing JSON schematic data but styled much better
  // ════════════════════════════════════════════════════════════════════════

  function renderGeneric(W, H, st, labDef, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const sch = labDef?.schematic || { nodes: [], pipes: [] };
    const PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);

    const title = labDef?.title_en || "System";
    svg += `<text x="12" y="18" fill="${C.cyan}" font-size="12" font-weight="700" opacity=".7">${title.toUpperCase()}</text>`;

    // Pipe colour heuristic
    function pipeColor(fromId, toId, type) {
      if (type === "signal") return C.pipe_elec;
      if (type === "power") return C.pipe_elec;
      const all = (fromId + " " + toId).toLowerCase();
      if (all.includes("steam") || all.includes("boil")) return C.pipe_steam;
      if (all.includes("fuel") || all.includes("oil")) return C.pipe_fuel;
      if (all.includes("ref") || all.includes("comp") || all.includes("cond") || all.includes("evap")) return C.pipe_ref;
      if (all.includes("hyd") || all.includes("ram")) return C.pipe_hyd;
      return C.pipe_water;
    }

    // Map nodes to scaled positions (use 95% of left panel)
    const nodeMap = {};
    sch.nodes.forEach(n => {
      nodeMap[n.id] = { x: n.x / 100 * PD * 0.95 + 10, y: n.y / 100 * (H - 30) + 20 };
    });

    function resolveState(key) {
      if (!key) return undefined;
      const v = s[key];
      return v;
    }

    function nodeColor(n) {
      const ns = sch.node_states?.[n.id];
      if (!ns || ns.type === "source") return C.pipe_water;
      const val = resolveState(ns.state_key);
      const mode = ns.mode;
      if (mode === "bool") return (val === true || val === 1) ? C.on : C.off;
      if (mode === "valve") return val === true ? C.on : C.alarm;
      if (mode === "valve_inv") return val === false ? C.on : C.off;
      if (mode === "pump_obj") {
        return val === "RUNNING" ? C.on : val === "TRIPPED" || val === "FAULT" ? C.alarm : C.off;
      }
      if (typeof val === "number") {
        return val > 0.6 ? C.on : val > 0.3 ? C.warn : C.alarm;
      }
      return C.pipe_water;
    }

    // Draw pipes
    const flowVal = s[sch.flow_key];
    const flowing = typeof flowVal === "number" ? flowVal > (sch.flow_threshold || 0.5)
      : typeof flowVal === "boolean" ? flowVal : false;

    sch.pipes.forEach((p, i) => {
      const f = nodeMap[p.from], t = nodeMap[p.to];
      if (!f || !t) return;
      const col = pipeColor(p.from, p.to, p.type);
      svg += pipe(f.x, f.y, t.x, t.y, col, `${pfx}gp_${i}`, flowing && p.type !== "signal");
    });

    // Draw nodes
    sch.nodes.forEach(n => {
      const p = nodeMap[n.id];
      const col = nodeColor(n);
      const isRound = ["pump", "separator", "sensor", "engine", "motor"].includes(n.type);
      const r = 20;

      if (isRound) {
        svg += `<circle cx="${p.x}" cy="${p.y}" r="${r}" fill="#0c1a2e"
          stroke="${col}" stroke-width="2" filter="${col === C.on ? 'url(#glow_s)' : ''}"/>`;
      } else if (n.type === "valve") {
        const pts = `${p.x - 12},${p.y - 12} ${p.x + 12},${p.y - 12} ${p.x},${p.y + 12}`;
        const pts2 = `${p.x - 12},${p.y + 12} ${p.x + 12},${p.y + 12} ${p.x},${p.y - 12}`;
        svg += `<polygon points="${pts}" fill="#0a1828" stroke="${col}" stroke-width="2"/>
                <polygon points="${pts2}" fill="#0a1828" stroke="${col}" stroke-width="2"/>`;
      } else if (["tank", "boiler", "cooler", "drum", "vessel"].includes(n.type)) {
        svg += vessel(p.x - 32, p.y - 22, 64, 44, n.label, col);
      } else {
        svg += `<rect x="${p.x - 24}" y="${p.y - 16}" width="48" height="32" rx="4"
          fill="#0c1a2e" stroke="${col}" stroke-width="2"/>`;
      }

      // Icon
      const icons = {
        pump: "P", separator: "S", sensor: "M", engine: "⚙",
        valve: "V", heater: "H", cooler: "≋", burner: "🔥",
        breaker: "CB", busbar: "BUS", load: "kW", tank: "T"
      };
      if (isRound) {
        svg += `<text x="${p.x}" y="${p.y + 1}" text-anchor="middle" dominant-baseline="central"
          fill="${col}" font-size="12" font-weight="700">${icons[n.type] || "?"}</text>`;
      }
      // Label
      if (!["tank", "vessel", "drum", "boiler", "cooler"].includes(n.type)) {
        svg += `<text x="${p.x}" y="${p.y + (isRound ? r + 12 : 28)}" text-anchor="middle"
          fill="${C.text}" font-size="9">${n.label}</text>`;
      }
    });

    // DIVIDER
    svg += divider(PD, 25, H - 25);

    // GAUGES panel (right)
    const PW = W - PD - 10;
    svg += `<text x="${PD + PW / 2}" y="20" text-anchor="middle" fill="${C.cyan}" font-size="11" font-weight="700">INSTRUMENTS</text>`;

    const gauges = labDef?.gauges || [];
    const gaugeH = Math.min(90, Math.floor((H - 30) / Math.max(1, gauges.length)));
    const gaugeR = Math.min(32, Math.floor(gaugeH * 0.38));

    gauges.forEach((g, i) => {
      const val = typeof s[g.id] === "number" ? s[g.id] : 0;
      const cy = 30 + gaugeH * i + gaugeH / 2;
      const cx = PD + PW / 2;
      svg += panelBox(PD + 8, 26 + gaugeH * i, PW - 14, gaugeH - 4, g.label || g.id);
      svg += gauge(cx, cy + 8, gaugeR, val, g.min || 0, g.max || 100, g.unit || "",
        "", `${pfx}gg_${g.id}`, g.warn_high, g.crit_high);
    });

    svg += `</svg>`;
    return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  REFRIGERATION (Lab 4)
  // ════════════════════════════════════════════════════════════════════════

  function renderRefrig(W, H, st, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const compRun = !!s.compressor_running;
    const condFoul = s.condenser_condition !== undefined ? s.condenser_condition < 0.8 : false;
    const refLeak = !!s.refrigerant_leak;
    const suctP = typeof s.suction_pressure_bar === "number" ? s.suction_pressure_bar : 2.8;
    const condP = typeof s.condenser_pressure_bar === "number" ? s.condenser_pressure_bar : 12;
    const discT = typeof s.discharge_temp_c === "number" ? s.discharge_temp_c : 85;
    const evapT = typeof s.evap_temp_c === "number" ? s.evap_temp_c : -5;
    const coolKW = typeof s.cooling_kw === "number" ? s.cooling_kw : 45;
    const charge = typeof s.refrigerant_charge_pct === "number" ? s.refrigerant_charge_pct : 100;
    const flowing = compRun;
    const PD = W - 220;

    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<text x="12" y="18" fill="${C.pipe_ref}" font-size="12" font-weight="700" opacity=".7">
      REFRIGERATION PLANT R22  /  ХОЛОДИЛЬНА УСТАНОВКА</text>`;

    // Vapour-compression cycle layout:
    // COMPRESSOR (left) → CONDENSER (top) → EXP.VALVE (right) → EVAPORATOR (bottom) → back to COMPRESSOR

    // Vapour-compression cycle layout — spread elements to fill the full height
    const CX = 130, CY = 260;  // Compressor — moved down
    const KX = 330, KY = 120;  // Condenser
    const EX = 510, EY = 260;  // Expansion valve — moved down
    const EV = 330, EVY = 380; // Evaporator — moved down

    // Pipes (refrigerant cycle — high/low pressure)
    // Coordinates:
    //   CX,CY = 130,260  (Compressor centre, radius 30)
    //   KX,KY = 330,120  (Condenser centre, box ±40 wide ±22 tall)
    //   EX,EY = 510,260  (Expansion valve centre)
    //   EV,EVY= 330,380  (Evaporator centre, box ±40 wide ±22 tall)

    // ── REFRIGERANT CYCLE — proper corner connections ──────────────────────
    // Layout (all coords relative to centres):
    //   CX,CY=130,260 (Comp, r=30)  KX,KY=330,120 (Cond, ±40w ±22h)
    //   EX,EY=510,260 (ExpValve)    EV,EVY=330,380 (Evap, ±40w ±22h)
    //
    //        ┌──────────[COND]──────────┐
    //        │          KY-22           │
    //     CX,KY-22                   EX,KY-22
    //        │                          │
    //     [COMP]                    [EXP.V]
    //        │                          │
    //     CX,EVY+22                 EX,EVY+22
    //        │                          │
    //        └──────────[EVAP]──────────┘
    //                  EVY+22

    // ── LAYOUT CONSTANTS ────────────────────────────────────────────────────
    // HP rail = top of condenser; LP rail = bottom of evaporator
    const pipeY_top = KY - 22;    // y=98  — top horizontal rail
    const pipeY_bot = EVY + 22;   // y=402 — bottom horizontal rail

    // ── DRAW THE COMPLETE CLOSED CYCLE AS SVG PATHS ───────────────────────
    // This avoids broken corners from separate pipe() segments.
    // HP path:  Comp top → corner TL → across top → corner TR → Exp valve top
    // LP path:  Exp valve bottom → corner BR → across bottom → corner BL → Comp bottom

    // HP (high pressure, hot) = alarm/red; LP (low pressure, cold) = ref/teal — ISO standard
    function refPathHP(d, id) {
      return `<path d="${d}" fill="none" stroke="#000" stroke-width="7" stroke-opacity=".35" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="${d}" fill="none" stroke="${C.alarm}" stroke-width="5" stroke-opacity=".25" stroke-linecap="round" stroke-linejoin="round"/>
        <path id="fp_${id}" d="${d}" fill="none" stroke="${C.alarm}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"
          stroke-dasharray="9,11" opacity="${flowing ? .85 : .35}" class="scada-flow">
          ${flowing ? '<animate attributeName="stroke-dashoffset" from="0" to="-20" dur=".7s" repeatCount="indefinite"/>' : ''}
        </path>`;
    }
    function refPathLP(d, id) {
      return `<path d="${d}" fill="none" stroke="#000" stroke-width="7" stroke-opacity=".35" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="${d}" fill="none" stroke="${C.pipe_ref}" stroke-width="5" stroke-opacity=".25" stroke-linecap="round" stroke-linejoin="round"/>
        <path id="fp_${id}" d="${d}" fill="none" stroke="${C.pipe_ref}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"
          stroke-dasharray="9,11" opacity="${flowing ? .9 : .45}" class="scada-flow">
          ${flowing ? '<animate attributeName="stroke-dashoffset" from="0" to="-20" dur=".9s" repeatCount="indefinite"/>' : ''}
        </path>`;
    }

    // HP: Compressor top → up → left rail → across → right rail → down → Exp valve top
    svg += refPathHP(
      `M${CX},${CY - 30} L${CX},${pipeY_top} L${KX - 40},${pipeY_top}`,
      "hp_left"
    );
    svg += refPathHP(
      `M${KX + 40},${pipeY_top} L${EX},${pipeY_top} L${EX},${EY - 12}`,
      "hp_right"
    );

    // LP: Exp valve bottom → down → right rail → across bottom → left rail → up → Comp bottom
    svg += refPathLP(
      `M${EX},${EY + 12} L${EX},${pipeY_bot} L${EV + 40},${pipeY_bot}`,
      "lp_right"
    );
    svg += refPathLP(
      `M${EV - 40},${pipeY_bot} L${CX},${pipeY_bot} L${CX},${CY + 30}`,
      "lp_left"
    );

    // Sea water cooling (to condenser)
    svg += pipe(KX, KY - 42, KX, KY - 22, C.pipe_water, "sw_cond", compRun);
    svg += `<text x="${KX + 8}" y="${KY - 30}" fill="${C.pipe_water}" font-size="9">▼ SW COOLING</text>`;

    // COMPRESSOR — ISA symbol (circle + triangle)
    svg += compressorSym(CX, CY, 36, compRun, "COMP\nкомпресор");
    svg += led(CX + 38, CY - 38, compRun, `${pfx}comp_led`);

    // CONDENSER
    const condCol = condFoul ? C.alarm : condP > 18 ? C.warn : C.on;
    svg += `<rect x="${KX - 44}" y="${KY - 24}" width="88" height="48" rx="6"
      fill="#08162a" stroke="${condCol}" stroke-width="2"/>`;
    // Tube symbol
    for (let i = 0; i < 6; i++) {
      svg += `<line x1="${KX - 34 + i * 14}" y1="${KY - 16}" x2="${KX - 34 + i * 14}" y2="${KY + 16}"
        stroke="${condCol}" stroke-width="1.5" opacity=".6"/>`;
    }
    svg += `<text x="${KX}" y="${KY + 32}" text-anchor="middle" fill="${C.text}" font-size="9">${L("condenser")}</text>`;
    svg += tipRect(KX - 40, KY - 30, 80, 56, `Condenser  Press:${condP.toFixed(1)}bar  ${condFoul ? "FOULED" : "OK"}`, condFoul ? "check_condenser" : null);
    svg += `<text x="${KX}" y="${KY + 43}" text-anchor="middle" fill="${C.muted}" font-size="8">конденсатор</text>`;

    // EXPANSION VALVE
    const expPts = `${EX - 10},${EY - 10} ${EX + 10},${EY - 10} ${EX},${EY + 10}`;
    const expPts2 = `${EX - 10},${EY + 10} ${EX + 10},${EY + 10} ${EX},${EY - 10}`;
    svg += `<polygon points="${expPts}" fill="#08162a" stroke="${C.on}" stroke-width="2"/>
      <polygon points="${expPts2}" fill="#08162a" stroke="${C.on}" stroke-width="2"/>
      <circle cx="${EX}" cy="${EY}" r="3" fill="${C.on}"/>`;
    svg += `<text x="${EX}" y="${EY + 24}" text-anchor="middle" fill="${C.text}" font-size="9">${L("exp_valve")}</text>`;

    // EVAPORATOR
    const evapCol = evapT > 0 ? C.warn : C.pipe_ref;
    svg += `<rect x="${EV - 44}" y="${EVY - 24}" width="88" height="48" rx="6"
      fill="#08162a" stroke="${evapCol}" stroke-width="2"/>`;
    for (let i = 0; i < 6; i++) {
      svg += `<line x1="${EV - 34 + i * 14}" y1="${EVY - 16}" x2="${EV - 34 + i * 14}" y2="${EVY + 16}"
        stroke="${evapCol}" stroke-width="1.5" opacity=".6"/>`;
    }
    svg += `<text x="${EV}" y="${EVY + 32}" text-anchor="middle" fill="${C.text}" font-size="9">${L("evaporator")}</text>`;
    svg += tipRect(EV - 40, EVY - 30, 80, 56, `Evaporator  EvapT:${evapT.toFixed(1)}°C  CoolOut:${coolKW.toFixed(0)}kW  Charge:${charge.toFixed(0)}%`);
    svg += `<text x="${EV}" y="${EVY + 43}" text-anchor="middle" fill="${C.muted}" font-size="8">випарник</text>`;

    // Refrigerant leak indicator
    if (refLeak) {
      svg += `<text x="${CX + 50}" y="${CY + 50}" fill="${C.alarm}" font-size="10" font-weight="700">⚠ LEAK!</text>`;
    }

    // Charge bar (bottom)
    const chargeCol = charge < 60 ? C.alarm : charge < 80 ? C.warn : C.on;
    svg += `<text x="60" y="${H - 38}" fill="${C.text}" font-size="9">REFRIGERANT CHARGE: <tspan fill="${chargeCol}" font-weight="700">${charge.toFixed(0)}%</tspan></text>`;
    svg += `<rect x="60" y="${H - 30}" width="480" height="12" rx="3" fill="#0a1020" stroke="${C.panelBdr}" stroke-width="1"/>`;
    svg += `<rect x="60" y="${H - 30}" width="${480 * charge / 100}" height="12" rx="3" fill="${chargeCol}" opacity=".7" id="${pfx}charge_bar"/>`;

    // DIVIDER
    svg += divider(PD, 25, H - 25);

    // INSTRUMENTS
    const PW = W - PD - 10;
    svg += `<text x="${PD + PW / 2}" y="20" text-anchor="middle" fill="${C.pipe_ref}"
      font-size="11" font-weight="700">REFRIGERATION INSTRUMENTS</text>`;

    svg += panelBox(PD + 8, 28, PW / 2 - 6, 80, "SUCT");
    svg += gauge(PD + 8 + (PW / 2 - 6) / 2, 70, 20, suctP, 0, 5, "", "", `${pfx}suct`, 1.5);

    svg += panelBox(PD + PW / 2 + 2, 28, PW / 2 - 10, 80, "HEAD");
    svg += gauge(PD + PW / 2 + 2 + (PW / 2 - 10) / 2, 70, 20, condP, 0, 25, "", "", `${pfx}cond`, 18, 22);

    svg += panelBox(PD + 8, 115, PW / 2 - 6, 80, "DISCH");
    svg += gauge(PD + 8 + (PW / 2 - 6) / 2, 155, 20, discT, -30, 200, "", "", `${pfx}disc`, 120, 140);

    svg += panelBox(PD + PW / 2 + 2, 115, PW / 2 - 10, 80, "COOL");
    svg += gauge(PD + PW / 2 + 2 + (PW / 2 - 10) / 2, 155, 20, coolKW, 0, 60, "", "", `${pfx}cool`);

    svg += panelBox(PD + 8, 202, PW - 14, 50, "EVAPORATOR TEMP");
    svg += digDisplay(PD + 18, 222, PW - 30, 26, evapT, "°C", "", `${pfx}evap`, evapT > 0 ? C.warn : C.pipe_ref);

    svg += panelBox(PD + 8, 259, PW - 14, 50, "COMPRESSOR STATUS");
    svg += `<text x="${PD + PW / 2}" y="${285}" text-anchor="middle" fill="${compRun ? C.on : C.off}" font-size="13" font-weight="700">${compRun ? "● RUNNING" : "○ STOPPED"}</text>`;

    svg += panelBox(PD + 8, 316, PW - 14, 65, "ALERTS");
    const rAlerts = [];
    if (discT > 120) rAlerts.push("⚠ HIGH DISCHARGE TEMP");
    if (suctP < 1.5 && compRun) rAlerts.push("⚠ LOW SUCTION PRESSURE");
    if (condP > 18) rAlerts.push("⚠ HIGH HEAD PRESSURE");
    if (charge < 80) rAlerts.push(`⚠ LOW CHARGE ${charge.toFixed(0)}%`);
    rAlerts.forEach((a, i) => {
      svg += `<text x="${PD + 14}" y="${336 + i * 13}" fill="${C.alarm}" font-size="8">${a}</text>`;
    });
    if (!rAlerts.length) {
      svg += `<text x="${PD + PW / 2}" y="${350}" text-anchor="middle" fill="${C.on}" font-size="10">✓ ALL NORMAL</text>`;
    }

    svg += legend(PD, H, [
      { color: C.pipe_ref, label: "Refrigerant LP / Холодоагент НТ" },
      { color: C.alarm, label: "Refrigerant HP / Холодоагент ВТ" },
      { color: C.pipe_water, label: "SW Cooling / Охолодж. вода" },
    ]);
    svg += `</svg>`;
    return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  DIESEL GENERATOR (Lab 6)
  // ════════════════════════════════════════════════════════════════════════

  function renderDG(W, H, st, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const dg1Run = !!s.dg1_running;
    const dg2Run = !!s.dg2_running;
    const dg1Rpm = typeof s.dg1_rpm === "number" ? s.dg1_rpm : 0;
    const dg2Rpm = typeof s.dg2_rpm === "number" ? s.dg2_rpm : 0;
    const freq = typeof s.frequency_hz === "number" ? s.frequency_hz : 0;
    const volt = typeof s.voltage_v === "number" ? s.voltage_v : 0;
    const load = typeof s.load_kw === "number" ? s.load_kw : 0;
    const d1Load = typeof s.dg1_load_kw === "number" ? s.dg1_load_kw : 0;
    const d2Load = typeof s.dg2_load_kw === "number" ? s.dg2_load_kw : 0;
    const busLive = !!s.bus_live;
    const blackout = !!s.blackout;
    const syncRdy = !!s.dg2_sync_ready;
    const PD = W - 220;

    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<text x="12" y="18" fill="${C.pipe_elec}" font-size="12" font-weight="700" opacity=".7">
      DIESEL GENERATORS × 2  /  ДИЗЕЛЬ-ГЕНЕРАТОРИ × 2</text>`;

    // BUS BAR (horizontal, center)
    const BX = 115, BY = 250, BW = 460, BH = 24;
    const busCol = blackout ? C.alarm : busLive ? C.on : C.off;
    svg += `<rect x="${BX}" y="${BY}" width="${BW}" height="${BH}" rx="4"
      fill="${busCol}" opacity="${busLive ? .25 : .1}" stroke="${busCol}" stroke-width="2"/>`;
    svg += `<text x="${BX + BW / 2}" y="${BY + 14}" text-anchor="middle"
      fill="${busCol}" font-size="11" font-weight="700">
      ${blackout ? "⚠ BLACKOUT — BUS DEAD" : "MAIN SWITCHBOARD BUS"}</text>`;
    svg += `<text x="${BX + BW / 2}" y="${BY + 28}" text-anchor="middle"
      fill="${C.muted}" font-size="8">Головний розподільний щит</text>`;
    svg += tipRect(BX, BY, BW, BH, `Main Bus  ${blackout ? "BLACKOUT" : busLive ? "LIVE" : "DEAD"}  ${freq.toFixed(1)}Hz  ${volt.toFixed(0)}V  ${load.toFixed(0)}kW`);

    // CB1 (DG1 side)
    const CB1X = BX + 90, CB1Y = BY - 50;
    const cb1Closed = dg1Run && busLive;
    svg += `<rect x="${CB1X - 12}" y="${CB1Y}" width="24" height="32" rx="3"
      fill="${cb1Closed ? C.on : C.off}" opacity="${cb1Closed ? .3 : .1}"
      stroke="${cb1Closed ? C.on : C.off}" stroke-width="1.5"/>`;
    svg += `<text x="${CB1X}" y="${CB1Y + 20}" text-anchor="middle"
      fill="${cb1Closed ? C.on : C.off}" font-size="9" font-weight="700">CB1</text>`;
    svg += pipe(CB1X, CB1Y + 32, CB1X, BY, C.pipe_elec, "cb1_bus", cb1Closed);

    // CB2 (DG2 side)
    const CB2X = BX + BW - 90, CB2Y = BY - 50;
    const cb2Closed = dg2Run && busLive && !blackout;
    svg += `<rect x="${CB2X - 12}" y="${CB2Y}" width="24" height="32" rx="3"
      fill="${cb2Closed ? C.on : (syncRdy ? C.warn : C.off)}" opacity=".3"
      stroke="${cb2Closed ? C.on : (syncRdy ? C.warn : C.off)}" stroke-width="1.5"/>`;
    svg += `<text x="${CB2X}" y="${CB2Y + 20}" text-anchor="middle"
      fill="${cb2Closed ? C.on : (syncRdy ? C.warn : C.off)}" font-size="9" font-weight="700">CB2</text>`;
    if (syncRdy && !cb2Closed) {
      svg += `<text x="${CB2X}" y="${CB2Y - 8}" text-anchor="middle"
        fill="${C.warn}" font-size="8">SYNC ✓</text>`;
    }
    svg += pipe(CB2X, CB2Y + 32, CB2X, BY, C.pipe_elec, "cb2_bus", cb2Closed);

    // DG1
    const G1X = CB1X, G1Y = CB1Y - 90;
    svg += `<rect x="${G1X - 45}" y="${G1Y - 30}" width="90" height="60" rx="6"
      fill="#08162a" stroke="${dg1Run ? C.on : C.off}" stroke-width="2"/>`;
    svg += `<text x="${G1X}" y="${G1Y - 10}" text-anchor="middle"
      fill="${dg1Run ? C.on : C.off}" font-size="11" font-weight="700">DG - 1</text>`;
    svg += tipRect(G1X - 30, 100, 60, 90, `DG-1  ${dg1Run ? "RUNNING" : "STOPPED"}  ${dg1Rpm.toFixed(0)}RPM  ${d1Load.toFixed(0)}kW`, dg1Run ? "stop_dg1" : "start_dg1");
    svg += `<text x="${G1X}" y="${G1Y + 5}" text-anchor="middle"
      fill="${C.muted}" font-size="8">${dg1Rpm.toFixed(0)} RPM</text>`;
    svg += `<text x="${G1X}" y="${G1Y + 18}" text-anchor="middle"
      fill="${C.cyan}" font-size="9">${d1Load.toFixed(0)} kW</text>`;
    svg += pipe(G1X, G1Y + 30, G1X, CB1Y, C.pipe_elec, "dg1_cb1", dg1Run);
    svg += led(G1X + 50, G1Y - 26, dg1Run, `${pfx}dg1_led`);

    // DG2
    const G2X = CB2X, G2Y = CB2Y - 90;
    svg += `<rect x="${G2X - 45}" y="${G2Y - 30}" width="90" height="60" rx="6"
      fill="#08162a" stroke="${dg2Run ? C.on : C.off}" stroke-width="2"/>`;
    svg += `<text x="${G2X}" y="${G2Y - 10}" text-anchor="middle"
      fill="${dg2Run ? C.on : C.off}" font-size="11" font-weight="700">DG - 2</text>`;
    svg += tipRect(G2X - 30, 100, 60, 90, `DG-2  ${dg2Run ? "RUNNING" : "STOPPED"}  ${dg2Rpm.toFixed(0)}RPM  ${d2Load.toFixed(0)}kW`, dg2Run ? "stop_dg2" : "start_dg2");
    svg += `<text x="${G2X}" y="${G2Y + 5}" text-anchor="middle"
      fill="${C.muted}" font-size="8">${dg2Rpm.toFixed(0)} RPM</text>`;
    svg += `<text x="${G2X}" y="${G2Y + 18}" text-anchor="middle"
      fill="${C.cyan}" font-size="9">${d2Load.toFixed(0)} kW</text>`;
    svg += pipe(G2X, G2Y + 30, G2X, CB2Y, C.pipe_elec, "dg2_cb2", dg2Run);
    svg += led(G2X + 50, G2Y - 26, dg2Run, `${pfx}dg2_led`);

    // LOAD consumers (below bus)
    const loads = [
      { label: L("STEERING"), x: BX + 50, kw: 20 },
      { label: L("NAVIGATION"), x: BX + 160, kw: 15 },
      { label: L("PUMPS"), x: BX + 240, kw: 80 },
      { label: L("LIGHTING"), x: BX + 330, kw: 30 },
      { label: L("OTHER"), x: BX + 410, kw: 35 },
    ];
    loads.forEach(l => {
      svg += pipe(l.x, BY + BH, l.x, BY + BH + 38, busLive ? C.pipe_elec : C.off, `load_${l.label}`, busLive);
      svg += `<rect x="${l.x - 30}" y="${BY + BH + 38}" width="60" height="34" rx="3"
        fill="#08162a" stroke="${busLive ? C.pipe_elec : C.off}" stroke-width="1.5" opacity=".7"/>`;
      svg += `<text x="${l.x}" y="${BY + BH + 56}" text-anchor="middle"
        fill="${busLive ? C.textHi : C.muted}" font-size="8" font-weight="700">${l.label}</text>`;
      svg += `<text x="${l.x}" y="${BY + BH + 68}" text-anchor="middle"
        fill="${busLive ? C.cyan : C.muted}" font-size="8">${l.kw}kW</text>`;
    });

    // Total load bar
    const lBarW = Math.min(1, load / 500) * 440;
    const lCol = load > 450 ? C.alarm : load > 380 ? C.warn : C.on;
    svg += `<text x="${BX}" y="${H - 50}" fill="${C.text}" font-size="9">${L("TOTAL LOAD:")}</text>`;
    svg += `<rect x="${BX}" y="${H - 42}" width="440" height="14" rx="3" fill="#0a1020" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${BX}" y="${H - 42}" width="${lBarW}" height="14" rx="3"
      fill="${lCol}" opacity=".7" id="${pfx}load_bar"/>`;
    svg += `<text id="${pfx}load_val" x="${BX + 220}" y="${H - 33}" text-anchor="middle"
      fill="${lCol}" font-size="9" font-weight="700">${load.toFixed(0)} kW / 500 kW</text>`;

    // DIVIDER
    svg += divider(PD, 25, H - 25);

    // INSTRUMENTS
    const PW = W - PD - 10;
    svg += `<text x="${PD + PW / 2}" y="20" text-anchor="middle" fill="${C.pipe_elec}"
      font-size="11" font-weight="700">MSB INSTRUMENTS</text>`;

    svg += panelBox(PD + 8, 28, PW / 2 - 6, 78, "Hz");
    svg += gauge(PD + 8 + (PW / 2 - 6) / 2, 73, 20, freq, 45, 55, "", "", `${pfx}freq`, 51, 52.5);

    svg += panelBox(PD + PW / 2 + 2, 28, PW / 2 - 10, 78, "V");
    svg += gauge(PD + PW / 2 + 2 + (PW / 2 - 10) / 2, 73, 20, volt, 0, 500, "", "", `${pfx}volt`, null, null);

    svg += panelBox(PD + 8, 115, PW / 2 - 6, 78, "DG1");
    svg += gauge(PD + 8 + (PW / 2 - 6) / 2, 157, 20, dg1Rpm, 0, 800, "", "", `${pfx}d1rpm`);

    svg += panelBox(PD + PW / 2 + 2, 115, PW / 2 - 10, 78, "DG2");
    svg += gauge(PD + PW / 2 + 2 + (PW / 2 - 10) / 2, 157, 20, dg2Rpm, 0, 800, "", "", `${pfx}d2rpm`);

    // Status
    svg += panelBox(PD + 8, 200, PW - 14, 80, "BUS STATUS");
    svg += `<text x="${PD + PW / 2}" y="${232}" text-anchor="middle" fill="${blackout ? C.alarm : busLive ? C.on : C.off}" font-size="13" font-weight="700">${blackout ? "⚠ BLACKOUT" : busLive ? "● BUS LIVE" : L("○ BUS DEAD")}</text>`;
    svg += `<text x="${PD + PW / 2}" y="${248}" text-anchor="middle" fill="${C.muted}" font-size="9">${freq.toFixed(2)} Hz  |  ${volt.toFixed(0)} V  |  ${load.toFixed(0)} kW</text>`;
    if (syncRdy && !cb2Closed && dg2Run) {
      svg += `<text x="${PD + PW / 2}" y="${264}" text-anchor="middle" fill="${C.warn}" font-size="9" font-weight="700">⚡ DG2 READY — Close CB2</text>`;
    }

    svg += panelBox(PD + 8, 288, PW - 14, 55, "ALERTS");
    const dgAlerts = [];
    if (blackout) dgAlerts.push("TOTAL BLACKOUT");
    if (load > 450) dgAlerts.push("BUS OVERLOAD");
    if (freq < 49 && busLive) dgAlerts.push("LOW FREQUENCY");
    if (s.dg1_governor_fault) dgAlerts.push("DG1 GOVERNOR FAULT");
    dgAlerts.forEach((a, i) => {
      svg += `<text x="${PD + 10}" y="${298 + i * 12}" fill="${C.alarm}" font-size="8.5">⚠ ${a}</text>`;
    });
    if (!dgAlerts.length) {
      svg += `<text x="${PD + PW / 2}" y="${308}" text-anchor="middle" fill="${C.on}" font-size="10">✓ ALL NORMAL</text>`;
    }

    // ── FUEL STUBS (short vertical supply into each DG — no long diagonals) ──
    // Fuel enters each DG from the left side at mid-height
    const fuelY = G1Y; // mid-height of DG boxes
    svg += pipe(G1X - 45, fuelY, G1X - 65, fuelY, C.pipe_fuel, "fuel_dg1", dg1Run);
    svg += `<text x="${G1X - 68}" y="${fuelY + 4}" text-anchor="end" fill="${C.pipe_fuel}" font-size="8">HFO⯈</text>`;
    svg += pipe(G2X - 45, fuelY, G2X - 65, fuelY, C.pipe_fuel, "fuel_dg2", dg2Run);
    svg += `<text x="${G2X - 68}" y="${fuelY + 4}" text-anchor="end" fill="${C.pipe_fuel}" font-size="8">HFO⯈</text>`;
    // ── COOLING STUBS (short SW cooling into each DG — right side) ──
    svg += pipe(G1X + 45, fuelY, G1X + 65, fuelY, C.pipe_water, "cool_dg1", dg1Run);
    svg += `<text x="${G1X + 68}" y="${fuelY + 4}" fill="${C.pipe_water}" font-size="8">⯇SW</text>`;
    svg += pipe(G2X + 45, fuelY, G2X + 65, fuelY, C.pipe_water, "cool_dg2", dg2Run);
    svg += `<text x="${G2X + 68}" y="${fuelY + 4}" fill="${C.pipe_water}" font-size="8">⯇SW</text>`;

    svg += legend(PD, H, [
      { color: C.pipe_elec, label: "Electrical / Електрика" },
      { color: C.pipe_fuel, label: "Fuel / Паливо" },
      { color: C.pipe_water, label: "Cooling / Охолодження" },
    ]);
    svg += `</svg>`;
    return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PUBLIC API
  // ════════════════════════════════════════════════════════════════════════


  // ════════════════════════════════════════════════════════════════════════
  //  LAB 3 — FRESH WATER GENERATOR (Alfa Laval JWP-26-C)
  // ════════════════════════════════════════════════════════════════════════

  function renderFWG(W, H, st, isModal) {
    const pfx = isModal ? "m_" : "";
    const s = st || {};
    const run = !!s.running;
    const ejRun = !!s.ejector_running;
    const vac = typeof s.vacuum_mbar === "number" ? s.vacuum_mbar : 71;
    const evap = typeof s.evaporator_temp_c === "number" ? s.evaporator_temp_c : 45;
    const sal = typeof s.salinity_ppm === "number" ? s.salinity_ppm : 2;
    const prod = typeof s.production_rate_lh === "number" ? s.production_rate_lh : 1080;
    const jwIn = typeof s.jw_temp_c === "number" ? s.jw_temp_c : 80;
    const jwOut = typeof s.jw_temp_out_c === "number" ? s.jw_temp_out_c : 72;
    const vacPct = Math.max(0, Math.min(100, (1 - vac / 1013) * 100)); // correct: vac is absolute pressure mbar
    const vacOk = vacPct >= 90;
    const salOk = sal < 5;
    const PD = W - 220;

    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_water}" font-size="11" font-weight="700">ОПУ ALFA LAVAL JWP-26-C  /  FRESH WATER GENERATOR</text>`;
    svg += `<text x="${PD - 10}" y="15" text-anchor="end" fill="${C.muted}" font-size="9">Vacuum: ${vacPct.toFixed(0)}%  |  Salinity: ${sal.toFixed(1)} ppm  |  ${prod.toFixed(0)} L/h</text>`;

    const seaCol = C.pipe_water;
    const jwCol = C.pipe_steam;
    const brinCol = "#64748b";
    const fwCol = "#06b6d4";

    // ── LAYOUT: spread across full width ─────────────────────────────────
    // [SEA CHEST] → [EJECTOR PUMP] → [FWG VESSEL] → [FW PUMP] → [SOL] → [FW TANK]
    //                                    ↕ JW in/out (top/bottom)
    //                                    ↓ Brine → OB

    const midY = 270;  // vertical centre of the diagram

    // SEA CHEST — left side
    const SCX = 30, SCY = midY - 45, SCW = 55, SCH = 90;
    svg += `<rect x="${SCX}" y="${SCY}" width="${SCW}" height="${SCH}" rx="4" fill="#08142a" stroke="${seaCol}" stroke-width="2"/>`;
    for (let i = 0; i < 4; i++) svg += `<line x1="${SCX + 10 + i * 10}" y1="${SCY + 8}" x2="${SCX + 10 + i * 10}" y2="${SCY + SCH - 8}" stroke="${seaCol}" stroke-width="1" opacity=".4"/>`;
    svg += `<text x="${SCX + SCW / 2}" y="${SCY + SCH / 2 - 6}" text-anchor="middle" fill="${seaCol}" font-size="9" font-weight="700">SEA</text>`;
    svg += `<text x="${SCX + SCW / 2}" y="${SCY + SCH / 2 + 6}" text-anchor="middle" fill="${seaCol}" font-size="8">CHEST</text>`;
    svg += `<text x="${SCX + SCW / 2}" y="${SCY - 8}" text-anchor="middle" fill="${seaCol}" font-size="8">${(s.sw_temp_in_c || 22).toFixed(0)}°C</text>`;

    // EJECTOR PUMP — left-centre
    const EPX = 155, EPY = midY;
    svg += pipe(SCX + SCW, midY, EPX - 20, EPY, seaCol, "sc_ep", ejRun && run);
    svg += `<circle cx="${EPX}" cy="${EPY}" r="22" fill="#06111e" stroke="${ejRun ? C.on : C.off}" stroke-width="2.5" ${ejRun ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${EPX - 10},${EPY + 10} ${EPX - 10},${EPY - 10} ${EPX + 12},${EPY}" fill="${ejRun ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${EPX}" y="${EPY + 36}" text-anchor="middle" fill="${C.text}" font-size="9">${L("ejector")}</text>`;
    svg += `<text x="${EPX}" y="${EPY + 47}" text-anchor="middle" fill="${C.muted}" font-size="7">PUMP</text>`;
    svg += tipRect(EPX - 24, EPY - 24, 48, 48, `Ejector Pump  ${ejRun ? "RUNNING" : "STOPPED"}  Vac:${vacPct.toFixed(0)}%`, ejRun ? "stop_generator" : "restart_ejector");
    svg += led(EPX + 28, EPY - 28, ejRun, `${pfx}ep_led`);

    // FWG VESSEL — centre, proper size
    const VX = 255, VY = 55, VW = 220, VH = 360;
    const VCX = VX + VW / 2, VCY = VY + VH / 2;
    // Outer shell (rounded rect not circle — more realistic)
    svg += `<rect x="${VX}" y="${VY}" width="${VW}" height="${VH}" rx="18" fill="#07121f" stroke="${run ? seaCol : C.off}" stroke-width="2.5"/>`;
    // Inner divider line (separator plate)
    const divY = VY + VH * 0.52;
    svg += `<line x1="${VX + 16}" y1="${divY}" x2="${VX + VW - 16}" y2="${divY}" stroke="${C.muted}" stroke-width="1.5" stroke-dasharray="8,4"/>`;
    // CONDENSER section (top half) — tubes
    svg += `<text x="${VCX}" y="${VY + 28}" text-anchor="middle" fill="${run ? seaCol : C.off}" font-size="10" font-weight="700">SEPARATOR</text>`;
    svg += `<text x="${VCX}" y="${VY + 42}" text-anchor="middle" fill="${C.muted}" font-size="7">конденсатор</text>`;
    svg += `<text x="${VCX}" y="${VY + 60}" text-anchor="middle" fill="${vacOk ? C.on : C.alarm}" font-size="13" font-weight="700">${vacPct.toFixed(0)}% VAC</text>`;
    // Vapour arrows (upward)
    if (run && evap > 30) {
      for (let i = 0; i < 5; i++) {
        svg += `<text x="${VX + 30 + i * 36}" y="${divY - 14}" text-anchor="middle" fill="${jwCol}" font-size="12" opacity=".5">↑</text>`;
      }
    }
    // EVAPORATOR section (bottom half) — heating tubes
    svg += `<text x="${VCX}" y="${divY + 22}" text-anchor="middle" fill="${run ? jwCol : C.off}" font-size="9" font-weight="700">${L("evaporator")}</text>`;
    svg += `<text x="${VCX}" y="${divY + 35}" text-anchor="middle" fill="${run ? jwCol : C.muted}" font-size="9">${evap.toFixed(1)}°C</text>`;
    for (let i = 0; i < 6; i++) {
      svg += `<line x1="${VX + 22 + i * 30}" y1="${divY + 48}" x2="${VX + 22 + i * 30}" y2="${VY + VH - 20}" stroke="${run ? jwCol : "#1a2a3a"}" stroke-width="2.5" opacity=".55"/>`;
    }
    svg += tipRect(VX, VY, VW, VH, `FWG  Vac:${vacPct.toFixed(0)}%  Evap:${evap.toFixed(0)}°C  Prod:${prod.toFixed(0)}L/h  ${run ? "RUNNING" : "STOPPED"}`);

    // JW circuit: engine jacket water enters bottom of evaporator, exits mid-vessel
    // JW circuit: labels placed BELOW sea chest to avoid overlap
    // Sea Chest spans y=225-315 at x=30-85. JW labels go at x=16 below y=315.
    const JWinY  = VY + VH - 30;    // bottom-left of vessel = y=385
    const JWoutY = VY + VH * 0.62;  // mid-left of vessel = y=278
    // Vertical JW bus: runs at x=16 from JWinY down to bottom (JW return)
    //                  and JWoutY routes down to join it
    const jwBusX = 16;              // far-left bus, always below sea chest bottom (y>315)
    // JW IN pipe: from left edge (off-screen) enter vessel at bottom-left
    svg += pipe(jwBusX, JWinY, VX, JWinY, jwCol, "jw_in_h", run);
    svg += `<text x="${jwBusX + 2}" y="${JWinY - 8}" text-anchor="start" fill="${jwCol}" font-size="8" font-weight="700">JW IN  ${jwIn.toFixed(0)}°C</text>`;
    // JW OUT pipe: exits vessel mid-left, travels left, drops to bottom
    svg += pipe(VX, JWoutY, jwBusX, JWoutY, jwCol, "jw_out_h", run);
    svg += elbowH(jwBusX, JWoutY, jwBusX, H - 20, jwCol, "jw_out_elb", run);
    // JW OUT label below sea chest bottom edge (SCY+SCH=315 → place at JWoutY+18 if >315)
    const jwOutLabelY = Math.max(JWoutY + 14, 320);
    svg += `<text x="${jwBusX + 2}" y="${jwOutLabelY}" text-anchor="start" fill="${jwCol}" font-size="8" font-weight="700">JW OUT  ${jwOut.toFixed(0)}°C</text>`;
    svg += `<text x="${jwBusX}" y="${H - 6}" text-anchor="middle" fill="${jwCol}" font-size="8">▼ JW RET.</text>`;

    // FIX: Brine: Evaporator bottom → horizontal to Ejector → directly OVERBOARD
    // Must NOT loop back toward Sea Chest inlet.
    const BrineY = VY + VH + 20;
    svg += elbowH(VCX, VY + VH, VCX, BrineY, brinCol, "brine_out", ejRun && run);
    svg += pipe(VCX, BrineY, EPX, BrineY, brinCol, "brine_left", ejRun && run);
    // Brine enters ejector (suction side) — ejector then discharges overboard
    svg += elbowH(EPX, BrineY, EPX, EPY + 22, brinCol, "brine_to_ej", ejRun && run);
    // Ejector overboard discharge — exits bottom of diagram
    const OB_X = EPX - 28;
    svg += elbowH(EPX, EPY + 22, OB_X, BrineY + 38, brinCol, "ej_ob_h", ejRun && run);
    svg += `<line x1="${OB_X}" y1="${BrineY + 38}" x2="${OB_X}" y2="${H - 18}"
      stroke="${ejRun && run ? brinCol : C.muted}" stroke-width="3"
      stroke-dasharray="${ejRun && run ? '6,4' : '3,6'}" stroke-linecap="round"/>`;
    svg += `<text x="${OB_X}" y="${H - 4}" text-anchor="middle"
      fill="${ejRun && run ? brinCol : C.muted}" font-size="8" font-weight="700">▼ OB</text>`;

    // ── RIGHT SIDE: FW PUMP → SOL → FW TANK ──────────────────────────────
    const FWoutY = VY + 80;   // clean distillate outlet (top of vessel)
    const FPX = VX + VW + 70, FPY = FWoutY;

    // FW pipe out of vessel
    svg += pipe(VX + VW, FWoutY, FPX - 22, FPY, fwCol, "vessel_fwp", run && prod > 0);

    // FW Pump
    svg += `<circle cx="${FPX}" cy="${FPY}" r="20" fill="#06111e" stroke="${run && salOk ? C.on : C.off}" stroke-width="2.5" ${run && salOk ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${FPX - 9},${FPY + 9} ${FPX - 9},${FPY - 9} ${FPX + 11},${FPY}" fill="${run && salOk ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${FPX}" y="${FPY + 34}" text-anchor="middle" fill="${C.text}" font-size="8">${L("fw_pump")}</text>`;
    svg += tipRect(FPX - 22, FPY - 22, 44, 44, `FW Pump  ${run ? "RUNNING" : "STOPPED"}  Salinity:${sal.toFixed(1)}ppm`);
    svg += led(FPX + 26, FPY - 26, run && salOk, `${pfx}fwp_led`);

    // Salinity sensor (DS-20) — below FW pump
    const SalX = FPX, SalY = FPY + 80;
    svg += elbowH(VX + VW, FWoutY + 60, SalX, SalY, fwCol, "sal_tap", run);
    svg += `<rect x="${SalX - 12}" y="${SalY - 12}" width="24" height="24" rx="3" fill="#0a1828" stroke="${salOk ? C.on : C.alarm}" stroke-width="1.5" transform="rotate(45 ${SalX} ${SalY})"/>`;
    svg += `<text x="${SalX}" y="${SalY + 4}" text-anchor="middle" fill="${salOk ? C.on : C.alarm}" font-size="7" font-weight="700">DS-20</text>`;
    svg += `<text x="${SalX}" y="${SalY + 26}" text-anchor="middle" fill="${salOk ? C.on : C.alarm}" font-size="8">${sal.toFixed(1)} ppm</text>`;

    // SOL valve → FW TANK
    const SOLX = FPX + 50, SOLY = FPY;
    svg += pipe(FPX + 20, FPY, SOLX - 8, SOLY, fwCol, "fwp_sol", run && salOk);
    svg += `<rect x="${SOLX - 8}" y="${SOLY - 9}" width="16" height="18" rx="2" fill="${salOk ? "#0a1e10" : C.alarm}" stroke="${salOk ? C.on : C.alarm}" stroke-width="1.5"/>`;
    svg += `<text x="${SOLX}" y="${SOLY + 4}" text-anchor="middle" fill="${salOk ? C.on : C.alarm}" font-size="7" font-weight="700">SOL</text>`;

    // FW TANK vessel
    const FTWX = SOLX + 30, FTWY = FPY - 40, FTWW = 65, FTWH = 80;
    svg += pipe(SOLX + 8, SOLY, FTWX, SOLY, salOk ? fwCol : brinCol, "fw_tank_pipe", run && salOk);
    svg += `<rect x="${FTWX}" y="${FTWY}" width="${FTWW}" height="${FTWH}" rx="4" fill="#07101a" stroke="${salOk ? fwCol : C.muted}" stroke-width="1.5"/>`;
    svg += `<text x="${FTWX + FTWW / 2}" y="${FTWY + FTWH / 2 - 6}" text-anchor="middle" fill="${salOk ? fwCol : C.muted}" font-size="8" font-weight="700">FW</text>`;
    svg += `<text x="${FTWX + FTWW / 2}" y="${FTWY + FTWH / 2 + 6}" text-anchor="middle" fill="${salOk ? fwCol : C.muted}" font-size="8" font-weight="700">TANK</text>`;
    // Fill level
    const ftFill = run && salOk ? Math.min(FTWH - 10, 10 + (prod / 1200) * 50) : 5;
    svg += `<rect x="${FTWX + 4}" y="${FTWY + FTWH - 4 - ftFill}" width="${FTWW - 8}" height="${ftFill}" rx="2" fill="${fwCol}" opacity=".2"/>`;
    svg += tipRect(FTWX, FTWY, FTWW, FTWH, `FW Tank  ${salOk ? "Receiving distillate" : "Isolated (salinity high)"}  Prod:${prod.toFixed(0)}L/h`);

    // ── RIGHT PANEL ───────────────────────────────────────────────────────
    svg += divider(PD, 22, H - 5);
    const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${fwCol}" font-size="10" font-weight="700">FWG CONTROL PANEL</text>`;

    const vacColor = vacPct >= 90 ? C.on : vacPct >= 85 ? C.warn : C.alarm;
    svg += panelBox(PD + 5, 43, PW / 2 - 4, 80, "VACUUM %");
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 83, 20, vacPct, 0, 100, "", "", `${pfx}vac`);
    if (vacPct < 90) svg += `<text x="${PD + 5 + (PW / 2 - 4) / 2}" y="150" text-anchor="middle" fill="${C.alarm}" font-size="8">⚠ MIN 90%</text>`;

    svg += panelBox(PD + PW / 2 + 3, 43, PW / 2 - 8, 80, "SALINITY");
    const salBarH = 40, salFill2 = Math.min(1, sal / 20) * salBarH; // Сделали чуть ниже
    const salCol2 = sal >= 5 ? C.alarm : sal >= 3 ? C.warn : C.on;
    const _salBoxCx = PD + PW / 2 + 3 + (PW / 2 - 8) / 2, _salBX = _salBoxCx - 14; // Сдвинули левее для делений
    const salY = 62; // Опустили ниже заголовка (было 56)
    svg += `<rect x="${_salBX}" y="${salY}" width="18" height="${salBarH}" rx="3" fill="#030a12" stroke="${salCol2}" stroke-width="1.5"/>`;
    svg += `<rect x="${_salBX + 1}" y="${salY + salBarH - salFill2}" width="16" height="${salFill2}" rx="2" fill="${salCol2}" opacity=".7"/>`;
    for (const p of [5, 10, 15, 20]) {
      const _py = salY + salBarH - (p / 20) * salBarH;
      svg += `<line x1="${_salBX + 18}" y1="${_py}" x2="${_salBX + 23}" y2="${_py}" stroke="${C.muted}" stroke-width="1"/>`;
      svg += `<text x="${_salBX + 25}" y="${_py + 3}" fill="${C.muted}" font-size="7">${p}</text>`;
    }
    svg += `<text x="${_salBoxCx - 5}" y="${salY + salBarH + 12}" text-anchor="middle" fill="${salCol2}" font-size="11" font-weight="700">${sal.toFixed(1)}</text>`;
    svg += `<text x="${_salBoxCx - 5}" y="${salY + salBarH + 20}" text-anchor="middle" fill="${C.muted}" font-size="7">ppm</text>`;

    svg += panelBox(PD + 5, 158, PW - 10, 50, "FW PRODUCTION");
    const prodColor = prod < 500 && run ? C.alarm : prod < 800 && run ? C.warn : C.on;
    svg += digDisplay(PD + 15, 174, PW / 2 - 10, 26, prod, "L/h", "", `${pfx}prod`, prodColor);
    const prodBarW = Math.min(1, prod / 1200) * (PW - 118);
    svg += `<rect x="${PD + 110}" y="174" width="${PW - 118}" height="26" rx="3" fill="#030a12" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${PD + 110}" y="174" width="${prodBarW}" height="26" rx="3" fill="${prodColor}" opacity=".6"/>`;

    svg += panelBox(PD + 5, 218, PW - 10, 55, "JW TEMP");
    svg += digDisplay(PD + 10, 234, PW / 2 - 12, 24, jwIn, "°C", "IN", `${pfx}jwi`, jwIn < 65 ? C.alarm : jwIn < 72 ? C.warn : C.on);
    svg += digDisplay(PD + PW / 2 + 6, 234, PW / 2 - 14, 24, jwOut, "°C", "OUT", `${pfx}jwo`, C.on);
    svg += `<text x="${PD + PW / 2}" y="${264}" text-anchor="middle" fill="${C.muted}" font-size="7">ΔT ${(jwIn - jwOut).toFixed(1)}°C</text>`;

    svg += panelBox(PD + 5, 277, PW - 10, 50, "EVAPORATOR TEMP");
    const evapColor = evap > 50 ? C.alarm : evap < 35 && run ? C.warn : C.on;
    svg += digDisplay(PD + 15, 293, PW / 2 - 10, 26, evap, "°C", "", `${pfx}evap`, evapColor);
    svg += `<text x="${PD + PW / 2}" y="${318}" text-anchor="middle" fill="${C.muted}" font-size="7">nom: 45°C @ 93% vac</text>`;

    svg += panelBox(PD + 5, 334, PW - 10, 80, "SYSTEM STATUS");
    [[`FWG Running`, run, false], [`Ejector Pump`, ejRun, false], [`Vacuum OK ≥90%`, vacOk, true], [`Salinity OK <5ppm`, salOk, true], [`Production OK`, prod > 500, false]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${364 + i * 13}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${364 + i * 13 + 4}" fill="${it[1] ? C.textHi : C_INACTIVE_TEXT}" font-size="8.5">${it[0]}</text>`;
    });
    svg += legend(PD, H, [
      { color: jwCol, label: "Jacket Water / ОО" },
      { color: fwCol, label: "Distillate / Дистилят" },
      { color: seaCol, label: "Seawater / Морська вода" },
      { color: brinCol, label: "Brine / Розсіл", dashed: true },
    ]);
    svg += `</svg>`; return svg;
  }
  function renderHydrophore(W, H, st, isModal) {
    const pfx = isModal ? "m_" : ""; const s = st || {};
    const p1Run = !!s.pump_running;
    const p2Run = !!s.pump2_running;
    const press = typeof s.tank_pressure_bar === "number" ? s.tank_pressure_bar : 3.5;
    const level = typeof s.tank_level_pct === "number" ? s.tank_level_pct : 60;
    const air = typeof s.air_charge_pct === "number" ? s.air_charge_pct : 35;
    const flow = typeof s.flow_ls === "number" ? s.flow_ls : 2;
    const pressOk = press >= 2.0, airOk = air > 10, PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_water}" font-size="11" font-weight="700">HYDROPHORE SYSTEM  /  ГІДРОФОРНА СИСТЕМА</text>`;
    const wc = C.pipe_water, ac = C.pipe_air;
    svg += vessel(15, 165, 60, 80, isUA() ? "ПОДАЧА\nПВ" : "FW\nSUPPLY", wc);
    const P1X = 160, P1Y = 205;
    // P2 (standby) pump — drawn above P1, shares same suction header
    const P2X_h = 160, P2Y_h = 155;
    svg += pipe(75, 155, P2X_h - 18, P2Y_h, wc, "src_p2h", p2Run);
    svg += `<circle cx="${P2X_h}" cy="${P2Y_h}" r="20" fill="#06111e" stroke="${p2Run ? C.on : C.off}" stroke-width="2.5"/>`;
    svg += `<polygon points="${P2X_h - 9},${P2Y_h + 9} ${P2X_h - 9},${P2Y_h - 9} ${P2X_h + 11},${P2Y_h}" fill="${p2Run ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${P2X_h}" y="${P2Y_h + 33}" text-anchor="middle" fill="${C.text}" font-size="8">${L("PUMP P2")}</text>`;
    svg += tipRect(P2X_h - 22, P2Y_h - 22, 44, 44, `Pump P-2 [SBY]  ${p2Run ? "RUNNING" : "STOPPED"}`, p2Run ? "stop_pump2" : "start_pump2");
    svg += led(P2X_h + 26, P2Y_h - 26, p2Run, `${pfx}p2h_led`);
    svg += pipe(P2X_h + 20, P2Y_h, 235, P2Y_h, wc, "p2h_nrv", p2Run);
    // NRV for P2
    svg += `<polygon points="235,${P2Y_h - 8} 235,${P2Y_h + 8} 251,${P2Y_h}" fill="#06111e" stroke="${wc}" stroke-width="1.5"/>`;
    svg += `<line x1="251" y1="${P2Y_h - 8}" x2="251" y2="${P2Y_h + 8}" stroke="${wc}" stroke-width="2"/>`;
    svg += pipe(251, P2Y_h, 265 - 10, P2Y_h, wc, "p2h_tank_in", p2Run);
    svg += elbowH(265 - 10, P2Y_h, 265 - 10, 205, wc, "p2h_join", p2Run);
    // Suction header: vertical connecting P1 and P2 suction branch
    svg += pipe(75, 155, 75, 205, wc, "src_header", p1Run || p2Run);
    svg += `<circle cx="75" cy="155" r="4" fill="${wc}" opacity=".7"/>`;
    svg += `<circle cx="75" cy="205" r="4" fill="${wc}" opacity=".7"/>`;
    // P1 pump
    svg += pipe(75, 205, P1X - 18, P1Y, wc, "src_p1", p1Run);
    svg += `<circle cx="${P1X}" cy="${P1Y}" r="20" fill="#06111e" stroke="${p1Run ? C.on : C.off}" stroke-width="3" ${p1Run ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${P1X - 9},${P1Y + 9} ${P1X - 9},${P1Y - 9} ${P1X + 11},${P1Y}" fill="${p1Run ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${P1X}" y="${P1Y + 33}" text-anchor="middle" fill="${C.text}" font-size="8">${L("PUMP P1")}</text>`;
    svg += tipRect(P1X - 22, P1Y - 22, 44, 44, `Pump P-1  ${p1Run ? "RUNNING" : "STOPPED"}  Press:${press.toFixed(2)}bar`, p1Run ? "stop_pump" : "start_pump");
    svg += led(P1X + 26, P1Y - 26, p1Run, `${pfx}p1_led`);
    svg += pipe(P1X + 20, P1Y, 235, P1Y, wc, "p1_nrv", p1Run);
    svg += `<polygon points="235,${P1Y - 8} 235,${P1Y + 8} 251,${P1Y}" fill="#06111e" stroke="${wc}" stroke-width="1.5"/>`;
    svg += `<line x1="251" y1="${P1Y - 8}" x2="251" y2="${P1Y + 8}" stroke="${wc}" stroke-width="2"/>`;
    const TX = 265, TY = 70, TW = 145, TH = 280;
    svg += `<rect x="${TX}" y="${TY}" width="${TW}" height="${TH}" rx="8" fill="#070e1a" stroke="${pressOk ? C.pipe_water : C.alarm}" stroke-width="2.5"/>`;
    svg += `<ellipse cx="${TX + TW / 2}" cy="${TY}" rx="${TW / 2}" ry="12" fill="#08152a" stroke="${pressOk ? C.pipe_water : C.alarm}" stroke-width="2"/>`;
    svg += `<ellipse cx="${TX + TW / 2}" cy="${TY + TH}" rx="${TW / 2}" ry="12" fill="#08152a" stroke="${pressOk ? C.pipe_water : C.alarm}" stroke-width="2"/>`;
    const airH = TH * 0.85 * (1 - level / 100);
    svg += `<rect x="${TX + 3}" y="${TY + 3}" width="${TW - 6}" height="${airH}" fill="${ac}" opacity=".08"/>`;
    // Only show air label if there's enough space
    if (airH > 25) svg += labelPill(TX + TW / 2, TY + Math.min(airH / 2 + 10, airH - 4), 'AIR ' + air.toFixed(0) + '%', airOk ? ac : C.alarm, 9);
    const waterH = TH * 0.85 * (level / 100), waterTop = TY + TH - waterH;
    svg += `<rect x="${TX + 3}" y="${waterTop}" width="${TW - 6}" height="${waterH}" fill="${wc}" opacity=".12"/>`;
    svg += `<line x1="${TX + 3}" y1="${waterTop}" x2="${TX + TW - 3}" y2="${waterTop}" stroke="${wc}" stroke-width="1.5"/>`;
    if (waterH > 20) svg += labelPill(TX + TW / 2, waterTop + Math.min(waterH / 2 + 4, waterH - 4), 'WATER ' + level.toFixed(0) + '%', wc, 9);
    svg += `<line x1="${TX + TW / 2}" y1="${TY}" x2="${TX + TW / 2}" y2="${TY - 30}" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<circle cx="${TX + TW / 2}" cy="${TY - 40}" r="12" fill="#06111e" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<text x="${TX + TW / 2}" y="${TY - 36}" text-anchor="middle" fill="${C.pipe_steam}" font-size="8" font-weight="700">PI</text>`;
    svg += `<text x="${TX + TW / 2}" y="${TY - 54}" text-anchor="middle" fill="${pressOk ? C.on : C.alarm}" font-size="10" font-weight="700">${press.toFixed(1)} bar</text>`;
    svg += pipe(251, P1Y, TX - 10, P1Y, wc, "nrv_tank", p1Run);
    svg += elbowH(TX - 10, P1Y, TX - 10, TY + TH - 30, wc, "tank_fill", p1Run);
    svg += pipe(TX - 10, TY + TH - 30, TX, TY + TH - 30, wc, "tank_in", p1Run);
    const DSX = TX + TW + 50;
    svg += pipe(TX + TW, TY + TH * 0.7, DSX, TY + TH * 0.7, wc, "tank_dist", pressOk && p1Run);
    svg += `<rect x="${DSX}" y="${TY + 70}" width="12" height="${TH * 0.6}" rx="2" fill="#06111e" stroke="${pressOk ? wc : C.off}" stroke-width="1.5"/>`;
    [L("ACCOMM."), L("GALLEY"), L("ENGINE RM")].forEach((c, i) => {
      const cy = TY + 90 + i * 50;
      svg += pipe(DSX + 12, cy, DSX + 60, cy, pressOk ? wc : C.off, `cons_${i}`, pressOk && p1Run);
      svg += `<rect x="${DSX + 60}" y="${cy - 14}" width="44" height="28" rx="3" fill="#06111e" stroke="${pressOk ? wc : C.off}" stroke-width="1" opacity=".7"/>`;
      svg += `<text x="${DSX + 82}" y="${cy + 1}" text-anchor="middle" fill="${pressOk ? C.textHi : C.muted}" font-size="7">${c}</text>`;
    });
    svg += divider(PD, 22, H - 5); const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${wc}" font-size="10" font-weight="700">HYDROPHORE PANEL</text>`;
    svg += panelBox(PD + 5, 43, PW / 2 - 4, 78, "bar");
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 85, 20, press, 0, 6, "", "", `${pfx}press`, 2.0);
    svg += panelBox(PD + PW / 2 + 3, 43, PW / 2 - 8, 78, "air%");
    svg += gauge(PD + PW / 2 + 3 + (PW / 2 - 8) / 2, 85, 20, air, 0, 50, "", "", `${pfx}air`);
    svg += panelBox(PD + 5, 140, PW - 10, 40, "WATER LEVEL");
    const lbW = Math.min(1, level / 100) * (PW - 28), lbC = level < 20 ? C.alarm : level < 40 ? C.warn : C.on;
    svg += `<rect x="${PD + 15}" y="160" width="${PW - 28}" height="16" rx="3" fill="#030a12" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${PD + 15}" y="160" width="${lbW}" height="16" rx="3" fill="${lbC}" opacity=".6"/>`;
    svg += `<text x="${PD + PW / 2}" y="172" text-anchor="middle" fill="${lbC}" font-size="10" font-weight="700">${level.toFixed(0)}%</text>`;
    svg += panelBox(PD + 5, 186, PW - 10, 38, "FLOW RATE");
    svg += digDisplay(PD + 15, 201, PW - 28, 22, flow, "L/s", "", `${pfx}flow`, C.on);
    svg += panelBox(PD + 5, 230, PW - 10, 70, "STATUS");
    [[`Pump P1`, p1Run, false], [`Pressure ≥2 bar`, pressOk, true], [`Air OK`, airOk, true], [`Level OK`, level > 20, false]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${254 + i * 13 + 4}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${254 + i * 13 + 4}" dominant-baseline="central" fill="${it[1] ? C.textHi : C_INACTIVE_TEXT}" font-size="8.5">${it[0]}</text>`;
    });
    svg += legend(PD, H, [
      { color: C.pipe_water, label: "Fresh Water / Прісна вода" },
      { color: C.pipe_air, label: "Air / Повітря" },
    ]);
    svg += `</svg>`; return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 7 — FUEL OIL SEPARATOR
  // ════════════════════════════════════════════════════════════════════════

  function renderFuelSep(W, H, st, isModal) {
    const pfx = isModal ? "m_" : ""; const s = st || {};
    const run = !!s.running, heatOn = !!s.heater_on, motFault = !!s.motor_fault;
    const bowl = typeof s.bowl_speed_rpm === "number" ? s.bowl_speed_rpm : 7500;
    const temp = typeof s.fuel_temp_c === "number" ? s.fuel_temp_c : 98;
    const flow = typeof s.clean_fuel_flow_ls === "number" ? s.clean_fuel_flow_ls : 0.8;
    const sludge = typeof s.sludge_level_pct === "number" ? s.sludge_level_pct : 5;
    const bowlOk = bowl >= 7125, purifying = run && bowlOk && !motFault, PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_fuel}" font-size="11" font-weight="700">ПАЛИВНИЙ СЕПАРАТОР ALFA LAVAL  /  FUEL OIL SEPARATOR</text>`;
    const fc = C.pipe_fuel, sc = C.pipe_steam;

    // ── LAYOUT: spread elements across full width ─────────────────────────
    // Bunker Tank (left) → Heater → Separator (centre) → Service Tank (right)
    const BT = { x: 15, y: 160, w: 65, h: 130 };       // Bunker Tank
    const HX = 140, HY = 220;                      // Heater centre
    const SX = 258, SY = 55;                       // Separator top-left
    const outY = SY + 55;                         // clean fuel outlet Y
    // Service Tank — now a real visible element on the right
    const STX = PD - 100, STY = outY - 35, STW = 80, STH = 70;

    svg += vessel(BT.x, BT.y, BT.w, BT.h, L("BUNKER\\nTANK"), fc);

    // Pipe: Bunker Tank → Heater
    svg += pipe(BT.x + BT.w, BT.y + BT.h / 2, HX - 27, HY, fc, "tank_heat", run);

    // Heater block
    // ISA heat exchanger for FuelSep heater
    svg += heatExSym(HX - 27, HY - 22, 55, 44, heatOn, `${pfx}fsep_hx`, "", `${temp.toFixed(0)}°C`);
    svg += `<text x="${HX}" y="${HY + 32}" text-anchor="middle" fill="${C.text}" font-size="8">HEATER</text>`;
    svg += tipRect(HX - 27, HY - 22, 55, 44, `Steam Heater  Fuel:${temp.toFixed(0)}°C  ${heatOn ? "ON" : "OFF"}`, heatOn ? "stop_heater" : "restore_heating");
    svg += led(HX + 27, HY - 22, heatOn, `${pfx}heat_led`);
    svg += `<line x1="${HX}" y1="${HY - 22}" x2="${HX}" y2="${HY - 50}" stroke="${heatOn ? sc : C.muted}" stroke-width="2" stroke-dasharray="5,3"/>`;

    // Pipe: Heater → Separator
    svg += pipe(HX + 28, HY, SX + 20, HY, fc, "heat_sep", run);

    // Separator body (trapezoid)
    svg += `<path d="M${SX + 20},${SY} L${SX + 100},${SY} L${SX + 110},${SY + 260} L${SX + 10},${SY + 260} Z" fill="#07101a" stroke="${run && !motFault ? C.on : motFault ? C.alarm : C.off}" stroke-width="2.5"/>`;
    for (let i = 0; i < 8; i++) { const dy = SY + 60 + i * 15, fw = 40 + i * 4; svg += `<line x1="${SX + 60 - fw / 2}" y1="${dy}" x2="${SX + 60 + fw / 2}" y2="${dy}" stroke="${purifying ? C.on : C.muted}" stroke-width="1.5" opacity="${0.3 + i * 0.07}"/>`; }
    svg += tipRect(SX, SY, 120, 220, `Fuel Separator  Bowl:${bowl.toFixed(0)}RPM  Sludge:${sludge.toFixed(0)}%  Temp:${temp.toFixed(0)}°C  ${run ? "RUNNING" : "STOPPED"}`, run ? "switch_standby" : "start_separator");
    const bCol = bowl < 5000 ? C.alarm : bowl < 7125 ? C.warn : C.on;
    svg += `<text x="${SX + 60}" y="${SY + 210}" text-anchor="middle" fill="${bCol}" font-size="12" font-weight="700">${Math.round(bowl)}</text>`;
    svg += `<text x="${SX + 60}" y="${SY + 225}" text-anchor="middle" fill="${C.muted}" font-size="8">RPM</text>`;
    svg += `<text x="${SX + 60}" y="${SY - 12}" text-anchor="middle" fill="${motFault ? C.alarm : run ? C.on : C.off}" font-size="9" font-weight="700">${motFault ? L("⚠ MOTOR FAULT") : run ? "RUNNING" : "STOPPED"}</text>`;
    // Fault badge on separator when motor fault
    if (motFault) {
      svg += `<circle cx="${SX + 100}" cy="${SY + 10}" r="10" fill="${C.alarm}" opacity=".92"/>`;
      svg += `<text x="${SX + 100}" y="${SY + 11}" text-anchor="middle" dominant-baseline="central" fill="#fff" font-size="11" font-weight="700">!</text>`;
    }

    // Pipe: Separator → Service Tank (shorter, ends at real ST box)
    svg += pipe(SX + 110, outY, STX, outY, purifying ? C.on : C.off, "sep_clean", purifying);

    // Service Tank — real visible element (FIX: was just text "→ SERVICE TANK")
    svg += `<rect x="${STX}" y="${STY}" width="${STW}" height="${STH}" rx="5" fill="#07101a" stroke="${purifying ? C.on : C.muted}" stroke-width="2" opacity=".85"/>`;
    svg += `<text x="${STX + STW / 2}" y="${STY + STH / 2 - 6}" text-anchor="middle" dominant-baseline="central" fill="${purifying ? C.on : C.muted}" font-size="8" font-weight="700">SERVICE</text>`;
    svg += `<text x="${STX + STW / 2}" y="${STY + STH / 2 + 6}" text-anchor="middle" dominant-baseline="central" fill="${purifying ? C.on : C.muted}" font-size="8" font-weight="700">TANK</text>`;
    // Fill level indicator inside service tank
    const stFill = purifying ? Math.min(STH - 10, 20 + flow * 15) : 8;
    svg += `<rect x="${STX + 6}" y="${STY + STH - 6 - stFill}" width="${STW - 12}" height="${stFill}" rx="2" fill="${C.on}" opacity=".25"/>`;
    svg += tipRect(STX, STY, STW, STH, `Service Tank  Clean Fuel Flow: ${flow.toFixed(1)} L/s`);

    // Sludge outlet
    const sludgeY = SY + 290, sludgeFull = sludge > 80;
    svg += elbowH(SX + 60, SY + 260, SX + 60, sludgeY, sludgeFull ? C.alarm : C.muted, "sludge_pipe", sludge > 20);
    svg += vessel(SX + 35, sludgeY, 50, 40, L("SLUDGE"), sludgeFull ? C.alarm : C.muted);
    // Sludge fill level inside vessel
    const slFill = Math.min(34, sludge / 100 * 34);
    svg += `<rect x="${SX + 38}" y="${sludgeY + 6 + 34 - slFill}" width="44" height="${slFill}" rx="2" fill="${sludgeFull ? C.alarm : C.warn}" opacity=".4"/>`;
    svg += `<text x="${SX + 60}" y="${sludgeY + 52}" text-anchor="middle" fill="${sludgeFull ? C.alarm : C.muted}" font-size="8">${sludge.toFixed(0)}%</text>`;

    // ── RIGHT INSTRUMENT PANEL ────────────────────────────────────────────
    svg += divider(PD, 22, H - 5); const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${fc}" font-size="10" font-weight="700">SEPARATOR INSTRUMENTS</text>`;
    svg += panelBox(PD + 5, 43, PW / 2 - 4, 78, "RPM");
    // FIX: RPM gauge — bowl speed, low RPM = bad (invertWarn: warnLow/critLow)
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 85, 20, bowl, 0, 8000, "", "", `${pfx}bowl`, 7125, 5000);
    svg += panelBox(PD + PW / 2 + 3, 43, PW / 2 - 8, 78, "°C");
    svg += gauge(PD + PW / 2 + 3 + (PW / 2 - 8) / 2, 85, 20, temp, 20, 130, "", "", `${pfx}temp`);
    svg += panelBox(PD + 5, 128, PW / 2 - 4, 70, "L/s");
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 166, 20, flow, 0, 1.2, "", "", `${pfx}flow`);

    // SLUDGE % bar — centered in its half-panel
    svg += panelBox(PD + PW / 2 + 3, 128, PW / 2 - 8, 70, "SLUDGE %");
    const sbH = 38; // Уменьшили высоту шкалы, чтобы влезла
    const sFill = Math.min(1, sludge / 100) * sbH;
    const _sbBoxW = PW / 2 - 8, _sbCx = PD + PW / 2 + 3 + _sbBoxW / 2;
    const sbW = 24, sbX = _sbCx - sbW / 2, sbY = 146; // Опустили ниже текста (было 134)
    svg += `<rect x="${sbX}" y="${sbY}" width="${sbW}" height="${sbH}" rx="3" fill="#030a12" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${sbX + 2}" y="${sbY + sbH - 2 - sFill}" width="${sbW - 4}" height="${sFill}" rx="2" fill="${sludgeFull ? C.alarm : C.warn}" opacity=".8"/>`;
    svg += `<text x="${_sbCx}" y="${sbY + sbH + 11}" text-anchor="middle" fill="${sludgeFull ? C.alarm : C.on}" font-size="10" font-weight="700">${sludge.toFixed(0)}%</text>`;

    svg += panelBox(PD + 5, 205, PW - 10, 75, "STATUS");
    [[`Running`, run, false], [`Heater ON`, heatOn, false], [`Bowl ≥7125 RPM`, bowlOk, true], [`Motor OK`, !motFault, true], [`${sludgeFull ? 'SLUDGE FULL ⚠' : 'Sludge OK'}`, !sludgeFull, true]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${230 + i * 12}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${230 + i * 12 + 4}" fill="${it[1] ? C.textHi : C.muted}" font-size="8.5">${it[0]}</text>`;
    });
    svg += legend(PD, H, [
      { color: C.pipe_fuel, label: "Dirty Fuel / Брудне паливо" },
      { color: C.on, label: "Clean Fuel / Чисте паливо" },
      { color: C.pipe_oil, label: "Sludge / Шлам" },
    ]);
    svg += `</svg>`; return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 8 — STEERING GEAR
  // ════════════════════════════════════════════════════════════════════════

  function renderSteering(W, H, st, isModal) {
    const pfx = isModal ? "m_" : ""; const s = st || {};
    const p1Run = !!s.pump_running, fbOk = !!s.feedback_ok;
    const press = typeof s.hydraulic_pressure_bar === "number" ? s.hydraulic_pressure_bar : 180;
    const oil = typeof s.oil_level_pct === "number" ? s.oil_level_pct : 85;
    const rudder = typeof s.rudder_angle_deg === "number" ? s.rudder_angle_deg : 0;
    const ordered = typeof s.ordered_angle_deg === "number" ? s.ordered_angle_deg : 0;
    const pressOk = press >= 80, PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_hyd}" font-size="11" font-weight="700">РУЛЬОВА МАШИНА  /  STEERING GEAR (ELECTRO-HYDRAULIC)</text>`;
    const hc = C.pipe_hyd;
    svg += `<rect x="30" y="190" width="110" height="100" rx="4" fill="#08112a" stroke="${C.pipe_elec}" stroke-width="1.5"/>`;
    svg += `<text x="85" y="206" text-anchor="middle" fill="${C.pipe_elec}" font-size="9" font-weight="700">HPU</text>`;
    svg += `<rect x="38" y="214" width="94" height="34" rx="2" fill="#030a10" stroke="${hc}" stroke-width="1.5"/>`;
    const oilFill = 90 * (oil / 100);
    svg += `<rect x="39" y="215" width="${oilFill}" height="32" rx="2" fill="${hc}" opacity=".25"/>`;
    svg += `<text x="85" y="234" text-anchor="middle" fill="${hc}" font-size="9">${oil.toFixed(0)}%</text>`;
    svg += `<text x="85" y="282" text-anchor="middle" fill="${C.muted}" font-size="7">${L("OIL SUMP")}</text>`;
    svg += tipRect(30, 190, 110, 100, `Hydraulic Unit  Oil:${oil.toFixed(0)}%  Press:${press.toFixed(0)}bar  ${p1Run ? "RUNNING" : "STOPPED"}`);
    const P1X = 85, P1Y = 370;
    svg += pipe(P1X, 290, P1X, P1Y - 22, hc, "hpu_p1", p1Run);
    svg += `<circle cx="${P1X}" cy="${P1Y}" r="22" fill="#06111e" stroke="${p1Run ? C.on : C.off}" stroke-width="3" ${p1Run ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${P1X - 10},${P1Y + 10} ${P1X - 10},${P1Y - 10} ${P1X + 12},${P1Y}" fill="${p1Run ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${P1X}" y="${P1Y + 35}" text-anchor="middle" fill="${C.text}" font-size="8">${L("PUMP P1")}</text>`;
    svg += tipRect(P1X - 24, P1Y - 24, 48, 48, `Hyd. Pump HP-1  ${p1Run ? "RUNNING" : "STOPPED"}  Press:${press.toFixed(0)}bar`, p1Run ? "stop_pump" : "start_pump");
    svg += led(P1X + 28, P1Y - 28, p1Run, `${pfx}p1_led`);
    svg += pipe(P1X + 22, P1Y, 460, P1Y, pressOk ? hc : C.off, "hp_manifold", p1Run);
    svg += `<circle cx="300" cy="${P1Y - 20}" r="10" fill="#06111e" stroke="${pressOk ? hc : C.alarm}" stroke-width="1.5"/>`;
    svg += pipe(300, P1Y, 300, P1Y - 20, pressOk ? hc : C.alarm, "pi_pipe", p1Run);
    svg += `<text x="300" y="${P1Y - 16}" text-anchor="middle" fill="${hc}" font-size="6" font-weight="700">PI</text>`;
    svg += `<text x="300" y="${P1Y - 34}" text-anchor="middle" fill="${pressOk ? C.on : C.alarm}" font-size="9" font-weight="700">${Math.round(press)} bar</text>`;
    const RAX = 350, RAY = 240, RAW = 155, RAH = 90;
    svg += `<rect x="${RAX}" y="${RAY}" width="${RAW}" height="${RAH}" rx="6" fill="#07101a" stroke="${pressOk ? hc : C.off}" stroke-width="2.5"/>`;
    const pistonX = RAX + RAW / 2 + rudder * (RAW * 0.3 / 35);
    svg += `<rect x="${pistonX - 10}" y="${RAY + 10}" width="20" height="${RAH - 20}" rx="3" fill="${pressOk ? hc : C.off}" opacity=".4"/>`;
    svg += `<line x1="${RAX - 30}" y1="${RAY + RAH / 2}" x2="${RAX}" y2="${RAY + RAH / 2}" stroke="${pressOk ? hc : C.off}" stroke-width="6" stroke-linecap="round"/>`;
    svg += `<line x1="${RAX + RAW}" y1="${RAY + RAH / 2}" x2="${RAX + RAW + 30}" y2="${RAY + RAH / 2}" stroke="${pressOk ? hc : C.off}" stroke-width="6" stroke-linecap="round"/>`;
    svg += `<text x="${RAX + RAW / 2}" y="${RAY - 10}" text-anchor="middle" fill="${hc}" font-size="8">${L("2-RAM ACTUATOR")}</text>`;
    svg += tipRect(RAX, RAY, RAW, RAH, `Rudder Actuator  ${rudder.toFixed(1)}°  Order:${ordered.toFixed(1)}°  ${fbOk ? "Feedback OK" : "NO FEEDBACK"}`);
    svg += elbowH(460, P1Y, 460, RAY + RAH * 0.3, hc, "man_ram1", p1Run);
    svg += pipe(460, RAY + RAH * 0.3, RAX + RAW, RAY + RAH * 0.3, hc, "man_ram2", p1Run);
    // ── HYDRAULIC RETURN LINE (ram → HPU sump, physically required for closed loop) ──
    const retY = RAY + RAH * 0.7;
    svg += pipe(RAX, retY, P1X + 22, retY, C.pipe_hyd, "hyd_ret_h", p1Run);
    svg += elbowH(P1X + 22, retY, P1X + 22, 255, C.pipe_hyd, "hyd_ret_v", p1Run);
    svg += `<text x="${P1X + 26}" y="${retY - 5}" fill="${C.pipe_hyd}" font-size="8" opacity=".7">← RET.</text>`;
    const RSX = RAX + RAW / 2, RSY = RAY + RAH;
    svg += `<line x1="${RSX}" y1="${RSY}" x2="${RSX}" y2="${RSY + 50}" stroke="${pressOk ? C.on : C.off}" stroke-width="5" stroke-linecap="round"/>`;
    const blade = rudder / 35, bx = RSX + blade * 40;
    svg += `<path d="M${RSX},${RSY + 50} L${bx - 12},${RSY + 90} L${bx + 12},${RSY + 90} Z" fill="${pressOk ? "#0a2040" : "#0a1020"}" stroke="${pressOk ? C.on : C.off}" stroke-width="2"/>`;
    svg += `<text x="${RSX}" y="${RSY + 105}" text-anchor="middle" fill="${C.on}" font-size="10" font-weight="700">${rudder >= 0 ? "STBD " : "PORT "}${Math.abs(rudder).toFixed(0)}°</text>`;
    svg += `<rect x="${RAX - 60}" y="${RAY + 25}" width="30" height="24" rx="3" fill="${fbOk ? "#0a1e10" : "#1e0a0a"}" stroke="${fbOk ? C.on : C.alarm}" stroke-width="1.5"/>`;
    svg += `<text x="${RAX - 45}" y="${RAY + 40}" text-anchor="middle" fill="${fbOk ? C.on : C.alarm}" font-size="8">${L("rfpu")}</text>`;
    svg += `<text x="350" y="50" text-anchor="middle" fill="${C.muted}" font-size="9">${L("HELM ORDER:")}</text>`;
    svg += `<text x="350" y="70" text-anchor="middle" fill="${C.cyan}" font-size="16" font-weight="700">${ordered >= 0 ? "STBD " : "PORT "}${Math.abs(ordered).toFixed(0)}°</text>`;
    svg += divider(PD, 22, H - 5); const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${hc}" font-size="10" font-weight="700">STEERING INSTRUMENTS</text>`;
    svg += panelBox(PD + 5, 43, PW - 10, 110, "RUDDER ANGLE");
    const cxR = PD + 5 + (PW - 10) / 2, cyR = 100, rR = 40;
    svg += `<circle cx="${cxR}" cy="${cyR}" r="${rR}" fill="#030a12" stroke="${C.panelBdr}" stroke-width="1.5"/>`;
    for (let deg = -35; deg <= 35; deg += 5) { const ang = (deg / 35) * 90 - 90, rad = ang * Math.PI / 180; const x1 = cxR + (rR - 4) * Math.cos(rad), y1 = cyR + (rR - 4) * Math.sin(rad), x2 = cxR + (rR - 12) * Math.cos(rad), y2 = cyR + (rR - 12) * Math.sin(rad); svg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${C.muted}" stroke-width="${deg % 10 === 0 ? 2 : 1}"/>`; }
    svg += `<text x="${cxR - rR + 4}" y="${cyR + 4}" text-anchor="middle" fill="${C.text}" font-size="7">PORT</text>`;
    svg += `<text x="${cxR + rR - 4}" y="${cyR + 4}" text-anchor="middle" fill="${C.text}" font-size="7">STBD</text>`;
    const ordRad = ((ordered / 35) * 90 - 90) * Math.PI / 180;
    svg += `<line x1="${cxR}" y1="${cyR}" x2="${cxR + (rR - 8) * Math.cos(ordRad)}" y2="${cyR + (rR - 8) * Math.sin(ordRad)}" stroke="white" stroke-width="2" opacity=".5"/>`;
    const rudRad = ((rudder / 35) * 90 - 90) * Math.PI / 180;
    svg += `<line x1="${cxR}" y1="${cyR}" x2="${cxR + (rR - 6) * Math.cos(rudRad)}" y2="${cyR + (rR - 6) * Math.sin(rudRad)}" stroke="${C.cyan}" stroke-width="3" filter="url(#glow_s)"/>`;
    svg += `<circle cx="${cxR}" cy="${cyR}" r="4" fill="${C.cyan}"/>`;
    svg += `<text x="${cxR}" y="${cyR + rR + 12}" text-anchor="middle" fill="${C.cyan}" font-size="12" font-weight="700">${rudder >= 0 ? "▶ " : "◀ "}${Math.abs(rudder).toFixed(1)}°</text>`;
    svg += panelBox(PD + 5, 160, PW - 10, 65, "HYD. PRESSURE");
    svg += gauge(PD + 5 + (PW - 10) / 2, 197, 20, press, 0, 250, "", "", `${pfx}hyp`, 100, 80);
    svg += panelBox(PD + 5, 230, PW - 10, 40, "OIL LEVEL");
    const oilBW = Math.min(1, oil / 100) * (PW - 28), oilC = oil < 50 ? C.alarm : oil < 70 ? C.warn : C.on;
    svg += `<rect x="${PD + 15}" y="250" width="${PW - 26}" height="16" rx="3" fill="#030a12" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${PD + 15}" y="250" width="${oilBW}" height="16" rx="3" fill="${oilC}" opacity=".6"/>`;
    svg += `<text x="${PD + PW / 2}" y="262" text-anchor="middle" fill="${oilC}" font-size="10" font-weight="700">${oil.toFixed(0)}%</text>`;
    svg += panelBox(PD + 5, 278, PW - 10, 70, "STATUS");
    [[`Pump P1`, p1Run, false], [`Pressure OK`, pressOk, true], [`Feedback OK`, fbOk, true], [`Oil OK`, oil > 50, false]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${301 + i * 13}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${301 + i * 13 + 4}" fill="${it[1] ? C.textHi : C.muted}" font-size="8.5">${it[0]}</text>`;
    });
    svg += legend(PD, H, [
      { color: C.pipe_hyd, label: "Hydraulic / Гідравліка" },
      { color: C.pipe_elec, label: "Electrical / Електрика" },
    ]);
    svg += `</svg>`; return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 9 — FUEL CONDITIONING MODULE (FCM One)
  // ════════════════════════════════════════════════════════════════════════

  function renderFCM(W, H, st, isModal) {
    const pfx = isModal ? "m_" : ""; const s = st || {};
    const run = !!s.running, hOn = !!s.heater_on, viscOk = !!s.viscometer_ok;
    const temp = typeof s.fuel_temp_c === "number" ? s.fuel_temp_c : 135;
    const visc = typeof s.viscosity_cst === "number" ? s.viscosity_cst : 11.8;
    const press = typeof s.pressure_bar === "number" ? s.pressure_bar : 6.0;
    const flow = typeof s.flow_ls === "number" ? s.flow_ls : 1.5;
    const viscOkR = visc >= 8 && visc <= 15, PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_fuel}" font-size="11" font-weight="700">FCM ONE  /  FUEL CONDITIONING MODULE (ALFA LAVAL)</text>`;
    const fc = C.pipe_fuel, sc = C.pipe_steam;
    svg += vessel(15, 190, 55, 120, L("HFO SERVICE TANK"), fc);
    const PX = 150, PY = 250;
    svg += pipe(70, 250, PX - 20, PY, fc, "tank_pump", run);
    svg += `<circle cx="${PX}" cy="${PY}" r="20" fill="#06111e" stroke="${run ? C.on : C.off}" stroke-width="3" ${run ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${PX - 9},${PY + 9} ${PX - 9},${PY - 9} ${PX + 11},${PY}" fill="${run ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${PX}" y="${PY + 33}" text-anchor="middle" fill="${C.text}" font-size="8">${L("SUPPLY PUMP")}</text>`;
    svg += tipRect(PX - 22, PY - 22, 44, 44, `Supply Pump SP-1  ${run ? "RUNNING" : "STOPPED"}  HP:${press.toFixed(1)}bar  LP:${(typeof s.lp_pressure_bar === "number" ? s.lp_pressure_bar : 4).toFixed(1)}bar`, run ? "stop_fcm" : "start_fcm");
    svg += led(PX + 26, PY - 26, run, `${pfx}sp_led`);
    // Standby pump indicator — appears when standby auto-started
    if (!!s.standby_pump_running) {
      svg += `<circle cx="${PX + 32}" cy="${PY + 12}" r="9" fill="#06111e" stroke="${C.warn}" stroke-width="1.5" filter="url(#glow_s)"/>`;
      svg += `<text x="${PX + 32}" y="${PY + 13}" text-anchor="middle" dominant-baseline="central" fill="${C.warn}" font-size="6" font-weight="700">SBY</text>`;
    }
    // Fault badge when both pumps are down while system should be running
    if (!s.supply_pump_running && !s.standby_pump_running && run) {
      svg += `<circle cx="${PX + 16}" cy="${PY - 18}" r="8" fill="${C.alarm}" opacity=".92"/>`;
      svg += `<text x="${PX + 16}" y="${PY - 17}" text-anchor="middle" dominant-baseline="central" fill="#fff" font-size="9" font-weight="700">!</text>`;
    }
    const HX = 255, HY = 145, HW = 95, HH = 165;
    svg += pipe(PX + 20, PY, HX, PY, fc, "pump_heat", run);
    svg += elbowH(HX, PY, HX, HY + HH, fc, "elb_heat", run);
    svg += pipe(HX, HY + HH, HX + HW, HY + HH, fc, "heat_in", run);
    // ISA heat exchanger symbol for FCM heater
    svg += heatExSym(HX, HY, HW, HH, hOn, `${pfx}fcm_hx`, isUA() ? "НАГРІВАЧ" : "HEATER", hOn ? `${temp.toFixed(0)}°C` : null);
    svg += tipRect(HX, HY, HW, HH, `Steam Heater EPC-60  Temp:${temp.toFixed(0)}°C  Visc:${visc.toFixed(1)}cSt  ${hOn ? "ON" : "OFF"}  ${s.on_diesel ? "DO MODE" : "HFO MODE"}`, hOn ? "switch_diesel" : "restore_heating");
    // FIX-FCM: temperature shown inside heatExSym already — removed duplicate labelPill to prevent overlap
    svg += `<line x1="${HX + HW / 2}" y1="${HY}" x2="${HX + HW / 2}" y2="${HY - 55}" stroke="${hOn ? sc : C.muted}" stroke-width="2" stroke-dasharray="5,3"/>`;
    svg += led(HX + HW, HY, hOn, `${pfx}heat_led`);
    const VX = HX + HW + 60, VY = HY + HH;
    svg += pipe(HX + HW, VY, VX - 15, VY, fc, "heat_visc", run);
    svg += `<rect x="${VX - 14}" y="${VY - 18}" width="28" height="36" rx="4" fill="${viscOk ? "#0a1e10" : "#1e0a0a"}" stroke="${viscOk ? C.on : C.alarm}" stroke-width="2"/>`;
    svg += `<text x="${VX}" y="${VY + 4}" text-anchor="middle" fill="${viscOk ? C.on : C.alarm}" font-size="8" font-weight="700">VM</text>`;
    svg += `<text x="${VX}" y="${VY + 24}" text-anchor="middle" fill="${viscOkR ? C.on : C.alarm}" font-size="8">${visc.toFixed(1)} cSt</text>`;
    const PCX = VX + 60, PCY = VY;
    svg += pipe(VX + 14, VY, PCX - 12, PCY, fc, "visc_pc", run);
    svg += `<polygon points="${PCX - 10},${PCY - 10} ${PCX + 10},${PCY - 10} ${PCX},${PCY + 10}" fill="#06111e" stroke="${run ? fc : C.off}" stroke-width="1.5"/>`;
    svg += `<polygon points="${PCX - 10},${PCY + 10} ${PCX + 10},${PCY + 10} ${PCX},${PCY - 10}" fill="#06111e" stroke="${run ? fc : C.off}" stroke-width="1.5"/>`;
    svg += `<text x="${PCX}" y="${PCY + 24}" text-anchor="middle" fill="${fc}" font-size="8">PCV</text>`;
    svg += tipRect(PCX - 12, PCY - 12, 24, 24, `PCV  HP:${press.toFixed(1)}bar  ${s.on_diesel ? "DO Mode" : "HFO Mode"}`);
    svg += `<text x="${PCX}" y="${PCY - 18}" text-anchor="middle" fill="${C.pipe_steam}" font-size="8">${press.toFixed(1)} bar</text>`;
    svg += tipRect(PCX - 14, PCY - 22, 28, 34, `Steam Press:${press.toFixed(1)}bar  Visc:${visc.toFixed(1)}cSt  ${hOn ? "Heater ON" : "Heater OFF"}`);
    svg += pipe(PCX + 10, PCY, PD - 14, PCY, run ? fc : C.off, "pcv_engine", run);
    svg += `<text x="${PD - 12}" y="${PCY - 10}" text-anchor="end" fill="${run ? fc : C.muted}" font-size="9" font-weight="700">→ ENGINE</text>`;
    svg += `<text x="${PD - 12}" y="${PCY + 4}" text-anchor="end" fill="${s.on_diesel ? C.warn : C.muted}" font-size="8">${s.on_diesel ? "DIESEL MODE" : "HFO MODE"}</text>`;
    svg += divider(PD, 22, H - 5); const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${fc}" font-size="10" font-weight="700">FCM INSTRUMENTS</text>`;
    svg += panelBox(PD + 5, 43, PW / 2 - 4, 78, "°C");
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 83, 20, temp, 60, 180, "", "", `${pfx}temp`, 150, 165);
    svg += panelBox(PD + PW / 2 + 3, 43, PW / 2 - 8, 78, "cSt");
    const vCol = visc > 20 ? C.alarm : visc > 15 ? C.warn : visc < 8 ? C.warn : C.on;
    svg += gauge(PD + PW / 2 + 3 + (PW / 2 - 8) / 2, 83, 20, visc, 0, 60, "", "", `${pfx}visc`, 20, 50);

    svg += panelBox(PD + 5, 135, PW / 2 - 4, 50, "HP bar");
    svg += digDisplay(PD + 7, 155, PW / 2 - 10, 22, press, "b", "", `${pfx}press`, press < 3 ? C.alarm : C.on);
    svg += panelBox(PD + PW / 2 + 3, 135, PW / 2 - 8, 50, "FLOW");
    svg += digDisplay(PD + PW / 2 + 5, 155, PW / 2 - 10, 22, flow, "Ls", "", `${pfx}flow`, C.on);
    svg += panelBox(PD + 5, 192, PW - 10, 80, "STATUS");
    [[`Supply Pump`, run, false], [`Heater ON`, hOn, false], [`Viscometer OK`, viscOk, true], [`Visc. 8-15 cSt`, viscOkR, true], [`Pressure OK`, press >= 3, true]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${210 + i * 13}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${210 + i * 13 + 4}" fill="${it[1] ? C.textHi : C.muted}" font-size="8.5">${it[0]}</text>`;
    });
    const fcmA = []; if (visc > 20) fcmA.push("⚠ HIGH VISCOSITY — CHECK HEATER"); if (!viscOk) fcmA.push("⚠ VISCOMETER FAULT"); if (press < 3) fcmA.push("⚠ LOW FUEL PRESSURE");
    svg += panelBox(PD + 5, 280, PW - 10, 52, "ACTIVE ALARMS");
    if (!fcmA.length) svg += `<text x="${PD + PW / 2}" y="308" text-anchor="middle" fill="${C.on}" font-size="10">✓ ALL NORMAL</text>`;
    else fcmA.slice(0, 3).forEach((a, i) => svg += `<text x="${PD + 10}" y="${298 + i * 13}" fill="${C.alarm}" font-size="8">${a}</text>`);
    svg += legend(PD, H, [
      { color: C.pipe_fuel, label: "HFO / Мазут" },
      { color: C.pipe_water, label: "Diesel / Дизель" },
      { color: C.pipe_steam, label: "Steam / Пара", dashed: true },
    ]);
    svg += `</svg>`; return svg;
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LAB 10 — CENTRAL SEAWATER COOLING SYSTEM
  // ════════════════════════════════════════════════════════════════════════

  function renderCSF(W, H, st, isModal) {
    const pfx = isModal ? "m_" : ""; const s = st || {};
    const p1 = s.p1_stage === "running", p2 = s.p2_stage === "running";
    const engT = typeof s.engine_temp_c === "number" ? s.engine_temp_c : 36;
    const flow = typeof s.cooling_flow_ls === "number" ? s.cooling_flow_ls : 25;
    const scDP = typeof s.sea_chest_dp_bar === "number" ? s.sea_chest_dp_bar : 0.2;
    const cDP = typeof s.cooler_dp_bar === "number" ? s.cooler_dp_bar : 0.3;
    const suctP = typeof s.suction_pressure_bar === "number" ? s.suction_pressure_bar : 2.5;
    const ua = typeof s.cooler_ua_factor === "number" ? s.cooler_ua_factor : 1.0;
    const swTin = typeof s.sw_temp_in_c === "number" ? s.sw_temp_in_c : 22;
    const swTout = typeof s.sw_temp_out_c === "number" ? s.sw_temp_out_c : 28;
    const fwT = typeof s.fw_temp_c === "number" ? s.fw_temp_c : 36;
    const engOk = engT <= 42, PD = W - 220;
    let svg = svgOpen(`${pfx}scada_svg`, W, H) + bg(W, H);
    svg += `<rect x="0" y="0" width="${W}" height="22" fill="#0b1828" opacity=".9"/>`;
    svg += `<text x="10" y="15" fill="${C.pipe_water}" font-size="11" font-weight="700">СИСТЕМА ОХОЛОДЖЕННЯ  /  SEAWATER COOLING SYSTEM</text>`;
    const wc = C.pipe_water, fc = "#06b6d4";
    svg += vessel(15, 125, 50, 80, "SEA\nCHEST", wc);
    svg += `<text x="40" y="222" text-anchor="middle" fill="${wc}" font-size="8">${swTin.toFixed(0)}°C</text>`;
    svg += `<circle cx="40" cy="248" r="9" fill="#06111e" stroke="${scDP > 0.4 ? C.alarm : C.muted}" stroke-width="1.5"/>`;
    svg += `<text x="40" y="252" text-anchor="middle" fill="${C.muted}" font-size="6">ΔP</text>`;
    svg += `<text x="40" y="264" text-anchor="middle" fill="${scDP > 0.4 ? C.alarm : C.muted}" font-size="7">${scDP.toFixed(2)}b</text>`;
    const P1X = 160, P1Y = 165, P2X = 160, P2Y = 285;
    // Sea chest → tee → P1 and P2 suction (proper tee junction with dots)
    svg += pipe(65, 165, 65, 285, wc, "sc_header", p1 || p2);  // shared suction header
    svg += pipe(65, 165, P1X - 20, P1Y, wc, "sc_p1", p1);
    svg += pipe(65, 285, P2X - 20, P2Y, wc, "sc_p2", p2);
    // Tee dots at branching points
    svg += `<circle cx="65" cy="165" r="5" fill="${p1 || p2 ? wc : C.off}"/>`;
    svg += `<circle cx="65" cy="285" r="5" fill="${p1 || p2 ? wc : C.off}"/>`;
    svg += `<circle cx="${P1X}" cy="${P1Y}" r="20" fill="#06111e" stroke="${p1 ? C.on : C.off}" stroke-width="2.5" ${p1 ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${P1X - 9},${P1Y + 9} ${P1X - 9},${P1Y - 9} ${P1X + 11},${P1Y}" fill="${p1 ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${P1X}" y="${P1Y + 33}" text-anchor="middle" fill="${C.text}" font-size="8">${L("SW PUMP P1")}</text>`;
    svg += tipRect(P1X - 22, P1Y - 22, 44, 44, `SW Pump P-1  ${p1 ? "RUNNING" : "STOPPED"}  Flow:${flow.toFixed(0)}L/s`, p1 ? "stop_pump" : "start_pump");
    svg += led(P1X + 26, P1Y - 26, p1, `${pfx}p1_led`);
    svg += `<circle cx="${P2X}" cy="${P2Y}" r="20" fill="#06111e" stroke="${p2 ? C.on : C.off}" stroke-width="2.5" ${p2 ? 'filter="url(#glow_s)"' : ""}/>`;
    svg += `<polygon points="${P2X - 9},${P2Y + 9} ${P2X - 9},${P2Y - 9} ${P2X + 11},${P2Y}" fill="${p2 ? C.on : C.off}" opacity=".8"/>`;
    svg += `<text x="${P2X}" y="${P2Y + 33}" text-anchor="middle" fill="${C.text}" font-size="8">${L("SW PUMP P2")}</text>`;
    svg += tipRect(P2X - 22, P2Y - 22, 44, 44, `SW Pump P-2 [SBY]  ${p2 ? "RUNNING" : "STOPPED"}`, p2 ? "stop_pump" : "start_pump");
    svg += led(P2X + 26, P2Y - 26, p2, `${pfx}p2_led`);
    // FIX-CSF-PIPE: Replace thin rect manifold with proper T-junction piping
    // P1 and P2 discharges meet at vertical header x=240, then elbow to cooler
    const MANX = 240, MANY = (P1Y + P2Y) / 2;  // header x=240, midpoint y=225
    svg += pipe(P1X + 20, P1Y, MANX, P1Y, wc, "p1_man", p1);
    svg += pipe(P2X + 20, P2Y, MANX, P2Y, wc, "p2_man", p2);
    // Vertical discharge header connecting both pump outlets
    svg += pipe(MANX, P1Y, MANX, P2Y, wc, "man_vert", p1 || p2);
    // Tee-dot at junction centre
    svg += `<circle cx="${MANX}" cy="${MANY}" r="5" fill="${(p1 || p2) ? wc : C.off}" opacity=".9"/>`;
    const HX = 290, HY = 135, HW = 120, HH = 165;
    // SW inlet: straight horizontal pipe from manifold header directly into cooler left wall at MANY
    svg += pipe(MANX, MANY, HX, MANY, wc, "man_hx", p1 || p2);
    // Cooler box (drawn AFTER pipe so it visually overlaps the pipe end cleanly)
    svg += `<rect x="${HX}" y="${HY}" width="${HW}" height="${HH}" rx="4" fill="#07101a" stroke="${(p1 || p2) ? fc : C.off}" stroke-width="2.5"/>`;
    for (let i = 0; i < 6; i++) svg += `<line x1="${HX + 12 + i * 16}" y1="${HY + 8}" x2="${HX + 12 + i * 16}" y2="${HY + HH - 8}" stroke="${ua > 0.6 ? fc : C.alarm}" stroke-width="2" opacity="${0.3 + ua * 0.5}"/>`;
    svg += `<text x="${HX + HW / 2}" y="${HY + HH / 2 - 6}" text-anchor="middle" fill="${(p1 || p2) ? fc : C.off}" font-size="9" font-weight="700">${L("cooler")}</text>`;
    svg += tipRect(HX, HY, HW, HH, `Central Cooler  UA:${(ua * 100).toFixed(0)}%  ΔP:${cDP.toFixed(2)}bar  EWT:${engT.toFixed(1)}°C  SWT:${swTin.toFixed(0)}→${swTout.toFixed(0)}°C`);
    svg += labelPill(HX + HW / 2, HY + HH / 2 + 8, 'UA: ' + (ua * 100).toFixed(0) + '%', ua > 0.6 ? C.on : C.alarm, 9);
    svg += labelPill(HX + HW / 2, HY - 10, 'ΔP ' + cDP.toFixed(2) + ' bar', cDP > 0.8 ? C.alarm : C.text, 8);
    // SW inlet tee-dot on cooler wall
    svg += `<circle cx="${HX}" cy="${MANY}" r="4" fill="${(p1 || p2) ? wc : C.off}" opacity=".9"/>`;
    svg += pipe(HX + HW, HY + HH * 0.4, PD - 14, HY + HH * 0.4, wc, "sw_hx_out", p1 || p2);
    svg += `<text x="${PD - 12}" y="${HY + HH * 0.4 + 4}" text-anchor="end" fill="${wc}" font-size="8">${swTout.toFixed(0)}°C→OB</text>`;
    const ENGX = HX + HW + 60, ENGY = HY + HH * 0.7;
    svg += `<rect x="${ENGX}" y="${ENGY - 35}" width="70" height="70" rx="8" fill="#07101a" stroke="${engOk ? C.on : C.alarm}" stroke-width="2"/>`;
    svg += `<text x="${ENGX + 35}" y="${ENGY - 10}" text-anchor="middle" fill="${engOk ? C.on : C.alarm}" font-size="10" font-weight="700">${L("engine")}</text>`;
    svg += `<text x="${ENGX + 35}" y="${ENGY + 8}" text-anchor="middle" fill="${engOk ? C.on : C.alarm}" font-size="8">${fwT.toFixed(1)}°C FW</text>`;
    svg += `<text x="${ENGX + 35}" y="${ENGY + 22}" text-anchor="middle" fill="${engOk ? C.muted : C.alarm}" font-size="7">${engT.toFixed(1)}°C</text>`;
    svg += pipe(HX + HW, ENGY, ENGX, ENGY, fc, "hx_eng", p1 || p2);
    // FW return: engine → up → left → enter cooler from TOP (avoids double-bar on left wall)
    svg += elbowH(ENGX + 70, ENGY, ENGX + 70, HY - 12, fc, "eng_ret1", p1 || p2);
    svg += pipe(ENGX + 70, HY - 12, HX + HW * 0.5, HY - 12, fc, "eng_ret2", p1 || p2);
    svg += elbowH(HX + HW * 0.5, HY - 12, HX + HW * 0.5, HY, fc, "eng_ret3", p1 || p2);
    svg += `<circle cx="${HX + HW * 0.5}" cy="${HY}" r="4" fill="${(p1||p2) ? fc : C.off}" opacity=".9"/>`;
    svg += `<circle cx="${HX + HW + 10}" cy="${HY + HH * 0.5}" r="9" fill="#06111e" stroke="${C.pipe_steam}" stroke-width="1.5"/>`;
    svg += `<text x="${HX + HW + 10}" y="${HY + HH * 0.5 + 4}" text-anchor="middle" fill="${C.pipe_steam}" font-size="6" font-weight="700">TI</text>`;
    svg += `<text x="${HX + HW + 22}" y="${HY + HH * 0.5 + 4}" fill="${engOk ? C.on : C.alarm}" font-size="9">${engT.toFixed(1)}°</text>`;
    svg += divider(PD, 22, H - 5); const PW = W - PD - 8;
    svg += `<text x="${PD + PW / 2}" y="36" text-anchor="middle" fill="${wc}" font-size="10" font-weight="700">COOLING SYSTEM INSTRUMENTS</text>`;
    svg += panelBox(PD + 5, 43, PW / 2 - 4, 80, "°C");
    svg += gauge(PD + 5 + (PW / 2 - 4) / 2, 85, 20, engT, 25, 65, "", "", `${pfx}engt`, 42, 52);
    svg += panelBox(PD + PW / 2 + 3, 43, PW / 2 - 8, 80, "L/s");
    svg += gauge(PD + PW / 2 + 3 + (PW / 2 - 8) / 2, 85, 20, flow, 0, 50, "", "", `${pfx}flow`);
    // FIX: wider digDisplay boxes so values don't get clipped
    svg += panelBox(PD + 5, 133, PW / 2 - 4, 50, "SCΔp");
    svg += digDisplay(PD + 10, 152, PW / 2 - 18, 22, scDP, "b", "", `${pfx}scdp`, scDP > 0.4 ? C.alarm : C.on);
    svg += panelBox(PD + PW / 2 + 3, 133, PW / 2 - 8, 50, "HXΔp");
    svg += digDisplay(PD + PW / 2 + 8, 152, PW / 2 - 18, 22, cDP, "b", "", `${pfx}cdp`, cDP > 0.8 ? C.alarm : C.on);
    // FIX: UA bar properly inside its panelBox (was at y=212, box started at y=227)
    svg += panelBox(PD + 5, 190, PW - 10, 48, "COOLER EFFICIENCY (UA)");
    const uaW = Math.min(1, ua) * (PW - 28), uaCol = ua < 0.5 ? C.alarm : ua < 0.7 ? C.warn : C.on;
    svg += `<rect x="${PD + 15}" y="208" width="${PW - 28}" height="16" rx="3" fill="#030a12" stroke="${C.panelBdr}"/>`;
    svg += `<rect x="${PD + 15}" y="208" width="${uaW}" height="16" rx="3" fill="${uaCol}" opacity=".6"/>`;
    svg += `<text x="${PD + PW / 2}" y="220" text-anchor="middle" fill="${uaCol}" font-size="9" font-weight="700">${(ua * 100).toFixed(0)}% ${ua > 0.7 ? "CLEAN" : ua > 0.5 ? "FOULING" : "FOUL"}</text>`;
    // FIX: STATUS panel starts after UA panel, items use correct y offsets
    svg += panelBox(PD + 5, 244, PW - 10, 72, "STATUS");
    [[`SW Pump P1`, p1, false], [`SW Pump P2 (SBY)`, p2, false], [`Engine Temp <42°C`, engOk, true], [`Cooler UA OK`, ua > 0.5, true]].forEach((it, i) => {
      const col = it[2] ? (it[1] ? C.on : C.alarm) : (it[1] ? C.on : C_INACTIVE_LED);
      svg += `<circle cx="${PD + 15}" cy="${265 + i * 13}" r="4" fill="${col}"/>`;
      svg += `<text x="${PD + 25}" y="${265 + i * 13 + 4}" fill="${it[1] ? C.textHi : C.muted}" font-size="8.5">${it[0]}</text>`;
    });
    svg += legend(PD, H, [
      { color: C.pipe_water, label: "SW / Морська вода" },
      { color: C.pipe_ref, label: "FW / Прісна вода" },
      { color: C.alarm, label: "High Temp / Висока темп." },
    ]);
    svg += `</svg>`; return svg;
  }

  const RENDERERS = {
    oily_water_separator: renderOWS,
    boiler: renderBoiler,
    fw_generator: renderFWG,
    refrigeration: renderRefrig,
    hydrophore: renderHydrophore,
    diesel_generator: renderDG,
    fuel_separator: renderFuelSep,
    steering_gear: renderSteering,
    fuel_conditioning: renderFCM,
    cooling_system: renderCSF,
  };

  // ── Shared pipe legend ──────────────────────────────────────────────────
  function legend(W, H, items) {
    // items: [{color, label, dashed?}]
    const LY = H - 20;
    let s = `<rect x="0" y="${LY - 12}" width="${W}" height="32" fill="${C.bg}" opacity=".9"/>`;
    let cx = 12;
    items.forEach(it => {
      const da = it.dashed ? ' stroke-dasharray="6,4"' : '';
      // Shadow line for 3D effect on legend
      s += `<line x1="${cx}" y1="${LY + 1}" x2="${cx + 36}" y2="${LY + 1}" stroke="#000" stroke-width="6" stroke-opacity=".3" stroke-linecap="round"/>`;
      s += `<line x1="${cx}" y1="${LY}" x2="${cx + 36}" y2="${LY}" stroke="${it.color}" stroke-width="5" stroke-linecap="round"${da}/>`;
      s += `<line x1="${cx}" y1="${LY - 1}" x2="${cx + 36}" y2="${LY - 1}" stroke="rgba(255,255,255,.12)" stroke-width="2" stroke-linecap="round"/>`;
      s += `<text x="${cx + 41}" y="${LY + 4}" fill="${C.textHi}" font-size="9.5" font-weight="600">${it.label}</text>`;
      cx += 42 + it.label.length * 5.5 + 10;
    });
    return s;
  }

  function render(moduleId, container, state, labDef, isModal) {
    const W = isModal ? 1100 : 960;
    const H = isModal ? 540 : 540;
    const fn = RENDERERS[moduleId];
    const html = fn
      ? fn(W, H, state, isModal)
      : renderGeneric(W, H, state, labDef, isModal);
    container.innerHTML = html;
  }

  // FIX #26: update() patches individual SVG text/rect elements in-place
  // rather than rebuilding the entire DOM. This eliminates 14 400 full
  // innerHTML redraws per 4-hour session and ends GC pressure.
  // Strategy: generate new SVG in a detached div, then copy only the
  // elements with an id — gauges, digital displays, valve states, labels.
  function update(moduleId, container, state, labDef, isModal) {
    const svg = container.querySelector("svg");
    if (!svg) {
      // No SVG yet — fall back to full render
      render(moduleId, container, state, labDef, isModal);
      return;
    }
    const W = isModal ? 1100 : 960;
    const H = 540;
    const fn = RENDERERS[moduleId];
    const html = fn
      ? fn(W, H, state, !!isModal)
      : renderGeneric(W, H, state, labDef, !!isModal);

    // Parse new SVG in a detached element
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    const newSvg = tmp.querySelector("svg");
    if (!newSvg) { container.innerHTML = html; return; }

    // Patch only elements that have an id (needles, value texts, fill rects)
    newSvg.querySelectorAll("[id]").forEach(newEl => {
      const oldEl = svg.getElementById(newEl.id);
      if (!oldEl) return;
      // Copy mutable presentation attributes
      ["x2","y2","stroke","fill","width","opacity","transform"].forEach(attr => {
        const v = newEl.getAttribute(attr);
        if (v !== null && oldEl.getAttribute(attr) !== v) oldEl.setAttribute(attr, v);
      });
      // Copy text content for value labels
      if (newEl.tagName === "text" && oldEl.textContent !== newEl.textContent) {
        oldEl.textContent = newEl.textContent;
      }
    });
  }

  return { render, update };

})();
