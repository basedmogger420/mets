// FIX #46: HTML sanitizer for report export

/* ═══════════════════════════════════════════════════════════════
   METS v1.0 — FEATURES MODULE
   Sound alarms, countdown timer, trend recorder, shortcuts,
   theme toggle, language switcher, PDF export
   ═══════════════════════════════════════════════════════════════ */

// ─── 1. SOUND ALARMS (Web Audio API) ────────────────────────
const AlarmSound = (() => {
  let ctx = null, playing = false, osc = null, gain = null;
  let alarmCount = 0;

  function _ensure() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    return ctx;
  }

  function start() {
    if (playing) return;
    try {
      const c = _ensure();
      osc = c.createOscillator();
      gain = c.createGain();
      osc.type = "square";
      osc.frequency.value = 880;
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(c.destination);
      // Pulsing pattern: 0.3s on, 0.3s off
      const now = c.currentTime;
      for (let i = 0; i < 30; i++) {
        gain.gain.setValueAtTime(0.15, now + i * 0.6);
        gain.gain.setValueAtTime(0, now + i * 0.6 + 0.3);
      }
      osc.start();
      osc.stop(now + 18); // max 18 seconds
      playing = true;
      osc.onended = () => { playing = false; };
    } catch(e) { console.warn("AlarmSound:", e); }
  }

  function stop() {
    if (osc) try { osc.stop(); } catch(e) {}
    playing = false;
  }

  function beep(freq, dur) {
    try {
      const c = _ensure();
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = "sine"; o.frequency.value = freq || 660;
      g.gain.value = 0.1;
      o.connect(g); g.connect(c.destination);
      o.start(); o.stop(c.currentTime + (dur || 0.12));
    } catch(e) {}
  }

  // Called on each telemetry — check for new alarms
  function check(alarms) {
    const activeCount = alarms.filter(a => a.severity > 0).length;
    if (activeCount > alarmCount && activeCount > 0) {
      start();
    }
    alarmCount = activeCount;
  }

  return { start, stop, beep, check };
})();

// Hook ACK button to silence alarm
const _origAckAlarm = window.ackAlarm;
window.ackAlarm = function() {
  AlarmSound.stop();
  AlarmSound.beep(440, 0.08);
  if (typeof _origAckAlarm === 'function') _origAckAlarm();
  else if (typeof sendCmd === 'function' && S.activeLab) {
    sendCmd(S.activeLab, 'acknowledge_alarm', []);
  }
};

// ─── 2. PROCEDURE COUNTDOWN TIMER ──────────────────────────
const ProcTimer = (() => {
  let intervalId = null;

  function update() {
    const procEl = document.getElementById("procedure");
    if (!procEl) return;
    const activeStep = procEl.querySelector(".proc-step.active");
    if (!activeStep) return;

    // Find or create timer element
    let timerEl = activeStep.querySelector(".proc-countdown");
    if (!timerEl) {
      timerEl = document.createElement("div");
      timerEl.className = "proc-countdown";
      activeStep.appendChild(timerEl);
    }

    // Get step data from procedure state
    const state = S.moduleStates[S.activeLab];
    if (!state || !state.procedure) return;
    const proc = state.procedure;
    const activeStepData = (proc.steps || []).find(s => s.active && !s.done);
    if (!activeStepData) return;

    // Calculate time budget (default 60s)
    const budget = activeStepData.time_budget_s || 60;
    const elapsed = activeStepData.elapsed_s || 0;
    const remaining = Math.max(0, budget - elapsed);

    if (remaining > 10) {
      timerEl.textContent = `⏱ ${Math.ceil(remaining)}s`;
      timerEl.className = "proc-countdown";
    } else if (remaining > 0) {
      timerEl.textContent = `⏱ ${Math.ceil(remaining)}s ⚠`;
      timerEl.className = "proc-countdown proc-countdown-warn";
    } else {
      timerEl.textContent = `⏱ OVERTIME +${Math.floor(elapsed - budget)}s`;
      timerEl.className = "proc-countdown proc-countdown-over";
    }
  }

  function start() {
    if (intervalId) return;
    intervalId = setInterval(update, 500);
  }

  function stop() {
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
  }

  return { start, stop, update };
})();

// ─── 3. TREND RECORDER ─────────────────────────────────────
const TrendRecorder = (() => {
  const HISTORY_LEN = 60; // 60 seconds
  const history = {}; // key → [{t, v}]
  let modalOpen = false;
  let activeKey = null;

  function push(key, val) {
    if (!history[key]) history[key] = [];
    const arr = history[key];
    arr.push({ t: Date.now(), v: val });
    if (arr.length > HISTORY_LEN) arr.shift();
  }

  function pushAll(state) {
    if (!state) return;
    for (const [k, v] of Object.entries(state)) {
      if (typeof v === "number" && !k.startsWith("_")) {
        push(k, v);
      }
    }
  }

  function openModal(key, label, unit) {
    activeKey = key;
    modalOpen = true;
    const arr = history[key] || [];
    _renderModal(key, label || key, unit || "", arr);
  }

  function closeModal() {
    modalOpen = false;
    activeKey = null;
    const m = document.getElementById("trendModal");
    if (m) m.classList.add("hidden");
  }

  function _renderModal(key, label, unit, arr) {
    let m = document.getElementById("trendModal");
    if (!m) {
      m = document.createElement("div");
      m.id = "trendModal";
      m.className = "schematic-modal";
      m.innerHTML = `<div class="schematic-modal-backdrop" onclick="TrendRecorder.closeModal()"></div>
        <div class="schematic-modal-content" style="width:min(90vw,700px);max-height:80vh">
          <div class="schematic-modal-header">
            <span id="trendTitle">TREND</span>
            <button class="schematic-modal-close" onclick="TrendRecorder.closeModal()">✕ Close</button>
          </div>
          <div id="trendBody" style="padding:16px;overflow:auto;flex:1"></div>
        </div>`;
      document.body.appendChild(m);
    }
    m.classList.remove("hidden");
    document.getElementById("trendTitle").textContent = `TREND: ${label} (${unit})`;

    const body = document.getElementById("trendBody");
    if (arr.length < 2) {
      body.innerHTML = '<div style="color:var(--text-dim);text-align:center;padding:40px">Waiting for data...</div>';
      return;
    }

    const W = 650, H = 250, pad = 40;
    const vals = arr.map(p => p.v);
    const mn = Math.min(...vals), mx = Math.max(...vals);
    const range = mx - mn || 1;

    let svg = `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block;background:#0a1828;border-radius:4px">`;
    // Grid
    for (let i = 0; i <= 4; i++) {
      const y = pad + (H - 2*pad) * i / 4;
      const v = mx - (range * i / 4);
      svg += `<line x1="${pad}" y1="${y}" x2="${W-10}" y2="${y}" stroke="#1a2a3a" stroke-width="0.5"/>`;
      svg += `<text x="${pad-4}" y="${y+3}" text-anchor="end" fill="#5a6a7a" font-size="9" font-family="monospace">${v.toFixed(1)}</text>`;
    }
    // Time axis
    svg += `<text x="${pad}" y="${H-5}" fill="#5a6a7a" font-size="8">-${arr.length}s</text>`;
    svg += `<text x="${W-10}" y="${H-5}" fill="#5a6a7a" font-size="8" text-anchor="end">now</text>`;

    // Line
    const pts = arr.map((p, i) => {
      const x = pad + (W - pad - 10) * i / (arr.length - 1);
      const y = pad + (H - 2*pad) * (1 - (p.v - mn) / range);
      return `${x},${y}`;
    }).join(" ");
    svg += `<polyline points="${pts}" fill="none" stroke="#06b6d4" stroke-width="2"/>`;
    // Current value dot
    const lastX = W - 10, lastY = pad + (H - 2*pad) * (1 - (vals[vals.length-1] - mn) / range);
    svg += `<circle cx="${lastX}" cy="${lastY}" r="4" fill="#06b6d4"/>`;
    svg += `<text x="${lastX-8}" y="${lastY-8}" fill="#06b6d4" font-size="11" font-weight="700" text-anchor="end">${vals[vals.length-1].toFixed(1)}</text>`;
    svg += `</svg>`;
    body.innerHTML = svg;
  }

  // Auto-refresh open modal
  setInterval(() => {
    if (modalOpen && activeKey && history[activeKey]) {
      const arr = history[activeKey];
      const title = document.getElementById("trendTitle");
      _renderModal(activeKey, title ? title.textContent.replace("TREND: ","").replace(/ \(.*/, "") : activeKey, "", arr);
    }
  }, 1000);

  return { push, pushAll, openModal, closeModal, history };
})();
window.TrendRecorder = TrendRecorder;

// ─── 4. KEYBOARD SHORTCUTS ─────────────────────────────────
document.addEventListener("keydown", (e) => {
  // Don't capture if typing in input
  if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;

  // Space = ACK alarm
  if (e.code === "Space" && S.activeLab) {
    e.preventDefault();
    window.ackAlarm();
  }
  // Escape = back to lab selector
  if (e.code === "Escape" && S.activeLab) {
    e.preventDefault();
    if (typeof goToLabSelector === "function") goToLabSelector();
  }
  // F = fullscreen schematic
  if (e.code === "KeyF" && S.activeLab) {
    if (typeof openSchematicModal === "function") openSchematicModal();
  }
  // T = open trend for first gauge
  if (e.code === "KeyT" && S.activeLab) {
    const state = S.moduleStates[S.activeLab];
    if (state) {
      const firstKey = Object.keys(state).find(k => typeof state[k] === "number" && !k.startsWith("_"));
      if (firstKey) TrendRecorder.openModal(firstKey, firstKey, "");
    }
  }
  // R = reset current lab (with confirmation)
  if (e.code === "KeyR" && S.activeLab) {
    if (confirm("Reset lab? All progress will be lost.")) {
      if (typeof resetLab === "function") resetLab();
    }
  }
  // 1-9 = quick lab select (only from selector screen)
  if (!S.activeLab && e.key >= "1" && e.key <= "9") {
    const idx = parseInt(e.key) - 1;
    const cards = document.querySelectorAll(".lab-card");
    if (cards[idx]) cards[idx].click();
  }
});

// ─── 5. THEME TOGGLE (Dark/Light) ──────────────────────────
const ThemeToggle = (() => {
  let isDark = true; // default

  function toggle() {
    isDark = !isDark;
    document.body.classList.toggle("light-theme", !isDark);
    const btn = document.getElementById("themeToggle");
    if (btn) btn.textContent = isDark ? "☀" : "🌙";
    try { localStorage.setItem("mets_theme", isDark ? "dark" : "light"); } catch(e) {}
  }

  function init() {
    try {
      const saved = localStorage.getItem("mets_theme");
      if (saved === "light") { isDark = false; document.body.classList.add("light-theme"); }
    } catch(e) {}
  }

  return { toggle, init };
})();

// ─── 6. LANGUAGE SWITCHER (UA/EN) ──────────────────────────
const LangSwitch = (() => {
  let lang = "en"; // default

  function toggle() {
    lang = lang === "en" ? "ua" : "en";
    document.body.setAttribute("data-lang", lang);
    const btn = document.getElementById("langToggle");
    if (btn) btn.textContent = lang === "en" ? "UA" : "EN";
    try { localStorage.setItem("mets_lang", lang); } catch(e) {}
    // Update section headers
    _updateLabels();
    // Trigger full UI re-render so gauges/procedure/instructor use new language
    if (typeof updateSimView === "function" && window._activeLab) {
      updateSimView();
    }
    if (typeof renderInstructor === "function" && window._activeLab) {
      renderInstructor();
    }
    // Update lab header name
    if (window._activeLab && typeof S !== "undefined") {
      const lab = S.labs.find(l => (l.id||l.module_id) === window._activeLab);
      if (lab) {
        const isUA = lang === "ua";
        const name = isUA
          ? (lab.title_ua || lab.name_ua || `Лаб ${lab.lab_no||""}: ${lab.name_en||window._activeLab}`)
          : `Lab ${lab.lab_no||""}: ${lab.name_en||window._activeLab}`;
        const el = document.getElementById("labName");
        if (el) el.textContent = name;
        const schTitle = document.getElementById("schTitle");
        if (schTitle) schTitle.textContent = (isUA
          ? (lab.title_ua || lab.name_ua || lab.name_en || "СИСТЕМА")
          : (lab.name_en || "SYSTEM P&ID")).toUpperCase();
      }
    }
    // Update lab selector card subtitles if visible
    document.querySelectorAll(".lab-card").forEach(card => {
      const mid = card.onclick?.toString().match(/'([^']+)'/)?.[1];
      if (!mid) return;
      const lab = S?.labs?.find(l => (l.id||l.module_id) === mid);
      if (!lab) return;
      const ua = card.querySelector(".name-ua");
      const en = card.querySelector(".name");
      if (ua) ua.style.display = lang === "ua" ? "block" : "none";
    });
  }

  function get() { return lang; }

  function _updateLabels() {
    const ua = lang === "ua";
    const T = {
      "gauges":     ua ? "Прилади / System Gauges" : "System Gauges / Прилади",
      "controls":   ua ? "Керування / Controls"    : "Controls / Керування",
      "procedure":  ua ? "Процедура / Procedure"   : "Procedure / Процедура",
      "alarmPanel": ua ? "Аварійні сигнали"        : "Alarms / Аварійні сигнали",
      "scorePanel": ua ? "Оцінка / Score"           : "Score / Оцінка",
    };
    document.querySelectorAll(".rp-header-title").forEach(el => {
      const section = el.closest(".rp-section");
      if (!section || el.id === "alarmPanelTitle") return;
      const panel = section.querySelector("[id]");
      if (panel && T[panel.id]) el.textContent = T[panel.id];
    });
    // Alarm panel title (has id so needs direct update)
    const apt = document.getElementById("alarmPanelTitle");
    if (apt) apt.textContent = ua ? "Аварійні сигнали" : "Alarms / Аварійні сигнали";
    // ACK button
    const ackBtn = document.getElementById("ackBtn");
    if (ackBtn && !ackBtn.classList.contains("ack-btn-alarm")) {
      ackBtn.textContent = ua ? "ПІДТВ" : "ACK";
    }
    // Shortcut hint
    const hint = document.getElementById("shortcutHint");
    if (hint) hint.textContent = ua
      ? "ПРОБІЛ=Підтвердити  ESC=Назад  F=Схема  T=Тренд  R=Скинути"
      : "SPACE=ACK   ESC=Back   F=Fullscreen   T=Trend   R=Reset";
    // Tab back button
    const tabBack = document.getElementById("tabBackBtn");
    if (tabBack) tabBack.textContent = ua ? "← НАЗАД" : "← BACK";
    // Hero title & subtitle on lab selector
    const heroTitle = document.getElementById("heroTitle");
    if (heroTitle) heroTitle.textContent = ua
      ? "Тренажер з суднової механіки"
      : "Marine Engineering Training Simulator";
    const heroSub = document.getElementById("heroSubtitle");
    if (heroSub) heroSub.textContent = ua
      ? "STCW A-III/1 — Оберіть лабораторну роботу"
      : "Marine Engineering Training Simulator — Select a lab";
    // Connection overlay
    const connMsg = document.getElementById("connMsg");
    if (connMsg) {
      const wsUrl = document.getElementById("connWsUrl");
      const urlText = wsUrl ? wsUrl.textContent : "ws://localhost:8765";
      connMsg.innerHTML = (ua ? "Підключення до сервера симуляції…" : "Connecting to simulation server…")
        + `<br><small id="connWsUrl">${urlText}</small>`;
    }
    // Disconnect overlay
    const discTitle = document.getElementById("disconnectTitle");
    if (discTitle) discTitle.textContent = ua ? "Сервер відключений" : "Server Disconnected";
    const discMsg = document.getElementById("disconnectMsg");
    if (discMsg) discMsg.textContent = ua ? "Автоматичне перепідключення…" : "Reconnecting automatically…";
    const retryBtn = document.getElementById("retryBtn");
    if (retryBtn) retryBtn.textContent = ua ? "↺ ПОВТОРИТИ" : "↺ RETRY NOW";
    // Schematic modal close button
    const schClose = document.getElementById("schematicCloseBtn");
    if (schClose) schClose.textContent = ua ? "✕ Закрити" : "✕ Close";
    // labName on selector screen (when no lab selected)
    if (!window._activeLab) {
      const labNameEl = document.getElementById("labName");
      if (labNameEl) labNameEl.textContent = ua
        ? "Тренажер з суднової механіки"
        : "Marine Engineering Training Simulator";
    }
  }

  function init() {
    try {
      const saved = localStorage.getItem("mets_lang");
      if (saved) lang = saved;
    } catch(e) {}
    document.body.setAttribute("data-lang", lang);
    // FIX: Update button text to match restored language — previously
    // only toggle() updated the button, so a restored "ua" from
    // localStorage showed "UA" on the button (the HTML default),
    // making it look like English was selected.
    const btn = document.getElementById("langToggle");
    if (btn) btn.textContent = lang === "en" ? "UA" : "EN";
    _updateLabels();
  }

  return { toggle, get, init };
})();


// ── FIX #46: HTML escape for report export — prevents stored XSS in downloaded reports ──

// ─── 7. PDF REPORT EXPORT ──────────────────────────────────

// ── GOLD FIX #46: Sanitize server-controlled HTML report data ─────────────

// ─── FIX #46: HTML escaping for report export ─────────────────────────────
function _escRpt(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function exportReport() {
  const state = S.moduleStates[S.activeLab];
  if (!state || !state.procedure) {
    showToast("No procedure data to export", "warn");
    return;
  }
  const proc = state.procedure;
  const report = proc.report;
  const labDef = S.labDefs[S.activeLab] || {};
  const labName = labDef.title_en || S.activeLab;

  let html = `<!DOCTYPE html><html><head><meta charset="utf-8">
    <title>METS Report - ${labName}</title>
    <style>
      body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; color: #1a1a1a; }
      h1 { color: #0a4a6a; border-bottom: 2px solid #06b6d4; padding-bottom: 8px; }
      h2 { color: #2a3a4a; margin-top: 24px; }
      table { border-collapse: collapse; width: 100%; margin: 12px 0; }
      th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: left; }
      th { background: #f0f4f8; font-weight: 600; }
      .pass { color: #0a8a0a; font-weight: bold; }
      .fail { color: #cc0000; font-weight: bold; }
      .score { font-size: 2em; font-weight: bold; color: #06b6d4; }
      .footer { margin-top: 40px; padding-top: 12px; border-top: 1px solid #ddd; color: #888; font-size: 0.85em; }
    </style></head><body>
    <h1>⚓ METS v1.0 — Lab Report / Звіт лабораторної роботи</h1>
    <p><strong>Lab / Лаба:</strong> ${_escRpt(labName)}</p>
    <p><strong>Module:</strong> ${S.activeLab}</p>
    <p><strong>Date / Дата:</strong> ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</p>
    ${state.scenario_id ? `<p><strong>Scenario / Сценарій:</strong> ${_escRpt(state.scenario_id)}</p>` : ""}`;

  if (report) {
    html += `<h2>Score / Оцінка</h2>
      <p class="score">${report.score} / ${report.max_score}</p>
      <p>Grade: <span class="${report.grade === 'FAIL' ? 'fail' : 'pass'}">${report.grade}</span></p>
      ${report.hard_fail ? `<p class="fail">⚠ Hard Fail: ${_escRpt(report.hard_fail_reason)}</p>` : ""}
      <p>Total elapsed: ${report.elapsed_s}s | Penalties: ${report.penalties} pts</p>`;
  }

  html += `<h2>Procedure Steps / Кроки процедури</h2><table>
    <tr><th>#</th><th>Step</th><th>Points</th><th>Penalty</th><th>Done</th></tr>`;
  (proc.steps || []).forEach((step, i) => {
    html += `<tr>
      <td>${i+1}</td>
      <td>${_escRpt(step.description || step.step_id)}</td>
      <td>${step.points}</td>
      <td>${step.penalty || 0}</td>
      <td>${step.done ? "✓" : "—"}</td>
    </tr>`;
  });
  html += `</table>`;

  if (proc.history && proc.history.length) {
    html += `<h2>Action Timeline / Хронологія дій</h2><table>
      <tr><th>Step</th><th>Time (s)</th><th>Points</th><th>Penalty</th><th>Auto</th></tr>`;
    proc.history.forEach(h => {
      html += `<tr><td>${_escRpt(h.step_id)}</td><td>${h.elapsed_s}</td><td>${h.points}</td><td>${h.penalty}</td><td>${h.auto ? "AUTO" : ""}</td></tr>`;
    });
    html += `</table>`;
  }

  html += `<div class="footer">
    <p>Generated by METS v1.0 — Marine Engineering Training Simulator</p>
    <p>STCW A-III/1 Competence Assessment</p>
  </div></body></html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `METS_Report_${S.activeLab}_${new Date().toISOString().slice(0,10)}.html`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Report exported! / Звіт збережено!", "info");
}
window.exportReport = exportReport;

// ─── 8. INIT ON LOAD ───────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  ThemeToggle.init();
  LangSwitch.init();
  ProcTimer.start();
});

// ─── 9. HOOKS INTO EXISTING TELEMETRY ──────────────────────
// Patch the existing handleMessage to add our features
const _origHandleMessage = window.handleMessage;
if (typeof _origHandleMessage === "function") {
  window.handleMessage = function(msg) {
    _origHandleMessage(msg);
    // After processing telemetry, run our hooks
    if (msg.type === "telemetry") {
      const state = msg.data || msg.state;
      if (state) {
        TrendRecorder.pushAll(state);
        AlarmSound.check(S.alarms || []);
        ProcTimer.update();
      }
    }
  };
}
