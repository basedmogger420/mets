// Auto-generated at server startup — do not edit manually
// This file is overwritten each time sim_server.py starts
// FIX: Support both localhost and LAN access
window.METS_HTTP_PORT = 8080;
window.METS_WS_PORT   = 8765;
window.METS_WS_URL    = 'ws://' + (window.location.hostname || 'localhost') + ':8765';
window.METS_AUTH_TOKEN = '';
