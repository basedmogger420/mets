OFFLINE FONTS — METS v1.0
=========================
To enable offline font rendering (for classrooms without internet access),
place the following woff2 files in this directory:

  ShareTechMono.woff2   — Share Tech Mono 400
  Rajdhani-500.woff2    — Rajdhani 500
  Rajdhani-600.woff2    — Rajdhani 600
  Rajdhani-700.woff2    — Rajdhani 700
  Orbitron-500.woff2    — Orbitron 500
  Orbitron-700.woff2    — Orbitron 700

Download from: https://fonts.google.com
(Search for each font, click "Download family")

If these files are absent, the simulator will attempt to load fonts from
Google Fonts CDN. If that also fails, system fallback fonts are used and
the simulator remains fully functional.
