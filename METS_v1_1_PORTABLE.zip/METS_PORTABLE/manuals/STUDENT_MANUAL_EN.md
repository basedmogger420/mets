# METS v1.0 — Student Manual
## Marine Engineering Training Simulator
### STCW A-III/1 Competence Assessment

---

## Getting Started

1. **Launch the simulator**: Run `run_simulator.py` or double-click `START_SIMULATOR.bat`
2. **Wait for browser**: The browser opens automatically to `http://localhost:8080`
3. **Select a lab**: Click any lab card to begin
4. **Wait for instructor**: Your instructor will inject a fault scenario using the **INSTRUCTOR** panel

---

## Interface Overview

```
┌─────────── HEADER ───────────────────────────────────────────┐
│ ⚓ METS  │  Lab Name  │  T+00s  │  ● ONLINE  │  0 ALARMS    │
├─────────── LEFT: P&ID SCHEMATIC ──────────────────────────────┤
│                                                               │
│   Real-time P&ID diagram of the equipment                     │
│   Colour-coded pipes, animated flow, live readings            │
│                                                               │
├─────────── RIGHT PANEL ───────────────────────────────────────┤
│ SYSTEM GAUGES  │  Pressure, temperature, flow dials          │
│ CONTROLS       │  Start/Stop/Action buttons                   │
│ PROCEDURE      │  STCW step-by-step checklist                 │
│ ALARMS         │  Active alarm list with severity              │
│ SCORE          │  Live score and grade                         │
│ INSTRUCTOR     │  (Instructor use only — fault injection)      │
└───────────────────────────────────────────────────────────────┘
```

---

## How an Assessment Works

1. **Instructor injects a fault** — you will see an alarm appear
2. **Acknowledge the alarm** — press the **ACK** button (or SPACE key)
3. **Work through the procedure** — the checklist shows required steps
4. **Complete all steps** — the system auto-advances some steps when physics conditions are met
5. **Review your score** — shown in the SCORE panel when complete

### Procedure Steps

Each step has:
- A **time budget** — complete it within the budget to avoid penalties
- A **critical flag** (⚠ CRIT) — skipping a critical step = automatic FAIL
- **Points** — earned by completing on time and in correct order

### Grading Scale

| Grade | Score |
|-------|-------|
| DISTINCTION | ≥ 90% |
| PASS | ≥ 75% |
| BORDERLINE PASS | ≥ 60% |
| FAIL | < 60% or critical step missed |

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `SPACE` | Acknowledge alarm (ACK) |
| `ESC` | Return to lab selector |
| `F` | Fullscreen P&ID schematic |
| `T` | Open trend chart for first gauge |
| `R` | Reset current lab (with confirmation) |
| `1`–`9` | Quick-select lab from main screen |

---

## Lab 01 — Oily Water Separator

**Equipment:** Hamworthy MK2 OWS — treats bilge water before overboard discharge

**Key indicators:**
- Oil Content (PPM) — must be < 15 ppm for legal overboard discharge
- Flow Rate (L/s) — normal 2.5 L/s
- Heater Temp (°C) — must be ≥ 45°C for efficient separation

**⚠ MARPOL WARNING:** Discharging above 15 ppm is a criminal offence. The simulator 
enforces MARPOL Annex I — attempting illegal discharge triggers immediate **HARD FAIL**.

**Possible faults:** Heater failure | Monitor failure | Disc stack blockage

---

## Lab 02 — Auxiliary Boiler

**Equipment:** Auxiliary boiler AQ-10 — provides steam for deck heating, cargo,
accommodation services

**Key indicators:**
- Steam Pressure (bar) — normal 7.0 bar, alarm at 8.0 bar, safety valve at 8.5 bar
- Water Level (%) — critical below 30%, scram at 10%
- Flue Temperature (°C) — confirms combustion status

**⚠ SAFETY WARNING:** Never attempt to relight or start a boiler with water level
below 10%. This results in a **dry firing** condition — tube damage and potential
explosion. The simulator enforces this as a Hard Fail.

**Possible faults:** Flame failure | Feed pump trip | High steam demand

---

## Lab 03 — Fresh Water Generator

**Equipment:** Alfa Laval JWP-26-C — produces fresh water from seawater using 
waste heat from the main engine jacket water

**Key indicators:**
- Vacuum (mbar) — normal 71 mbar (93% vacuum)
- Salinity (PPM) — must be < 5 ppm for potable water
- Production Rate (L/h) — normal ~1080 L/h

**⚠ CONTAMINATION WARNING:** Producing water with salinity > 5 ppm risks 
contaminating the ship's potable water tanks. The system enforces a stop-production
requirement before fault correction.

**Possible faults:** Ejector failure | Tube leak | Jacket water temperature drop

---

## Lab 04 — Refrigeration Plant

**Equipment:** R22 refrigeration plant — maintains cargo hold and provision store temperatures

**Key indicators:**
- Suction Pressure (bar) — normal 2.8 bar, alarm at < 1.5 bar
- Head Pressure (bar) — normal 12.0 bar, alarm at > 18 bar
- Discharge Temperature (°C) — normal ~85°C, alarm at 120°C, scram at 140°C

**⚠ SAFETY WARNING:** Isolating a refrigerant leak section while the compressor is
running causes high-pressure liquid hammer and frostbite risk. Stop the compressor first.

**Possible faults:** Refrigerant leak | Condenser fouling | Compressor trip

---

## Lab 05 — Hydrophore System

**Equipment:** Fresh water pressure system supplying accommodation and deck services

**Key indicators:**
- Tank Pressure (bar) — normal 3.5 bar, alarm < 2.0 bar
- Air Charge (%) — normal 35%, alarm < 5%

**Possible faults:** Pump failure | Waterlogged tank | High demand

---

## Lab 06 — Diesel Generator (MSB Synchronisation)

**Equipment:** Two diesel generators supplying the ship's main electrical busbar

**Key indicators:**
- Frequency (Hz) — normal 50.0 Hz ± 0.5 Hz
- Voltage (V) — normal 400 V
- Total Load (kW) — alarm > 450 kW

**⚠ ELECTRICAL SAFETY:** Never close a circuit breaker while the generator is below
690 RPM (92% of nominal). Out-of-sync connection causes severe overcurrent and
equipment damage. The simulator enforces this as a Hard Fail.

**Synchronisation procedure:** Start DG2 → wait for RPM > 690 → match frequency
using governor → when synchroscope aligned → Close CB2 → Transfer load → Open CB1

**Possible faults:** Total blackout (DG1 trip) | Governor fault | Bus overload

---

## Lab 07 — Fuel Separator

**Equipment:** Alfa Laval S-type centrifugal fuel/oil separator — removes water and
impurities from heavy fuel oil

**Key indicators:**
- Bowl Speed (RPM) — normal 7500 RPM, separation effective at > 7125 RPM
- Fuel Temperature (°C) — normal 85–95°C
- Sludge Level (%) — alarm at 75%

**⚠ WARNING:** Sludge tank overflow at 99.5% contaminates clean fuel. The simulator
triggers Hard Fail at this point.

**Possible faults:** Motor fault (speed drop) | Heater failure | Sludge tank full

---

## Lab 08 — Steering Gear

**Equipment:** Hydroster 2-ram electro-hydraulic steering gear

**Key indicators:**
- Hydraulic Pressure (bar) — normal 180 bar, alarm < 80 bar
- Oil Level (%) — monitor for leaks
- Oil Temperature (°C) — alarm at 70°C

**⚠ SOLAS REQUIREMENT:** Loss of steering is a navigational emergency. Always
notify the bridge FIRST (before investigation). This is a critical step — failure
to notify bridge results in Hard Fail.

**Possible faults:** Pump failure | Hydraulic oil leak | Rudder feedback failure | Oil overtemp

---

## Lab 09 — Fuel Conditioning Module (FCM)

**Equipment:** Alfa Laval FCM One — conditions heavy fuel oil to correct viscosity
for main engine injection

**Key indicators:**
- Fuel Temperature (°C) — normal 130°C
- Viscosity (cSt) — normal 10–15 cSt for injection
- HP Pressure (bar) — normal 8 bar

**⚠ DANGER:** Viscosity above 50 cSt (SCRAM limit) can cause main engine fuel pump
seizure, loss of propulsion, and potential grounding. Hard Fail is triggered.

**Possible faults:** Heater failure | Circulation pump failure | Viscometer fault

---

## Lab 10 — Central Cooling System

**Equipment:** Seawater cooling system providing cooling to main engine,
generators, air compressors, and other consumers

**Key indicators:**
- FW Temperature (°C) — normal 36°C, alarm at 42°C, critical at 50°C, scram at 58°C
- SW Flow (L/s) — normal 25 L/s from each pump
- HX Condition — heat exchanger effectiveness (1.0 = clean)

**⚠ ENGINE DAMAGE WARNING:** FW temperature above 58°C causes main engine
thermal overload. Time from alarm to scram is approximately 90 seconds.
Act immediately.

**Possible faults:** SW pump trip | HX fouling | Sea chest blockage

---

## Exporting Your Results

After completing a scenario, click **Export Report** in the Score panel to 
download an HTML report including:
- Step-by-step performance breakdown
- Time penalties
- Final score and grade
- Session timeline

---

## Common Mistakes to Avoid

| Mistake | Consequence |
|---------|-------------|
| Relight boiler with low water | HARD FAIL — thermal explosion |
| Discharge OWS above 15 ppm | HARD FAIL — MARPOL violation |
| Close DG breaker out of sync | HARD FAIL — overcurrent damage |
| Isolate refrigerant leak while running | HARD FAIL — pressure injury |
| Skip NOTIFY_BRIDGE in steering failure | HARD FAIL — SOLAS violation |
| Ignore FCM viscosity > 50 cSt | HARD FAIL — engine seizure |

---

*METS v1.0 — GOLD BUILD — STCW A-III/1 Compliant*
*For technical support, contact your instructor.*
