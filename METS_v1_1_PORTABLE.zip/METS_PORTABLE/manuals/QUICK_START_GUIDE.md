# METS v8 — Quick Start Guide

## Starting the Simulator

### Windows
1. Double-click START_SIMULATOR.bat
2. Browser opens at http://localhost:8080
3. Select a lab from the grid

### If START_SIMULATOR.bat fails
Run SETUP_AND_RUN.bat (downloads Python automatically)

## Keyboard Shortcuts
- SPACE = Acknowledge alarm
- ESC = Back to lab selector
- F = Fullscreen schematic
- T = Open trend recorder
- 1-9 = Quick lab select

## New Features
- Sound alarms (ACK to silence)
- Countdown timer on active procedure step
- Click any gauge for 60-second trend chart
- Dark/Light theme toggle (sun icon)
- UA/EN language switch (UA button)
- Export HTML report after completing lab
