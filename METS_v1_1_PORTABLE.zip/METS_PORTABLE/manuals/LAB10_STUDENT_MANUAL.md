# LAB 10 — SEAWATER COOLING SYSTEM FAILURE
## Student Training Manual
### Marine Engineering Training Simulator | STCW A-III/1

---

## Before You Begin

**Estimated time:** 20–30 minutes per scenario  
**Assessment:** Scored 0–100 pts. Pass = 75 pts. Distinction = 90 pts.  
**STCW competency:** Monitor and control engineering systems (A-III/1, Table A-III/1)

Read this manual completely before starting the simulator.

---

## 1. System Overview

The seawater cooling system removes heat from the main engine jacket water using seawater drawn through the ship's hull.

```
SEA ──► Sea Chest ──► SW Pump (P1 or P2) ──► Cooler Bundle ──► Overboard
                                                     ▲
                                            Engine Jacket Water
                                            (carries engine heat)
```

**Key components you will operate:**

| Component | Description |
|---|---|
| SW Pump P1 | Main seawater cooling pump (7.5 kW, 12 L/s) |
| SW Pump P2 | Standby seawater cooling pump (identical to P1) |
| Sea Chest Valve | Seawater inlet isolating valve |
| Overboard Valve | Seawater outlet isolating valve |
| Cooler Bundle | Heat exchanger — transfers heat from engine to seawater |

**Normal operating parameters:**

| Parameter | Normal Range | Alarm |
|---|---|---|
| Engine temperature | 68–80 °C | HIGH: 85 °C / HIGH-HIGH: 93 °C |
| Cooling flow | 10–14 L/s | LOW: <1 L/s |
| Sea chest ΔP | 0.10–0.20 bar | >0.5 bar = blockage suspected |
| Cooler ΔP | 0.20–0.30 bar | >0.70 bar = fouling suspected |
| Suction pressure | 1.6–1.9 bar | <0.5 bar = cavitation risk |

---

## 2. Critical Safety Rules

> ⚠️ **RULE 1 — Never close the sea chest valve while a pump is running.**  
> A centrifugal pump running against a closed suction valve will fail within 30 seconds (seal destruction due to recirculation heating). Always **stop the pump first**, then change valve position.

> ⚠️ **RULE 2 — Watch the engine temperature continuously.**  
> At 100 °C the engine will automatically shut down (SCRAM). This is a hard fail — you will not pass the assessment. Act before 93 °C.

> ⚠️ **RULE 3 — Check suction pressure before starting the standby pump.**  
> If the sea chest is blocked, starting P2 into a blocked suction may cause immediate cavitation. Open the alternate sea chest first.

---

## 3. Standard Operating Procedure — Pump Changeover

When a cooling pump fails, use this procedure:

| Step | Action | Points | Time Limit |
|---|---|---|---|
| 1 | **ACK ALARM** — Press the alarm acknowledgement button on the panel | 10 | 30 s |
| 2 | **IDENTIFY FAULT** — Check which pump is in fault (red indicator) | 15 | 45 s |
| 3 | **CHECK STANDBY** — Verify P2 is ready (oil level OK, no fault flags) | 15 | 30 s |
| 4 | **OPEN SEA CHEST** — Confirm sea chest valve is open (or open alternate) | 10 | 20 s |
| 5 | **START P2** — Click pump P2 → Start | 20 | 20 s |
| 6 | **CONFIRM FLOW** — Verify cooling flow returns to >8 L/s | 10 | 30 s |
| 7 | **CONFIRM TEMP FALLING** — Engine temperature drops below 85 °C | 10 | 2 min |
| 8 | **LOG FAULT** — Record the fault in the engine room log | 5 | 60 s |
| 9 | **NOTIFY BRIDGE** — Inform the officer of the watch | 5 | 60 s |

**Steps 6 and 7 are auto-detected by the simulator** — you do not need to press a button. They complete when the physics confirms the correct condition.

**Penalties:**
- −1 point per 10 seconds over the time limit for each step
- −5 points for performing steps out of order

---

## 4. Fault Scenarios

### Scenario A ★ — SW Pump P1 Bearing Seizure (Easy)
**What happens:** P1 stops suddenly. Cooling flow drops to zero. Temperature rises quickly (~0.2 °C/second).

**Your task:** Follow the 9-step procedure above. You have approximately 65 seconds before the HIGH TEMP alarm, and ~155 seconds before SCRAM.

**Key diagnostic:** P1 shows FAULT status (red indicator). Flow gauge reads zero.

---

### Scenario B ★★ — Sea Chest Blockage (Medium)
**What happens:** Marine growth / debris blocks 60% of the sea chest. Flow reduces to ~4 L/s. Temperature rises slowly.

**Your task:** Identify that the problem is the sea chest, not the pump. Switch to the alternate sea chest valve.

**Key diagnostic:** Flow is low but P1 shows RUNNING. Sea chest ΔP is elevated (>0.5 bar). Suction pressure is low.

> **Tip:** If sea chest ΔP is high, the problem is upstream of the pump — not the pump itself.

---

### Scenario C ★★★ — Dual Pump Degradation (Hard)
**What happens:** Both pumps are degraded + P1 has a seal leak + tropical 28°C sea water. No single obvious fault.

**Your task:** Systematic diagnosis. Check each component methodically. The combined flow from both degraded pumps may barely hold engine temperature.

**Key diagnostic:** Both pumps show RUNNING but combined flow is lower than expected. Seal leak indicator lit on P1.

---

### Scenario D ★★ — Operator Error: Valve Closed While Running (Medium)
**What happens:** The sea chest valve has been closed while P1 was running (simulating an operator mistake). P1 will fail within 30 seconds.

**Your task:** Recognise the alarm quickly. Do NOT try to restart P1 — it is already damaged. Start P2 after opening the sea chest valve.

**Key learning:** This scenario tests your knowledge of centrifugal pump operating rules.

> **What went wrong:** Closing the suction valve on a running centrifugal pump causes the impeller to recirculate hot water internally — the seal overheats and fails. This is why you must always stop the pump before operating suction valves.

---

### Scenario E ★★ — Fouled Heat Exchanger (Medium — Diagnostic Challenge)
**What happens:** The cooler has accumulated deposits reducing its heat transfer by 40%. Cooling flow is **normal** but engine temperature is rising.

**Your task:** Diagnose WHY temperature is high when flow is normal.

**Key diagnostic:** Check cooler ΔP — it will be elevated (>0.7 bar), indicating fouling. The correct response is to log the fault and notify the bridge (not to change pumps — the pumps are fine).

> **This scenario cannot be fixed during the training session.** Fouled coolers require cleaning during port. Your role is to correctly diagnose and report.

---

## 5. How to Use the Simulator Controls

### Pump Controls
- **Click on a pump** → Context menu appears
- Select **Start** or **Stop**
- Pump indicator shows: ⚫ Stopped | 🟡 Starting | 🟢 Running | 🔴 Fault

### Valve Controls
- **Click on a valve** → Context menu: Open / Close
- Valve handle animates to open (0°) or closed (−90°) position
- Indicator light shows position

### Reading the Gauges
- **Engine Temperature gauge** — left panel, large dial. Red zone starts at 85°C.
- **Cooling Flow gauge** — centre panel, shows total seawater flow in L/s.
- **Sea Chest ΔP gauge** — right panel, shows pressure drop across sea chest strainer.

### Alarms
- Alarms flash in the top alarm bar
- Yellow = Warning (severity 1), Amber = Alarm (severity 2), Red = Emergency (severity 3)
- Press **ACK** button to acknowledge — this is your first procedure step

### Procedure Panel
- Right panel shows your current procedure checklist
- ✅ Green = completed | ⬜ White = pending | 🔴 Red = overdue

---

## 6. Common Mistakes to Avoid

**Mistake 1 — Starting P2 before acknowledging the alarm**  
You lose 5 points for out-of-order steps. ACK ALARM is always first.

**Mistake 2 — Checking standby before identifying the fault**  
Take a moment to read the indicators. What is actually faulted?

**Mistake 3 — Closing the sea chest valve without stopping the pump first**  
This will fault your standby pump too. Both pumps will be unavailable → SCRAM.

**Mistake 4 — Ignoring the cooler ΔP gauge in Scenario E**  
If flow is normal but temp is rising, the heat exchanger is the problem, not the pumps.

**Mistake 5 — Waiting too long**  
Temperature rises faster than it seems. Do not read all the gauges before acting on an obvious P1 fault.

---

## 7. Self-Assessment Checklist

Before finishing, ask yourself:

- [ ] Did I acknowledge the alarm within 30 seconds?
- [ ] Did I correctly identify which component failed?
- [ ] Did I check the standby pump before starting it?
- [ ] Was the sea chest valve open before I started P2?
- [ ] Did I confirm flow was restored?
- [ ] Did I confirm engine temperature was falling?
- [ ] Did I log the fault?
- [ ] Did I notify the bridge?

If you can tick all eight boxes, you followed the correct procedure.

---

## 8. Grade Boundaries

| Grade | Score |
|---|---|
| DISTINCTION | 90–100 pts |
| PASS | 75–89 pts |
| BORDERLINE PASS | 60–74 pts |
| FAIL | < 60 pts |

A FAIL means you must repeat the scenario before moving to the next laboratory.

---

## 9. After the Session

Your instructor will review:
- Your total score and grade
- Which steps were on time vs late
- Whether any steps were performed out of order
- Whether the engine reached a dangerous temperature

If you scored FAIL or BORDERLINE PASS on your first attempt, repeat Scenario A before attempting B or C.

---

*Document version: 2.0 | Lab 10 | STCW A-III/1 | Marine Engineering Training Simulator*
