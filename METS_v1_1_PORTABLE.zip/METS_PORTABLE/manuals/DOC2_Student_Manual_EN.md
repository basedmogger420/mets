# 🚢 Marine Engineering Training Simulator v8
# Student User Manual & Quick Start Guide

> **Welcome aboard.** This guide will take you from zero to running your first fault scenario in under ten minutes. Read it once before your lab session and keep it open as a reference. You've got this.

---

## Table of Contents

1. [What Is This Simulator?](#1-what-is-this-simulator)
2. [Getting Started — Launching the Simulator](#2-getting-started--launching-the-simulator)
3. [Interface Overview — What You're Looking At](#3-interface-overview--what-youre-looking-at)
4. [Selecting Your Lab Module](#4-selecting-your-lab-module)
5. [Reading the Instruments — Gauges & Telemetry](#5-reading-the-instruments--gauges--telemetry)
6. [Operating the Equipment — Controls & Actions](#6-operating-the-equipment--controls--actions)
7. [When an Alarm Fires — What To Do](#7-when-an-alarm-fires--what-to-do)
8. [The Procedure Checklist — Your Step-by-Step Guide](#8-the-procedure-checklist--your-step-by-step-guide)
9. [How You Are Assessed & Graded](#9-how-you-are-assessed--graded)
10. [Completing & Reviewing Your Session](#10-completing--reviewing-your-session)
11. [Troubleshooting — FAQ](#11-troubleshooting--faq)
12. [Quick Reference Card](#12-quick-reference-card)

---

## 1. What Is This Simulator?

The Marine Engineering Training Simulator (METS) lets you practice operating the machinery of a real ship's engine room — safely, from a classroom computer.

You will face the same systems you will encounter on a working vessel: boilers, diesel generators, refrigeration plants, steering gear, and more. Your instructor can inject a fault into any running system at any time — a pump trips, a valve sticks, a leak develops — and it is your job to diagnose what has gone wrong and respond correctly, following the same procedures required by international maritime law (STCW).

**What the simulator does:**
- Models each piece of equipment using real engineering physics
- Tracks every action you take and when you take it
- Scores your performance automatically against the correct procedure
- Gives your instructor detailed data on your response times and decision-making

**What it does not do:**
- It will not penalise you for exploring — you can reset and try again as many times as you need before the assessed run
- It will not crash if you click the wrong button — the physics simply reflects the consequences

Think of it as a flight simulator for the engine room. Professionals use simulators because making mistakes in training is safe and educational. Making the same mistakes on a real ship is not.

---

## 2. Getting Started — Launching the Simulator

### Step 1 — Run the Application

Find the file called **`START_SIMULATOR.bat`** (or **`start_simulator.bat`**) in the METS folder on your desktop or provided USB drive. Double-click it.

A small black command window will appear briefly. **Do not close it** — this is the simulation server running in the background. It will tell you the address the simulator is available on, for example:

```
HTTP  →  http://localhost:8080
WS    →  ws://localhost:8765
```

### Step 2 — Your Browser Opens Automatically

Within 1–2 seconds, your default web browser (Chrome, Edge, or Firefox) will open automatically and navigate to the simulator. You do not need to type any address.

> **💡 Tip:** If the browser does not open automatically, open it yourself and type `http://localhost:8080` into the address bar.

### Step 3 — The Connection Screen

You will see a dark screen with an anchor icon (⚓) and the message **"Connecting to simulator…"** For most computers this disappears within one second. Once connected, the lab selection grid appears.

> **⚠️ If you see "Connection failed":** Check that the black command window is still open. If it closed, double-click `START_SIMULATOR.bat` again.

### Step 4 — You Are Ready

Once the lab grid is visible, the simulator is fully running. You do not need to do anything else to "start" it — the physics engine is already live behind the scenes.

---

## 3. Interface Overview — What You're Looking At

The simulator interface is divided into five main areas. Take a moment to identify each one before your first lab.

```
┌─────────────────────────────────────────────────────────────┐
│  ⚓  METS v8.0          [Lab Name]         T+ 0s   ● LIVE  │  ← HEADER BAR
├──────────────────┬──────────────────────────────────────────┤
│                  │                                          │
│   LAB GRID  or   │         TELEMETRY GAUGES                 │  ← MAIN PANEL
│   SCHEMATIC      │    (pressure, temperature, flow…)        │
│                  │                                          │
├──────────────────┴──────────────────────────────────────────┤
│  🔴 ALARMS PANEL                                            │  ← ALARMS
├─────────────────────────────────────────────────────────────┤
│  OPERATOR CONTROLS  [Start Pump] [Stop Pump] [ACK Alarm]…   │  ← CONTROLS
├─────────────────────────────────────────────────────────────┤
│  PROCEDURE CHECKLIST  ▶ Step 1: Acknowledge alarm…         │  ← PROCEDURE
└─────────────────────────────────────────────────────────────┘
```

### Header Bar
Shows the simulator name, the currently active lab module, a live tick counter (`T+ Xs` — how many seconds the simulation has been running), and a green **LIVE** indicator confirming the WebSocket connection is active.

### Main Panel — Telemetry Gauges
This is your instrument panel. Each gauge displays a real-time reading from the simulation:
- **Green zone** — normal operating range
- **Amber zone** — warning, requires attention
- **Red zone** — alarm condition, requires immediate action

### Alarms Panel
When a fault occurs, alarm banners appear here in red or amber. Each alarm shows the alarm name, severity level, and timestamp. **Alarms do not go away on their own** — you must acknowledge and then resolve them.

### Operator Controls
These are your buttons. Each button sends a command to the simulated equipment — starting a pump, closing a valve, switching to manual control. **Only the buttons relevant to the active lab are shown.**

### Procedure Checklist
This panel shows the step-by-step procedure you are expected to follow. The currently active step is highlighted. As you complete actions, steps are ticked off automatically or by your button presses.

---

## 4. Selecting Your Lab Module

When you first connect, you see a grid of ten lab cards. Each card shows:
- The lab number and title
- The equipment being simulated (e.g. "Auxiliary Boiler AQ-10")
- The available fault scenarios for that module

**To begin a lab:**
1. Click the card for the lab your instructor has assigned (e.g. **Lab 2 — Boiler**)
2. The interface switches to that module's instrument panel immediately
3. The simulation begins — gauges start updating every second
4. Wait for your instructor to inject a fault scenario before beginning your procedure

> **💡 Important:** Your instructor controls fault injection from their own panel. You will know a fault has been injected because one or more alarms will fire on your screen. Do not try to begin the procedure before a fault is active — there will be nothing to respond to.

---

## 5. Reading the Instruments — Gauges & Telemetry

Every lab module has its own set of instruments. Here are the ones you will encounter most frequently, and what they mean.

### Universal Gauges (appear in most labs)

| Gauge | Units | What It Tells You |
|-------|-------|-------------------|
| **Pressure** | bar | Operating pressure of the system |
| **Temperature** | °C | Fluid or component temperature |
| **Flow Rate** | L/s or L/h | Volume of fluid moving through the system |
| **Level** | % | Tank or vessel fill level (0% = empty, 100% = full) |
| **RPM / Speed** | RPM | Rotation speed of pumps, separators, generators |

### Colour Coding

| Colour | Meaning | Your Action |
|--------|---------|-------------|
| 🟢 Green | Normal — within safe limits | Continue monitoring |
| 🟡 Amber | Warning — approaching limit | Investigate, prepare to act |
| 🔴 Red | Alarm — limit exceeded | Act immediately per procedure |

### Lab-Specific Instruments

**Boiler (Lab 2):**
- `Steam Pressure (bar)` — target 7.0 bar; alarm at 8.0 bar (high) and 5.5 bar (low)
- `Water Level (%)` — keep above 30%; critical below 15% → emergency shutdown
- `Flue Temp (°C)` — confirms burner is firing; drops to ~45°C when flame is out
- `Flame` — boolean indicator: ON (green) or OUT (red alarm)

**Diesel Generator (Lab 6):**
- `Frequency (Hz)` — target 50 Hz; alarm if below 47 Hz
- `Voltage (V)` — target 400 V; drops to zero during blackout
- `DG1/DG2 RPM` — must reach ~690 RPM before you can close the circuit breaker
- `DG2 Sync Ready` — indicator: ⏳ = wait; button becomes active when ready

**Refrigeration (Lab 4):**
- `Suction Pressure (bar)` — target 2.8 bar; low reading → refrigerant leak
- `Head Pressure (bar)` — target 12 bar; high reading → condenser fouling
- `Discharge Temp (°C)` — target 85°C; rising above 120°C → compressor risk

**Oily Water Separator (Lab 1):**
- `Oil Content (PPM)` — must stay below 15 PPM to discharge overboard legally
- `Flow Rate (L/s)` — low flow indicates blocked separator or pump fault

> **⚠️ Critical Rule for Lab 1:** Never press **Switch to Overboard** if PPM is above 15. The simulator will trigger an immediate hard fail (illegal discharge), exactly as the real 15 ppm monitor would shut the valve on a real ship.

---

## 6. Operating the Equipment — Controls & Actions

### How Controls Work

Every button in the controls panel sends a specific command to the equipment. The equipment responds according to its physics model — **changes do not happen instantly**. Just like on a real ship, a pump takes a few seconds to build pressure, a boiler takes minutes to reach operating temperature, and a generator takes ~20 seconds to reach synchronisation speed.

**Be patient.** If you press a button and nothing seems to happen immediately, wait for the next gauge update (every 1 second) and check whether the reading is moving in the expected direction.

### Common Controls and What They Do

| Button | What It Does | When To Use It |
|--------|-------------|----------------|
| **🔔 ACK Alarm** | Acknowledges the active alarm — records your response time | First action after any alarm fires |
| **Start [Pump/Generator/etc.]** | Starts the named piece of equipment | When equipment has tripped or was manually stopped |
| **Stop [Pump/Generator/etc.]** | Stops the named piece of equipment | When switching to standby or during shutdown |
| **Switch to Recirc** | Diverts flow back to the bilge (OWS only) | When PPM is too high to discharge |
| **Switch to Overboard** | Opens discharge valve (OWS only) | Only when PPM is confirmed below 15 |
| **Secure Fuel** | Closes the boiler fuel valve | During boiler flame failure response |
| **Purge Furnace** | Clears combustible gas from boiler firebox | Before relighting burner — mandatory step |
| **Re-light Burner** | Attempts to restart boiler flame | After purge is complete |
| **Sync DG2** | Confirms synchronisation is complete | Before closing DG2 circuit breaker |
| **Close CB1 / CB2** | Closes a generator circuit breaker onto the bus | After synchronisation |

### Equipment Interlocks

The simulator enforces real safety interlocks. These are not bugs — they are correct behaviour:

- **Boiler:** You cannot relight the burner while it is locked out. You must press **Purge Furnace** first.
- **Diesel Generator:** The **Close CB2** button is greyed out (⏳) until DG2 has reached synchronisation speed. You cannot close the breaker early — attempting it on a real ship would cause an out-of-phase fault and instantaneous overcurrent trip.
- **OWS:** You cannot switch to overboard when oil content is above 15 PPM. The button will refuse the command and a hard fail will be recorded.

---

## 7. When an Alarm Fires — What To Do

This is the most important section of this guide. When an alarm fires, your procedure starts. Every second counts — your reaction time is being measured from the moment the alarm appears.

### The Golden Sequence

Follow this sequence for every alarm scenario:

```
1. ACKNOWLEDGE → 2. IDENTIFY → 3. ACT → 4. VERIFY → 5. LOG & NOTIFY
```

### Step-by-Step Breakdown

**Step 1 — ACKNOWLEDGE (🔔 ACK Alarm)**
Press the **ACK Alarm** button immediately when you see the alarm. This:
- Records your reaction time (time from alarm firing to your ACK press)
- Confirms to the assessment system that you noticed the alarm
- Does NOT silence or clear the alarm — the fault is still active

> **⚠️ Do not skip this step.** ACK Alarm is the first step in every procedure. Skipping it will mark it as not completed and cost you points.

**Step 2 — IDENTIFY (🔍 Identify Fault)**
Press **Identify Fault** to register that you have diagnosed the cause. Before pressing it, actually look at your gauges:
- Which reading is out of range?
- Is it rising or falling? Fast or slow?
- Which equipment is affected?

This step is often automatic — the assessment system may auto-complete it once you have correctly read the situation from the gauges.

**Step 3 — ACT**
Take the corrective action indicated by the procedure checklist. The checklist shows you exactly which steps are needed for this specific scenario. Follow them in order.

**Step 4 — VERIFY**
After taking action, confirm that the fault is resolving. Watch your gauges:
- Is pressure moving back toward the normal range?
- Has the alarm cleared?
- Is the equipment running correctly?

The system will auto-complete verification steps once the physical parameters return to acceptable values.

**Step 5 — LOG & NOTIFY**
Press **📝 Log Fault** and **📡 Notify Bridge** to complete the scenario. These final administrative steps are required by STCW procedures and are worth points in your assessment.

---

## 8. The Procedure Checklist — Your Step-by-Step Guide

The procedure checklist panel at the bottom of the screen is your roadmap through the scenario. It is generated dynamically for each fault — a boiler flame failure shows different steps than a feed pump trip.

### Understanding the Checklist

Each step has:
- A **step ID** (e.g. `ACK_ALARM`, `PURGE_FURNACE`)
- A **description** of what to do
- A **point value** (shown when the step is active)
- A **status**: ○ Not done | ✓ Complete | ✗ Missed

The **currently active step** is highlighted. You can complete steps in two ways:
1. **Button press** — pressing a control button (e.g. **Purge Furnace**) marks the matching step as done
2. **Automatic** — the system marks some steps done automatically when physics conditions are met (e.g. pressure returning to normal marks "Verify Steam" as done)

### Step Order Matters

Procedures must be followed in the correct order. If you complete a step out of sequence:
- That specific step earns zero points
- Subsequent steps earn normally — one mistake does not ruin your entire score
- The OOO event is recorded in your report so your instructor can discuss it during debrief

> **💡 Example:** If you press **Purge Furnace** before pressing **Secure Fuel**, the Purge step earns zero (wrong order). But if you then do every remaining step correctly in order, you can still pass the scenario.

### Time Budgets

Each step has a time budget — a number of seconds within which it should be completed. The timer starts when the step becomes active. If you exceed the budget:
- A penalty of 0.5 points per 2 seconds overtime is applied
- The step still counts as complete — you are not penalised for exceeding the budget by a small amount
- Very slow responses (e.g. 5 minutes to acknowledge an alarm) will significantly reduce your score

---

## 9. How You Are Assessed & Graded

### Scoring Model

Your score for a scenario is calculated as:

```
Total Earned = Σ (step.points − step.penalty) for all completed steps
Score %      = (Total Earned / Maximum Possible) × 100
```

### Grading Scale

| Grade | Score | Meaning |
|-------|-------|---------|
| 🏅 **DISTINCTION** | ≥ 90% | Excellent — all steps completed correctly and promptly |
| ✅ **PASS** | ≥ 75% | Competent — minor timing penalties or one OOO event |
| 🟡 **BORDERLINE PASS** | ≥ 60% | Marginal — your instructor may require a repeat attempt |
| ❌ **FAIL** | < 60% | Insufficient — remedial practice required |

### What Causes Points to Be Deducted

| Event | Penalty |
|-------|---------|
| Step completed overtime | 0.5 pts per 2 seconds over budget |
| Step completed out of order | Full step points (that step earns 0) |
| Step not completed | Full step points lost |

### What Causes an Automatic FAIL (Hard Fail)

Some actions — or failures to act — result in an immediate FAIL regardless of your score:

| Hard Fail Condition | Why |
|--------------------|-----|
| Boiler water level drops below 10% | Risk of catastrophic boiler damage |
| OWS discharges overboard above 15 PPM | MARPOL violation — illegal under maritime law |
| Attempting overboard discharge at high PPM | Illegal discharge — even attempting it is a violation |
| Cooling system FW temperature exceeds 55°C | Engine damage threshold reached |
| Skipping a STCW-critical step (e.g. Notify Bridge) | Critical safety omission |

> **💡 Hard fails are learning moments, not punishments.** In a real engine room, each of these conditions would have serious consequences. The simulator enforces them so you learn their importance before you ever face them at sea.

---

## 10. Completing & Reviewing Your Session

### When the Scenario Ends

Once all steps in the checklist are marked done, the scenario completes automatically. You will see:
- Your **final score** (e.g. 85/100)
- Your **grade** (PASS, DISTINCTION, etc.)
- A **summary** showing each step: points earned, penalty applied, time taken
- Any **OOO violations** or missed steps highlighted in amber

### Reviewing Your Performance

The procedure panel expands to show your full action history. Review it carefully:
- Which steps took longest?
- Did you perform any steps out of order?
- Which alarms did you acknowledge slowest?

This data is the same data your instructor uses during the debrief. Come prepared to discuss your decisions.

### Resetting for Another Attempt

Your instructor can reset the module at any time. When they do:
- All physics values return to nominal
- The alarm clears
- The procedure resets to Step 1
- A new fault scenario can be injected

You may be asked to run the same scenario a second time to demonstrate improvement, or a different scenario at a higher difficulty level.

---

## 11. Troubleshooting — FAQ

---

**Q: The browser opened but I see "Connection failed" or a blank screen.**

A: The black command window (the server) may have closed or not started properly. Check that it is still open on the taskbar. If it is closed, double-click `START_SIMULATOR.bat` again and wait 3 seconds before refreshing the browser.

---

**Q: I pressed a button but nothing happened.**

A: Three possible causes:
1. **Interlock active** — the equipment cannot accept that command yet (e.g. Close CB2 when DG2 is not at sync speed). Check for the ⏳ indicator or look at the gauge values.
2. **Scenario not injected** — no fault is active yet. Wait for your instructor to inject a scenario.
3. **Procedure complete** — the scenario has already ended. Ask your instructor to reset.

---

**Q: Why isn't the pressure rising / the temperature coming down?**

A: Physics takes time. Every system has a time constant — a measure of how slowly or quickly it responds. For reference:
- Boiler pressure responds in ~25 seconds to changes in firing rate
- Refrigeration suction pressure responds in ~20 seconds
- Generator frequency responds in ~8 seconds after breaker closure

If a reading is not moving at all (frozen), something may still be in a fault state. Check all your gauges and compare against the expected values in Section 5.

---

**Q: The alarm is still showing even though I fixed the problem.**

A: Alarms have hysteresis — a small buffer zone that prevents rapid flickering. For example, the boiler HIGH PRESSURE alarm sets at 8.0 bar but does not clear until pressure drops back to 7.5 bar. This is realistic: on a real ship, an alarm that clears the moment you take action gives you no confirmation that the situation is actually stable.

---

**Q: I accidentally pressed the wrong button. Is my scenario ruined?**

A: Probably not. The simulator records out-of-order actions as OOO events, which deduct points from that specific step only. You can continue the procedure from the next correct step and still pass. The only way to completely ruin a scenario is to trigger a hard fail condition (see Section 9).

---

**Q: The procedure checklist shows a step as active but I don't know what to do.**

A: Read the step description carefully — it tells you exactly what action is required (e.g. "Start standby SW pump P2"). Then look for the matching button in the controls panel. If you cannot find the button, scroll down — the controls panel may have more buttons below the visible area.

---

**Q: My DG2 "Close CB2" button is greyed out.**

A: This is intentional. DG2 has not yet reached synchronisation speed (≥92% of nominal RPM). Watch the `DG2 RPM` gauge — when it reaches approximately 690 RPM, the button will activate. On a real ship, attempting to close a circuit breaker out of phase causes an instantaneous overcurrent fault. The simulator enforces this for your safety education.

---

**Q: I got a HARD FAIL. What now?**

A: Ask your instructor to reset the module. Hard fails are not permanent — they reset with the module. Review what caused the hard fail (Section 9), discuss it with your instructor, and try again. Most students who receive a hard fail on their first attempt pass on their second because they now understand exactly what to avoid.

---

**Q: The simulator window shows the time counting up (T+ 120s) but I haven't started my procedure yet.**

A: The tick counter runs continuously from the moment you select a lab — the simulation is always live. This is normal. Your procedure timer only starts when the first alarm fires. Do not be concerned about the global tick counter — it is informational only.

---

## 12. Quick Reference Card

Cut out or screenshot this section and keep it beside your keyboard during the lab.

---

### ⚡ The Response Sequence (Every Scenario)

```
① Alarm fires → ② Press 🔔 ACK Alarm → ③ Read gauges → ④ Press 🔍 Identify Fault
→ ⑤ Follow checklist steps in order → ⑥ Verify readings returning to normal
→ ⑦ Press 📝 Log Fault → ⑧ Press 📡 Notify Bridge
```

---

### 🚨 Alarm Severity Guide

| Colour | Level | Response Time Target |
|--------|-------|---------------------|
| 🔴 Red | EMERGENCY | Acknowledge within 15 seconds |
| 🟠 Orange | CRITICAL | Acknowledge within 30 seconds |
| 🟡 Amber | WARNING | Acknowledge within 60 seconds |

---

### 🔴 Hard Fail Conditions — Avoid These

| Lab | Avoid |
|-----|-------|
| Boiler | Water level below 10% |
| OWS | Overboard valve at PPM > 15 |
| Cooling | FW temperature above 55°C |
| Any | Skipping a critical step |

---

### 🟢 Normal Operating Values

| System | Key Reading | Normal Range |
|--------|------------|-------------|
| Boiler | Steam pressure | 6.5 – 8.0 bar |
| Boiler | Water level | 30 – 80% |
| DG | Frequency | 49 – 51 Hz |
| DG | Voltage | 380 – 420 V |
| Refrigeration | Suction pressure | 2.3 – 3.3 bar |
| OWS | Oil content | < 15 PPM |
| Cooling | FW temperature | 32 – 40°C |

---

### 📊 Grading At A Glance

| Grade | Score Needed | Key Requirement |
|-------|-------------|-----------------|
| DISTINCTION | ≥ 90% | Fast, correct, in-order |
| PASS | ≥ 75% | Correct with minor delays |
| BORDERLINE | ≥ 60% | Mostly correct |
| FAIL | < 60% | Significant errors or omissions |

---

*Good luck — and remember: in the engine room, a calm, methodical response saves ships.*

*Marine Engineering Training Simulator v8.0 — Student Manual*
