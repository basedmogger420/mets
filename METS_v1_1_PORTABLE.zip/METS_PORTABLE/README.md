# ⚓ METS v1.0 — Marine Engineering Training Simulator
## GOLD BUILD — All 52 Audit Fixes Applied

A browser-based real-time training simulator for **STCW A-III/1** Marine Engineering 
competence assessment. Covers all 10 mandatory lab topics from Oily Water Separator 
to Central Cooling System.

---

## Quick Start

### Windows
```
Double-click START_SIMULATOR.bat
```

### Python (any OS)
```bash
python run_simulator.py
```

The browser opens automatically to `http://localhost:8080`.

---

## Requirements

- Python 3.10 or newer (stdlib only — no pip install required)
- Modern browser: Chrome 90+, Firefox 90+, Edge 90+

---

## Labs Included

| # | Lab | Equipment |
|---|-----|-----------|
| 01 | Oily Water Separator | Hamworthy MK2 |
| 02 | Auxiliary Boiler | AQ-10 Steam Boiler |
| 03 | Fresh Water Generator | Alfa Laval JWP-26-C |
| 04 | Refrigeration Plant | R22 Vapour Compression |
| 05 | Hydrophore System | Pressure Water System |
| 06 | Diesel Generator | MSB 2×DG Synchronisation |
| 07 | Fuel Separator | Alfa Laval S-type |
| 08 | Steering Gear | Hydroster 2-Ram E/H |
| 09 | Fuel Conditioning | Alfa Laval FCM One |
| 10 | Central Cooling | Seawater Cooling System |

---

## Key Features

- **Real-time P&ID schematics** — ISO 10628 compliant, animated flow
- **STCW-compliant assessment** — step-by-step procedure with time budgets
- **Hard Fail enforcement** — critical maritime safety rules enforced
- **Dual language** — English / Ukrainian (UA/EN toggle)
- **Research export** — CSV with per-alarm reaction times for ANOVA
- **Instructor panel** — inject faults, reset sessions, review timeline

---

## Documentation

| File | Description |
|------|-------------|
| `docs/ARCHITECTURE.md` | System architecture and component overview |
| `docs/PHYSICS.md` | Physics models, parameters, and equations |
| `manuals/STUDENT_MANUAL_EN.md` | Student guide (English) |
| `manuals/STUDENT_MANUAL_UA.md` | Student guide (Ukrainian) |

---

## Project Integrity Check

```bash
python validate_project.py
```

Runs 8 checks (A–H) across all 10 labs:
- Gauge keys vs physics state
- Control actions vs module methods
- JSON scenario IDs vs Python FAULT_SCENARIOS
- Step ID synchronization (new in v1.0)

---

## GOLD v1.0 — Audit Summary

This release incorporates **52 confirmed fixes** from an independent security and 
architecture audit:

- **8 Critical fixes:** Path traversal, WebSocket auth, race conditions, XSS, MARPOL compliance
- **21 High fixes:** HSE hard fails, physics deadlocks, security headers, NaN protection
- **23 Medium fixes:** Memory management, hysteresis, pump logic, CI tooling

See `docs/ARCHITECTURE.md` for the full security architecture overview.

---

*Developed by Department of Ship Power Plants Operation and Thermal Power Engineering*  
*STCW A-III/1 — Marine Engineering Competence Assessment Platform*
