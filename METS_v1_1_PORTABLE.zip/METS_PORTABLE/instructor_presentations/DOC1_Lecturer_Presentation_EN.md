# 🚢 Marine Engineering Training Simulator v8
## Instructor Presentation — Pedagogical Introduction

---

# Slide 1 — Welcome & Purpose

**Slide Title:** Transforming Marine Engineering Education: Introducing METS v8

**Bullet Points:**
- A browser-based, physics-driven training simulator for ship's engine room systems
- Covers 10 mandatory STCW-aligned laboratory modules
- Zero hardware dependency — runs on any classroom PC, laptop, or lab computer
- Designed by practitioners, for academic and vocational maritime programmes
- Bridges the gap between classroom theory and hands-on engine room competence

**Speaker Notes:**
Welcome everyone. The Marine Engineering Training Simulator — METS — was built to solve a problem every maritime lecturer knows well: students understand thermodynamics on paper but freeze when a real alarm fires in the engine room. METS replicates that exact environment safely. It is a self-contained desktop application: the instructor double-clicks one file, a browser opens automatically, and the full simulator is live within seconds. No licensing servers, no cloud dependency, no specialist hardware. Today I want to walk you through what it does, how it assesses your students, and how to slot it directly into your existing lab schedule.

---

# Slide 2 — The Problem We Are Solving

**Slide Title:** Why Simulators Matter in Maritime Education

**Bullet Points:**
- STCW requires demonstrated competence, not merely theoretical knowledge
- Physical engine room visits are expensive, logistically complex, and hazardous for novices
- Traditional paper-based assessments cannot replicate time-pressure and alarm response
- Students rarely experience controlled fault scenarios without real risk of equipment damage
- Industry expects cadets to have hands-on fault diagnosis skills on day one

**Speaker Notes:**
STCW Convention Chapter III mandates that engineering watch officers demonstrate practical competence across boilers, generators, cooling systems, and separators. Real ships are not teaching environments — a student who opens the wrong valve on a live boiler has consequences. Shore-based simulators that do exist typically cost hundreds of thousands of euros and are timetabled only for senior cadets. METS brings that capability to first and second year students at a fraction of the cost, and — critically — allows instructors to inject specific, repeatable fault scenarios so every cohort faces identical conditions, making assessment fair and scientifically valid.

---

# Slide 3 — The Ten Laboratory Modules

**Slide Title:** Curriculum Coverage — 10 STCW-Aligned Labs

**Bullet Points:**
- **Lab 1** — Oily Water Separator (Hamworthy MK2) — MARPOL compliance & pollution prevention
- **Lab 2** — Auxiliary Boiler (AQ-10) — Steam generation, flame failure, feed pump management
- **Lab 3** — Fresh Water Generator (Alfa Laval JWP-26-C) — Vacuum evaporation, salinity control
- **Lab 4** — Refrigeration Plant (R22) — Vapour-compression cycle, refrigerant leak response
- **Lab 5** — Hydrophore System — Pressure vessel management, waterlogging
- **Lab 6** — Diesel Generators × 2 (MSB Synchronisation) — Blackout recovery, paralleling
- **Lab 7** — Fuel/Oil Separator (Alfa Laval) — Purification, sludge discharge
- **Lab 8** — Fuel Conditioning Module — Viscosity control, heating failure
- **Lab 9** — Steering Gear (2-Ram Electro-Hydraulic) — Loss of steering emergency procedure
- **Lab 10** — Seawater Cooling System — SW pump trip, heat exchanger fouling

**Speaker Notes:**
These ten modules map directly onto the practical assessments required by STCW Table A-III/1 and A-III/2. Each module is independent — you can run any single lab in a one-hour session, or sequence them across a semester. The modules are listed here with their real-world equipment references so students learn the correct brand and model terminology they will encounter at sea. Every module ships with both English and Ukrainian interface text, making this suitable for international cohorts.

---

# Slide 4 — The v8 Upgrade — What Changed

**Slide Title:** METS v8 — Major Capability Upgrades

**Bullet Points:**
- **Dynamic Procedure Manager** — procedure steps rebuild automatically for each fault scenario
- **Bernoulli-physics fault models** — leaks and pressure decay follow fluid dynamics, not fixed curves
- **Multi-client architecture** — entire classroom can run simultaneously, each session isolated
- **Research-grade assessment engine** — per-alarm reaction times, OOO detection, STCW grading
- **Portable distribution** — single `.exe` with embedded server, no Python installation required
- **Instructor Dashboard** — inject faults, reset modules, download research CSV — all in-browser

**Speaker Notes:**
Before v8, the procedure checklist was hardcoded: every scenario for a given module showed the same steps regardless of which fault was injected. A student doing a flame-failure scenario saw the same list as one doing a feed-pump-trip, which made the assessment meaningless. v8 introduces the Dynamic Procedure Manager — when the instructor injects a fault, the system immediately rebuilds the step list to show only the steps relevant to that specific scenario, in the correct STCW-prescribed order. This is the most significant pedagogical improvement in this version.

---

# Slide 5 — Dynamic Procedure Manager (Deep Dive)

**Slide Title:** How the Dynamic Procedure Manager Works

**Bullet Points:**
- Each fault scenario carries its own `expected_steps` list (e.g. flame failure vs. feed pump trip)
- On fault injection, the `AssessmentRulesRegistry` looks up the correct step sequence
- `DynamicProcedureManager` rebuilds the live procedure object in place — no page reload
- The UI receives an immediate `procedure_reset` event with the new step list
- Physics state is also immediately overridden (`interrupt_overrides`) for instant alarm visibility
- Instructors can chain scenarios: reset, inject a different fault, new procedure loads instantly

**Speaker Notes:**
Here is the technical flow for those who want to understand the internals. When the instructor selects "Fuel Valve Stuck Open" from the dashboard and clicks Inject, three things happen simultaneously: first, the physics state is overwritten via interrupt_overrides so that the boiler pressure jumps to just below the alarm threshold — the alarm fires on the very next one-second tick rather than after a 40-second warm-up. Second, the FaultInjectionEngine applies the scenario's logic function to the physics model. Third, the DynamicProcedureManager rebuilds the step checklist to show exactly the steps relevant to a runaway pressure scenario. The student's browser receives all three updates atomically. This matters because it prevents the confusing situation where an alarm is firing but the procedure panel shows irrelevant steps.

---

# Slide 6 — Physics Engine Accuracy

**Slide Title:** Real-World Physics — Why It Matters Pedagogically

**Bullet Points:**
- All systems use **first-order lag models** with calibrated time constants (τ) matching real equipment
- Boiler: 3-element water level, steam-demand coupling, safety valve lift simulation
- Refrigeration: full vapour-compression cycle — suction/discharge pressures, superheat tracking
- **Bernoulli leak model**: refrigerant and hydraulic leaks decay as `rate ∝ √pressure` not linearly
- DG synchronisation: generator must reach ≥92% RPM before circuit breaker can be closed
- OWS: bowl speed spin-up delay — no instant purification, mirrors real Alfa Laval behaviour

**Speaker Notes:**
Students often ask "is this realistic?" The answer is yes, to the degree that matters for training. Consider the refrigerant leak scenario: in a simple simulator, refrigerant drops by a fixed amount per second. In METS, the leak rate follows Bernoulli's principle — fast escape at high pressure, slowing as charge depletes. This teaches students why a newly discovered leak needs urgent attention, and why the compressor doesn't trip immediately. Similarly, the boiler water level uses a genuine three-element model: level, steam flow, and feedwater flow are all coupled. A student who simply starts the standby feed pump without first checking why the primary tripped will see the water level continue to drop if the underlying cause wasn't addressed. This mirrors real engine room dynamics and prevents students from learning incorrect shortcuts.

---

# Slide 7 — Fault Injection System

**Slide Title:** Controlled Fault Injection — Reproducible Assessment Conditions

**Bullet Points:**
- Instructor selects fault from dropdown menu — no student visibility
- Three difficulty levels: ★ (recognition), ★★ (diagnosis+action), ★★★ (emergency management)
- Example faults per module:
  - Boiler: Flame Failure, Feed Pump Trip, High Steam Demand, Fuel Valve Stuck Open
  - DG: Total Blackout, Governor Fault, Bus Overload
  - Refrigeration: Refrigerant Leak, Condenser Fouling, Compressor Trip
- Multiple students can run different scenarios simultaneously — sessions are fully isolated
- Inject → observe → reset cycle takes under 60 seconds

**Speaker Notes:**
The fault injection system is designed for rapid classroom iteration. A typical one-hour lab session might run like this: 15 minutes of pre-lab briefing, 30 minutes of simulator time where the instructor injects a ★ scenario for the first attempt and a ★★ scenario for the second, then 15 minutes of debrief using the downloaded CSV report. The difficulty progression is deliberate: ★ scenarios require the student to recognise the alarm and follow a well-practised sequence. ★★ scenarios require diagnosis — the alarm alone doesn't tell you what is wrong. ★★★ scenarios, like the DG blackout in a high-sea condition, require the student to manage multiple simultaneous alarms under time pressure while keeping essential consumers powered.

---

# Slide 8 — Assessment Engine & STCW Grading

**Slide Title:** Automated Assessment — Rigorous, Fair, Research-Ready

**Bullet Points:**
- Every operator action is timestamped and matched against the scenario's expected step sequence
- **Grading thresholds:** DISTINCTION ≥90% | PASS ≥75% | BORDERLINE PASS ≥60% | FAIL <60%
- **Time-budget penalties:** each step has a time allowance; overtime deducts 0.5 points per 2 seconds
- **Out-of-order (OOO) detection:** performing a step out of sequence deducts that step's full points
- **Critical step hard-fail:** skipping a STCW-critical step (e.g. notifying the bridge) forces FAIL regardless of score
- **Per-alarm reaction time:** individually tracked for research and debrief — not averaged across alarms

**Speaker Notes:**
The grading model was designed with two audiences in mind: the instructor who needs a defensible pass/fail decision, and the researcher who needs statistically valid data. On the assessment side: borderline pass sits 15 percentage points below the pass threshold, giving instructors a clear amber zone for students who need a remedial attempt rather than an outright fail. On the research side: alarm reaction times are computed per-alarm by matching each ACTIVE event to the first ACK event with the same alarm_id. This prevents the old bug where five simultaneous alarms would all be attributed a reaction time close to zero because the student pressed ACK once. The per-alarm data is exportable as a UTF-8 CSV with BOM — opens cleanly in Excel and imports directly into SPSS.

---

# Slide 9 — Integrating Into Your Curriculum

**Slide Title:** Practical Integration — Slot Into Any Existing Schedule

**Bullet Points:**
- **Pre-lab** (15 min): instructor introduces the system being studied using the included `.pptx` slides
- **Simulator lab** (45–60 min): students work individually or in pairs; instructor injects faults
- **Debrief** (15 min): instructor downloads CSV, projects score and reaction-time data on screen
- Assessment data integrates with standard grade books — scores are numeric, grades are categorical
- Can replace or supplement physical lab visits — not intended to eliminate ship visits entirely
- All lab materials (student manual, instructor guide, `.pptx` presentations) included in distribution

**Speaker Notes:**
Each of the ten labs ships with a ready-made PowerPoint presentation in the `instructor_presentations/` folder — these cover the real equipment, the operating principles, and the expected emergency procedures. The suggested workflow is: show the presentation, run the simulator, debrief with data. This three-phase structure takes 90 minutes and maps cleanly onto a standard double-period lab slot. For institutions that do run ship visits, we recommend using METS as preparation — students who have already diagnosed a boiler flame failure in the simulator perform significantly better during physical assessments because they arrive with procedural memory rather than just theoretical knowledge.

---

# Slide 10 — Research Capabilities

**Slide Title:** Built-In Research Tools — Beyond Pass/Fail

**Bullet Points:**
- Full session data persisted to SQLite database (`sessions` + `alarm_events` tables)
- Longitudinal tracking: student performance across multiple attempts per module
- Learning curve analysis: `get_learning_curve(student_id, module_id)` — score progression over attempts
- Cohort comparison: `get_cohort_summary(module_id)` — average performance across the class
- CSV export covers: reaction times, OOO violations, penalties, grades, elapsed time per step
- Suitable for ethics-approved studies in maritime education, human factors, and alarm management

**Speaker Notes:**
For colleagues who are also active researchers, METS provides a longitudinal data platform at no additional cost. The SQLite database grows automatically with each session. You can query it directly or use the built-in Python API. The session data is rich enough to support studies on alarm response habituation, the effect of difficulty progression on learning curves, and the cognitive load implications of simultaneous alarm events. The per-alarm reaction time data is particularly well-suited to ANOVA designs where alarm severity and student experience are the independent variables. If you are interested in running a collaborative study, the data schema is fully documented in the technical guide.

---

# Slide 11 — Getting Started (For Instructors)

**Slide Title:** Running Your First Lab — Five Steps

**Bullet Points:**
1. Double-click `START_SIMULATOR.bat` — browser opens automatically within 2 seconds
2. Select a lab module from the grid (e.g. Lab 2 — Boiler)
3. Open the **Instructor Panel** (right sidebar) — select a fault scenario
4. Click **⚡ Inject Selected Fault** — watch the alarm fire on the student dashboard
5. After the scenario, click **💾 Download Research CSV** for the session report

**Speaker Notes:**
First launch takes about 5 seconds while the simulation engine loads all ten modules. Subsequent sessions are immediate. The instructor and student can use different browser tabs on the same machine, or the instructor can use a separate device on the same local network — the simulator binds to all network interfaces. The Instructor Panel is hidden from students unless they know to look for it, but for maximum assessment integrity, consider running the instructor interface on a separate screen. The reset button is your best friend: between student attempts, one click resets the physics, clears the procedure, and loads the next scenario — no restart required.

---

# Slide 12 — Q&A & Resources

**Slide Title:** Questions & Further Resources

**Bullet Points:**
- Full documentation in `docs/Marine_Engineering_Training_Simulator_Guide.pdf`
- Student quick-start guide in `manuals/QUICK_START_GUIDE.md`
- Interactive lab guide in `manuals/INTERACTIVE_LAB_GUIDE.html`
- Module source code is readable Python — adaptable for specialist curricula
- Feedback and feature requests welcome — the system is under active development
- **Contact:** available through your institution's maritime department

**Speaker Notes:**
The simulator is deliberately open in its architecture. The physics modules are plain Python dataclasses — if your institution teaches a piece of equipment not currently in the simulator, the pattern for adding a new module is clear and well-documented. The fault scenarios are also straightforward to extend: each scenario is a data structure with a name, a difficulty, an expected step list, and a function that mutates the physics state. A competent Python developer could add a new scenario in an afternoon. We welcome collaboration from other institutions who want to add modules for their specific curriculum. Thank you for your time — I am happy to take questions, or we can move directly to a live demonstration.

---

*Presentation prepared for the Marine Engineering Training Simulator v8.0*
*© Maritime Education Technology — All rights reserved*
