"""PySide6.QtWidgets shim for headless mode."""

class QApplication:
    _instance = None

    def __init__(self, argv=None):
        QApplication._instance = self

    @classmethod
    def instance(cls):
        return cls._instance

    def exec_(self):
        pass

    def quit(self):
        pass
