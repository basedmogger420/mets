"""
PySide6 compatibility shim for headless server mode.
Provides QObject, Signal, QTimer stubs that satisfy the module interfaces
without requiring a real Qt installation.

Also includes QFile/QIODevice stubs needed by PyInstaller's PySide6 runtime hook.
"""


class _Signal:
    """Lightweight signal that stores connections and emits to them."""
    def __init__(self, *types):
        self._types = types

    def __set_name__(self, owner, name):
        self._name = name

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        key = f"_signal_{self._name}"
        if not hasattr(obj, key):
            setattr(obj, key, _BoundSignal())
        return getattr(obj, key)


class _BoundSignal:
    def __init__(self):
        self._slots = []

    def connect(self, slot):
        self._slots.append(slot)

    def disconnect(self, slot=None):
        if slot is None:
            self._slots.clear()
        else:
            self._slots = [s for s in self._slots if s is not slot]

    def emit(self, *args):
        for slot in self._slots:
            try:
                slot(*args)
            except Exception:
                pass


class QObject:
    def __init__(self, parent=None):
        self._parent = parent

    def deleteLater(self):
        pass


def Signal(*types):
    return _Signal(*types)


class QTimer:
    def __init__(self, parent=None):
        self._interval = 0
        self._single_shot = False
        self.timeout = _BoundSignal()

    def setInterval(self, ms):
        self._interval = ms

    def setSingleShot(self, v):
        self._single_shot = v

    def start(self, ms=None):
        pass

    def stop(self):
        pass

    @staticmethod
    def singleShot(ms, callback):
        pass


# ── Stubs needed by PyInstaller's PySide6 runtime hook ──────

class QIODevice:
    ReadOnly = 0x0001
    WriteOnly = 0x0002
    ReadWrite = 0x0003
    Text = 0x0010
    NotOpen = 0x0000

class QFile:
    """Stub for PyInstaller's create_embedded_qt_conf."""
    def __init__(self, path=""):
        self._path = str(path)
    def open(self, mode=0):
        return False
    def close(self):
        pass
    def write(self, data):
        return 0
    def exists(self, *args):
        return False
    def fileName(self):
        return self._path

class QLibraryInfo:
    """Stub — PyInstaller hook queries library paths."""
    @staticmethod
    def path(p):
        return ""
    @staticmethod
    def location(p):
        return ""
    LibraryPath = 0
    PluginsPath = 0
    PrefixPath = 0

class QCoreApplication:
    """Stub for PyInstaller hooks."""
    _instance = None
    def __init__(self, *args):
        QCoreApplication._instance = self
    @classmethod
    def instance(cls):
        return cls._instance
    def libraryPaths(self):
        return []
    def setLibraryPaths(self, paths):
        pass

# Version info that PyInstaller hooks check
__version__ = "6.0.0"
__version_info__ = (6, 0, 0)
