"""PySide6 headless shim package for server mode."""
__version__ = "6.0.0"
__version_info__ = (6, 0, 0)
