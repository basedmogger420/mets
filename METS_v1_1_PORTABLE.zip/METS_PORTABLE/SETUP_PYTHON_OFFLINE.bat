@echo off
chcp 65001 > nul 2>&1
title METS v1.0 - Python Offline Setup
setlocal

set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "EMBED_DIR=%ROOT%\python_embed"

echo.
echo  ============================================================
echo   METS v1.0 -- Python Offline Bundler
echo   Run ONCE on a PC with internet to create portable package
echo  ============================================================
echo.

if exist "%EMBED_DIR%\python.exe" (
    echo  [OK] Embedded Python already installed!
    echo  METS_v1.0.bat will run without internet on any PC.
    echo.
    pause
    exit /b 0
)

echo  This downloads Python 3.12 Embeddable (~11 MB) once.
echo  After this, copy the entire METS_v1.0 folder to USB.
echo  Students double-click METS_v1.0.bat - no internet needed.
echo.
set /p "GO=Press Enter to start download, or Ctrl+C to cancel: "

if not exist "%EMBED_DIR%" mkdir "%EMBED_DIR%"

set "URL=https://www.python.org/ftp/python/3.12.9/python-3.12.9-embed-amd64.zip"
set "ZIP=%TEMP%\py_embed_%RANDOM%.zip"

echo.
echo  Downloading from python.org...
powershell -NoProfile -Command ^
  "[Net.ServicePointManager]::SecurityProtocol='Tls12,Tls13';" ^
  "(New-Object Net.WebClient).DownloadFile('%URL%','%ZIP%')"

if not exist "%ZIP%" (
    echo  [ERROR] Download failed. Check internet connection.
    echo  Manual: download python-3.12.9-embed-amd64.zip from python.org
    echo  and unzip to: %EMBED_DIR%\
    pause
    exit /b 1
)

echo  Extracting...
powershell -NoProfile -Command ^
  "Expand-Archive -Path '%ZIP%' -DestinationPath '%EMBED_DIR%' -Force"
del "%ZIP%" 2>nul

:: Enable site-packages so stdlib modules work
if exist "%EMBED_DIR%\python312._pth" (
    powershell -NoProfile -Command ^
      "(Get-Content '%EMBED_DIR%\python312._pth') -replace '#import site','import site' | Set-Content '%EMBED_DIR%\python312._pth'"
)

if exist "%EMBED_DIR%\python.exe" (
    echo.
    echo  [OK] Python Embeddable installed successfully!
    echo.
    echo  METS now runs on ANY Windows PC without Python installed.
    echo  Copy the METS_v1.0 folder to USB and distribute to students.
    echo.
    "%EMBED_DIR%\python.exe" --version
) else (
    echo  [ERROR] Extraction failed. Check %EMBED_DIR%
)
pause
