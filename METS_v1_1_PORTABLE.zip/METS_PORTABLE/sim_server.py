# sim_server.py — Marine Engineering Training Simulator v1.0 (GOLD)
# ─────────────────────────────────────────────────────────────────────
# GOLD BUILD: All 52 audit fixes applied.
# ─────────────────────────────────────────────────────────────────────
from __future__ import annotations
import sys, os, socket, threading, json, time, traceback, webbrowser
import http.server, asyncio, logging, secrets, urllib.parse
from collections import deque
from pathlib import Path
from typing import Any, Dict, Optional, Set

class MockQObject:
    def __init__(self, *a, **kw): self._qp = {}; self._n = ""
    def setProperty(self, n, v):  self._qp[n] = v; return True
    def property(self, n):        return self._qp.get(n)
    def objectName(self):         return self._n
    def setObjectName(self, n):   self._n = n
    def parent(self):             return None
    def setParent(self, p):       pass
    def blockSignals(self, b):    return False

if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    _BASE = Path(sys._MEIPASS)
else:
    _BASE = Path(os.path.abspath(__file__)).parent

STATIC_DIR = _BASE / "web_ui"
LABS_DIR   = _BASE / "labs"
sys.path.insert(0, str(_BASE))

if getattr(sys, "frozen", False):
    _WS_PORT_JS_DIR = Path(sys.executable).parent
else:
    _WS_PORT_JS_DIR = STATIC_DIR

# FIX WINDOWS: Force UTF-8 output so Unicode chars work on any Windows console
import io as _io
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
elif hasattr(sys.stdout, 'buffer'):
    sys.stdout = _io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = _io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("mets")

# ── FIX #22: WebSocket max payload guard ──────────────────────────────────
MAX_WS_PAYLOAD = 256 * 1024  # 256 KB

# ── FIX #2: Auth token generated at startup ───────────────────────────────
_WS_AUTH_TOKEN: str = secrets.token_hex(16)

def find_free_port(start: int, end: int = 0) -> int:
    if end == 0:
        end = start + 120
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("", port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]

def write_ws_port_config(http_port: int, ws_port: int) -> None:
    js_path = _WS_PORT_JS_DIR / "ws_port.js"
    try:
        js_path.write_text(
            f"// Auto-generated at startup — do not edit manually\n"
            f"window.METS_HTTP_PORT = {http_port};\n"
            f"window.METS_WS_PORT   = {ws_port};\n"
            f"// FIX: Support both localhost and LAN access\n"
            f"window.METS_WS_URL    = 'ws://' + (window.location.hostname || 'localhost') + ':{ws_port}';\n"
            f"window.METS_AUTH_TOKEN = '{_WS_AUTH_TOKEN}';\n",
            encoding="utf-8")
        log.info("ws_port.js written  ->  HTTP=%d  WS=%d", http_port, ws_port)
    except Exception as e:
        log.warning("Could not write ws_port.js: %s", e)

# ── FIX #1 + #37: Path Traversal protection + Security Headers ────────────
class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(STATIC_DIR), **kw)

    def log_message(self, *a): pass
    def log_error(self, fmt, *a): log.warning("HTTP: " + fmt % a)

    def end_headers(self):
        # FIX #37: Security headers
        self.send_header("Content-Security-Policy",
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self' 'unsafe-inline'; "
            "connect-src 'self' ws://localhost:* ws://127.0.0.1:*; "
            "img-src 'self' data:;")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()

    def do_GET(self):
        # FIX #1: Normalize and sanitize path before checking
        try:
            decoded_path = urllib.parse.unquote(self.path).split("?")[0]
        except Exception:
            self.send_error(400, "Bad Request")
            return
        norm = os.path.normpath(decoded_path).replace("\\", "/")
        if not norm.startswith("/"):
            norm = "/" + norm
        # Block traversal attempts
        if ".." in decoded_path or "\\" in decoded_path:
            self.send_error(403, "Forbidden")
            return
        # Block sensitive file types
        blocked_ext = ('.py', '.pyc', '.sqlite', '.db', '.bat', '.sh', '.env', '.pem')
        if any(norm.lower().endswith(ext) for ext in blocked_ext):
            self.send_error(403, "Forbidden")
            return
        # FIX #43: Fixed duplicate tuple
        if norm == "/ws_port.js":
            ws_js = _WS_PORT_JS_DIR / "ws_port.js"
            if ws_js.exists():
                data = ws_js.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
                return
        super().do_GET()

def start_http_server(port: int) -> None:
    srv = http.server.HTTPServer(("", port), _QuietHandler)
    threading.Thread(target=srv.serve_forever, daemon=True, name="http").start()
    log.info("HTTP  ->  http://localhost:%d", port)

# ══════════════════════════════════════════════════════════════
#  SIMULATION ENGINE
# ══════════════════════════════════════════════════════════════

_engine  = None
_modules: Dict[str, Any] = {}
_alarm_buf: deque = deque(maxlen=200)
# FIX #24: Lock for concurrent alarm buffer access
_alarm_lock = threading.Lock()
_clients: Set[asyncio.StreamWriter] = set()
_tick_task: Optional[asyncio.Task]  = None
_client_lab: Dict[asyncio.StreamWriter, Optional[str]] = {}

def _build_engine():
    global _engine, _modules
    from marine_simulator.core.simulation_engine import SimulationEngine
    from marine_simulator.core.assessment_rules import (
        register_module_rules,
        patch_base_module_inject_fault,
    )
    patch_base_module_inject_fault()
    _engine = SimulationEngine()
    registry = {
        "boiler":               ("marine_simulator.modules.boiler.boiler_module",             "BoilerModule"),
        "oily_water_separator": ("marine_simulator.modules.oily_water_separator.ows_module",   "OWSModule"),
        "diesel_generator":     ("marine_simulator.modules.diesel_generator.dg_module",        "DGModule"),
        "refrigeration":        ("marine_simulator.modules.refrigeration.refrig_module",       "RefrigerationModule"),
        "fuel_separator":       ("marine_simulator.modules.fuel_separator.fsep_module",        "FuelSeparatorModule"),
        "hydrophore":           ("marine_simulator.modules.hydrophore.hydro_module",           "HydrophoreModule"),
        "fw_generator":         ("marine_simulator.modules.fw_generator.fwg_module",           "FWGModule"),
        "steering_gear":        ("marine_simulator.modules.steering_gear.steer_module",        "SteeringModule"),
        "fuel_conditioning":    ("marine_simulator.modules.fuel_conditioning.fcm_module",      "FCMModule"),
        "cooling_system":       ("marine_simulator.modules.cooling_system.csf_module",         "CoolingSystemModule"),
    }
    for mid, (pkg, cls) in registry.items():
        try:
            m = getattr(__import__(pkg, fromlist=[cls]), cls)()
            m.start()
            m.alarm_raised.connect(lambda aid, sev, _m=mid: _on_alarm(_m, aid, sev))
            m.alarm_cleared.connect(lambda aid, sev, _m=mid: _on_alarm(_m, aid, 0))
            _modules[mid] = m
            _engine.register(m)
            register_module_rules(m)
            log.info("  [OK] %s", mid)
        except Exception:
            log.warning("  [FAIL] %s\n%s", mid, traceback.format_exc(limit=2))
    log.info("Engine ready — %d modules", len(_modules))

def _on_alarm(module_id, alarm_id, severity):
    e = {"module": module_id, "alarm_id": alarm_id,
         "severity": severity, "tick": (_engine.tick_count if _engine else 0),
         "ts": round(time.monotonic(), 2)}
    with _alarm_lock:
        _alarm_buf.append(e)

_lab_defs: Dict[str, dict] = {}

def _load_labs():
    if not LABS_DIR.exists():
        log.warning("labs/ not found at %s", LABS_DIR); return
    for p in sorted(LABS_DIR.glob("*.json")):
        try:
            d = json.loads(p.read_text("utf-8"))
            _lab_defs[d.get("module_id", p.stem)] = d
        except Exception as e:
            log.warning("Lab %s: %s", p.name, e)
    log.info("Labs: %d loaded", len(_lab_defs))

def _check_physics_alarms():
    boiler = _modules.get("boiler")
    if boiler:
        try:
            lvl = boiler.get_state().get("water_level_pct", 50)
            if lvl < 20:   _on_alarm("boiler", "SRV_BOILER_LOW_LEVEL", 3)
            elif lvl > 80: _on_alarm("boiler", "SRV_BOILER_HIGH_LEVEL", 2)
        except Exception: pass
    fwg = _modules.get("fw_generator")
    if fwg:
        try:
            sal = fwg.get_state().get("salinity_ppm", 0)
            if sal > 5:
                _on_alarm("fw_generator", "SRV_FWG_HIGH_SALINITY", 3)
                if hasattr(fwg, "trigger_auto_dump"): fwg.trigger_auto_dump()
        except Exception: pass
    fsep = _modules.get("fuel_separator")
    if fsep:
        try:
            if fsep.get_state().get("sludge_level_pct", 0) > 95:
                _on_alarm("fuel_separator", "SRV_FSEP_SLUDGE_FULL", 2)
        except Exception: pass

async def _ws_send(w: asyncio.StreamWriter, data: dict) -> bool:
    try:
        raw = json.dumps(data, default=str).encode()
        n   = len(raw)
        hdr = (bytes([0x81, n]) if n < 126 else
               bytes([0x81, 126]) + n.to_bytes(2, "big") if n < 65536 else
               bytes([0x81, 127]) + n.to_bytes(8, "big"))
        w.write(hdr + raw)
        await asyncio.wait_for(w.drain(), timeout=0.5)
        return True
    except (asyncio.TimeoutError, Exception):
        return False

async def _broadcast(data: dict):
    dead = set()
    for w in list(_clients):
        if not await _ws_send(w, data): dead.add(w)
    _clients.difference_update(dead)

def _decode_frame(buf: bytes):
    if len(buf) < 2: return None, 0
    masked  = bool(buf[1] & 0x80)
    pay_len = buf[1] & 0x7F
    idx     = 2
    if pay_len == 126:
        if len(buf) < 4: return None, 0
        pay_len = int.from_bytes(buf[2:4], "big"); idx = 4
    elif pay_len == 127:
        if len(buf) < 10: return None, 0
        pay_len = int.from_bytes(buf[2:10], "big"); idx = 10
        # FIX #22: Reject oversized frames
        if pay_len > MAX_WS_PAYLOAD:
            return "__close__", 0
    need = idx + (4 if masked else 0) + pay_len
    if len(buf) < need: return None, 0
    if masked:
        mask = buf[idx:idx+4]; idx += 4
        payload = bytes(buf[idx+i] ^ mask[i%4] for i in range(pay_len))
    else:
        payload = buf[idx:idx+pay_len]
    opcode = buf[0] & 0x0F
    if opcode == 8: return "__close__", need
    if opcode == 9: return "__ping__",  need
    try:    return payload.decode(), need
    except: return None, need

def _ws_upgrade(raw: bytes):
    import base64, hashlib
    txt = raw.decode("utf-8", errors="replace")
    if "Upgrade: websocket" not in txt: return b""
    key = next((l.split(":",1)[1].strip() for l in txt.splitlines()
                if l.lower().startswith("sec-websocket-key:")), "")
    acc = base64.b64encode(hashlib.sha1(
        (key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
    return ("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n"
            f"Connection: Upgrade\r\nSec-WebSocket-Accept: {acc}\r\n\r\n").encode()

# FIX #10: Track per-client alarm cursor to send only NEW alarms
_client_alarm_cursor: Dict[asyncio.StreamWriter, int] = {}
# FIX BUG-1: Track per-client modules for which hard_fail has already been sent,
# so the event fires exactly once and not on every subsequent tick.
_client_hard_fail_sent: Dict[asyncio.StreamWriter, set] = {}

async def _tick_loop():
    first = True
    while True:
        if not first:
            await asyncio.sleep(1.0)
        first = False
        if not _clients: continue
        if _engine:
            try:
                _engine.tick()
            except Exception:
                log.warning("Engine tick error:\n%s", traceback.format_exc(limit=2))
        try: _check_physics_alarms()
        except Exception: pass
        for w in list(_clients):
            mid = _client_lab.get(w)
            if not (mid and mid in _modules): continue
            m = _modules[mid]
            try:
                st = m.get_state()
                # FIX #10: Send only new alarms since last cursor
                tick_now = (_engine.tick_count if _engine else 0)
                cursor = _client_alarm_cursor.get(w, 0)
                with _alarm_lock:
                    new_alarms = [a for a in _alarm_buf
                                  if a.get("module") == mid and a.get("ts", 0) > cursor]
                if new_alarms:
                    _client_alarm_cursor[w] = new_alarms[-1].get("ts", cursor)
                await _ws_send(w, {
                    "type": "telemetry", "module_id": mid, "module": mid,
                    "tick": tick_now, "data": st, "state": st,
                    "alarms": new_alarms,
                })
                proc = st.get("procedure")
                if proc:
                    await _ws_send(w, {
                        "type": "procedure_update",
                        "module": mid, "module_id": mid,
                        "procedure": proc,
                        "scenario_id": st.get("scenario_id"),
                    })
                # FIX BUG-1: Send hard_fail event exactly once per module per session.
                # Previously checked st.get("_hard_fail_notified") which is never set
                # in get_state() -> hard_fail was re-broadcast every tick indefinitely.
                hf_key = mid
                already_sent = _client_hard_fail_sent.get(w, set())
                if proc and proc.get("hard_fail") and hf_key not in already_sent:
                    already_sent.add(hf_key)
                    _client_hard_fail_sent[w] = already_sent
                    await _ws_send(w, {
                        "type": "hard_fail",
                        "module": mid,
                        "reason": proc.get("hard_fail_reason", "Critical limit exceeded"),
                    })
            except Exception:
                log.debug("Tick send err: %s", traceback.format_exc(limit=2))

async def _dispatch(w: asyncio.StreamWriter, msg: str):
    try: cmd = json.loads(msg)
    except: return
    t = cmd.get("type","")
    my_lab = _client_lab.get(w)

    # FIX #2: Require auth token for all non-handshake messages
    if t not in ("hello", "connect"):
        token = cmd.get("auth_token", "")
        if token != _WS_AUTH_TOKEN:
            await _ws_send(w, {"type": "error", "message": "Unauthorized — invalid auth token"})
            return

    if t in ("hello", "connect"):
        await _ws_send(w, {"type": "connected", "server": "METS v1.0",
                           "auth_token": _WS_AUTH_TOKEN})
        await _ws_send(w, {"type": "lab_list", "labs": [
            {"id": mid, "module_id": mid, "lab_no": i+1,
             "name_en": d.get("title_en",""), "name_ua": d.get("title_ua",""),
             "gauges": d.get("gauges",[]), "scenarios": d.get("scenarios",[])}
            for i,(mid,d) in enumerate(_lab_defs.items())
        ]})
        return

    if t == "select_lab":
        mid = cmd.get("lab_id") or cmd.get("module_id","")
        if mid in _modules:
            _client_lab[w] = mid
            _client_alarm_cursor[w] = 0  # FIX #10: reset cursor on lab select
            _client_hard_fail_sent[w] = set()  # FIX BUG-1: reset hard_fail tracker on new lab
            _modules[mid].reset()
            await _ws_send(w, {"type": "lab_started", "module": mid, "module_id": mid,
                               "lab_def": _lab_defs.get(mid,{})})
        return

    if t == "command":
        mid    = cmd.get("module", my_lab)
        action = cmd.get("action","")
        args   = cmd.get("args",[])
        # FIX #16 (Security): Block private/dunder methods
        if not action or action.startswith("_"):
            return
        if mid in _modules:
            mod = _modules[mid]
            _POWER_ACTIONS = ("start_", "restore_", "relight_", "start_compressor",
                              "start_separator", "start_pump")
            if (mid != "diesel_generator"
                    and not getattr(mod, "_power_available", True)
                    and any(action.startswith(p) or action == p for p in _POWER_ACTIONS)):
                await _ws_send(w, {"type": "error", "message": "No power available — restore DG first"})
                return
            fn = getattr(mod, action, None)
            if callable(fn):
                try: fn(*args)
                except Exception as e: log.warning("Action %s: %s", action, e)
            # FIX #8: Check for hard_fail after action
            if hasattr(mod, '_procedure') and mod._procedure.hard_fail:
                await _ws_send(w, {
                    "type": "hard_fail", "module": mid,
                    "reason": mod._procedure.hard_fail_reason
                })
        if action == "inject_fault" and args and mid in _modules:
            await _ws_send(w, {"type": "fault_injected", "module": mid,
                                "scenario_id": args[0], "ok": True})
        return

    if t == "inject_fault":
        mid   = cmd.get("module_id") or cmd.get("module", my_lab)
        sc_id = cmd.get("scenario_id","")
        if mid in _modules:
            ok = _modules[mid].inject_fault(sc_id)
            await _ws_send(w, {"type": "fault_injected", "module": mid,
                                "scenario_id": sc_id, "ok": ok})
        return

    if t == "ack_alarm":
        mid = cmd.get("module_id") or cmd.get("module", my_lab)
        aid = cmd.get("alarm_id","")
        if mid in _modules and hasattr(_modules[mid],"acknowledge_alarm"):
            _modules[mid].acknowledge_alarm(aid)
        return

    if t == "reset":
        mid = cmd.get("module_id") or cmd.get("module", my_lab)
        if mid in _modules:
            _modules[mid].reset()
            # FIX BUG-9: cursor=0 meant ALL alarms in the deque (ts >> 0) were
            # replayed to the client after reset.  Set cursor to now so only
            # NEW alarms generated after the reset are delivered.
            _client_alarm_cursor[w] = round(time.monotonic(), 2)
            # FIX BUG-10: clear hard_fail tracker so a new fault injection in the
            # same session can fire the hard_fail event again after reset.
            if w in _client_hard_fail_sent:
                _client_hard_fail_sent[w].discard(mid)
            await _ws_send(w, {"type": "reset_ack", "module": mid})
        return

async def _handle_client(r: asyncio.StreamReader, w: asyncio.StreamWriter):
    global _tick_task
    addr = w.get_extra_info("peername")
    log.info("WS connect: %s", addr)
    buf = b""
    while b"\r\n\r\n" not in buf:
        c = await r.read(4096)
        if not c: w.close(); return
        buf += c
    resp = _ws_upgrade(buf)
    if not resp: w.close(); return
    w.write(resp); await w.drain()
    _client_lab[w] = None
    _client_alarm_cursor[w] = 0
    _client_hard_fail_sent[w] = set()
    _clients.add(w)
    if _tick_task is not None and _tick_task.done():
        _tick_task.cancel()
        try: await _tick_task
        except (asyncio.CancelledError, Exception): pass
    if _tick_task is None or _tick_task.done():
        _tick_task = asyncio.ensure_future(_tick_loop())
    # Send auth token with connection response
    await _ws_send(w, {"type": "connected", "server": "METS v1.0",
                       "auth_token": _WS_AUTH_TOKEN})
    await _ws_send(w, {"type": "lab_list", "labs": [
        {"id": mid, "module_id": mid, "lab_no": i+1,
         "name_en": d.get("title_en",""), "name_ua": d.get("title_ua",""),
         "gauges": d.get("gauges",[]), "scenarios": d.get("scenarios",[])}
        for i,(mid,d) in enumerate(_lab_defs.items())
    ]})
    buf = b""
    try:
        while True:
            c = await r.read(4096)
            if not c: break
            buf += c
            # FIX #22: Drop oversized buffers
            if len(buf) > MAX_WS_PAYLOAD * 2:
                log.warning("WS buffer overflow from %s — disconnecting", addr)
                break
            while buf:
                txt, n = _decode_frame(buf)
                if n == 0: break
                buf = buf[n:]
                if txt == "__close__": raise ConnectionResetError
                if txt == "__ping__": w.write(bytes([0x8A,0])); await w.drain()
                elif txt: await _dispatch(w, txt)
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError): pass
    except Exception: log.debug("WS err:\n%s", traceback.format_exc(limit=3))
    finally:
        # FIX #13: Only reset if no other client is using the module
        abandoned_lab = _client_lab.get(w)
        _client_lab.pop(w, None)
        _client_alarm_cursor.pop(w, None)
        _client_hard_fail_sent.pop(w, None)   # FIX BUG-1: prevent memory leak on disconnect
        _clients.discard(w)
        if abandoned_lab and abandoned_lab in _modules:
            other_users = [ow for ow, lab in _client_lab.items() if lab == abandoned_lab]
            if not other_users:
                try:
                    _modules[abandoned_lab].reset()
                    log.info("WS disconnect: reset module '%s' for next student", abandoned_lab)
                except Exception:
                    log.debug("Module reset on disconnect failed: %s", traceback.format_exc(limit=2))
        try: w.close()
        except: pass
        log.info("WS disconnect: %s", addr)

async def _ws_main(ws_port: int):
    # FIX #2: Bind to 127.0.0.1 for localhost-only access
    server = await asyncio.start_server(_handle_client, "127.0.0.1", ws_port)
    log.info("WS    ->  ws://localhost:%d", ws_port)
    async with server:
        await server.serve_forever()

def main():
    http_port = find_free_port(8080)
    ws_port   = find_free_port(8765)
    write_ws_port_config(http_port, ws_port)
    _load_labs()
    _build_engine()
    start_http_server(http_port)
    url = f"http://localhost:{http_port}"
    def _open():
        time.sleep(1.2)
        try: webbrowser.open(url)
        except Exception as e: log.warning("Browser open failed: %s", e)
    threading.Thread(target=_open, daemon=True, name="browser").start()
    sep = "=" * 56
    print(f"\n{sep}")
    print(f"  METS v1.0 -- Marine Engineering Training Simulator")
    print(f"{'-' * 56}")
    print(f"  HTTP  ->  {url}")
    print(f"  WS    ->  ws://localhost:{ws_port}")
    print(f"  Press Ctrl+C to stop")
    print(f"{sep}\n")
    try:
        asyncio.run(_ws_main(ws_port))
    except KeyboardInterrupt:
        print("\n  METS v1.0 -- Server stopped.")

if __name__ == "__main__":
    main()
