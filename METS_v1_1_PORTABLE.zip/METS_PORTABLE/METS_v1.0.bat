@echo off
chcp 65001 > nul 2>&1
setlocal EnableDelayedExpansion
title METS v1.0 - Marine Engineering Training Simulator

:: ============================================================
::  METS v1.0 -- Smart Launcher  (c) 2025
::  Tries: embedded Python > system Python > winget > Store
:: ============================================================

set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "EMBED=%ROOT%\python_embed\python.exe"
set "PY="

echo.
echo  ============================================================
echo   METS v1.0  --  Marine Engineering Training Simulator
echo   STCW A-III/1  ^|  www.mets-simulator.edu
echo  ============================================================
echo.

:: ── Priority 1: Bundled embedded Python ─────────────────────
if exist "%EMBED%" (
    echo  [OK] Using bundled Python ^(offline mode^)
    set "PY=%EMBED%"
    goto :launch
)

:: ── Priority 2: python.exe in PATH ──────────────────────────
python --version > nul 2>&1
if !errorlevel! == 0 (
    for /f "tokens=*" %%P in ('where python 2^>nul') do (
        if not defined PY set "PY=%%P"
    )
    if defined PY (
        "%PY%" -c "import sys;exit(0 if sys.version_info>=(3,8) else 1)" > nul 2>&1
        if !errorlevel! == 0 (
            echo  [OK] Found Python: !PY!
            goto :launch
        ) else (
            echo  [!!] Python too old ^(need 3.8+^), searching...
            set "PY="
        )
    )
)

:: ── Priority 3: py launcher ──────────────────────────────────
py -3 --version > nul 2>&1
if !errorlevel! == 0 (
    echo  [OK] Using Windows Python Launcher ^(py.exe^)
    set "PY=py -3"
    goto :launch
)

:: ── Priority 4: Common install paths ────────────────────────
for %%V in (313 312 311 310 39 38) do (
    for %%P in (
        "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        "%PROGRAMFILES%\Python%%V\python.exe"
        "C:\Python%%V\python.exe"
    ) do (
        if exist %%P if not defined PY (
            set "PY=%%P"
            echo  [OK] Found Python: %%P
        )
    )
)
if defined PY goto :launch

:: ── Priority 5: Microsoft Store Python ──────────────────────
for /f "tokens=*" %%P in ('where python3 2^>nul') do (
    if not defined PY (
        echo  [OK] Found Python: %%P
        set "PY=%%P"
    )
)
if defined PY goto :launch

:: ── Not found: offer auto-install ───────────────────────────
echo.
echo  [!!] Python 3.8+ not found on this computer.
echo.
echo  Choose how to install Python:
echo   1 - Download automatically via winget ^(Windows 10/11^)
echo   2 - Open python.org download page in browser
echo   3 - Exit ^(I will install Python manually^)
echo.
set /p "CHOICE=Enter 1, 2, or 3: "

if "%CHOICE%"=="1" goto :winget_install
if "%CHOICE%"=="2" goto :browser_install
echo  Exiting. Please install Python 3.12 from python.org
pause
exit /b 1

:winget_install
echo  Installing Python 3.12 via winget...
winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
if !errorlevel! == 0 (
    echo  [OK] Python installed! Restarting...
    timeout /t 3 > nul
    :: Refresh PATH
    for /f "tokens=*" %%P in ('where python 2^>nul') do if not defined PY set "PY=%%P"
    if defined PY goto :launch
    set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    if exist "!PY!" goto :launch
)
echo  [!!] winget install failed. Try option 2.
goto :not_found

:browser_install
start https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe
echo  Downloading Python installer...
echo  When installed, run this bat file again.
pause
exit /b 0

:not_found
echo  Python not found. Install from https://python.org then run again.
pause
exit /b 1

:launch
echo  Starting METS v1.0...
echo  Browser opens automatically at http://localhost:8080
echo  Press Ctrl+C to stop the server.
echo.
cd /d "%ROOT%"
if "%PY%"=="py -3" (
    py -3 run_simulator.py
) else (
    "%PY%" run_simulator.py
)
if !errorlevel! neq 0 (
    echo.
    echo  [ERROR] Server exited with code !errorlevel!
    echo  Check the output above for details.
    echo.
    pause
)
