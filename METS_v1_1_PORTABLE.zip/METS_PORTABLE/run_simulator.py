#!/usr/bin/env python3
"""
run_simulator.py — Marine Engineering Training Simulator v1.0

Just run: python run_simulator.py
Browser opens automatically once the server prints its HTTP port.
No external packages needed.

FIX LOG:
  FIX R-1: Added atexit + proc.terminate() to prevent orphan server process
            when parent crashes or is killed without KeyboardInterrupt.
  FIX R-2: Added fallback URL (http://localhost:8080) if server does not print
            its URL within 15 seconds — browser still opens automatically.
"""
import subprocess, sys, os, re, threading, time, webbrowser, atexit
import io as _io
# FIX WINDOWS: Force UTF-8 output on Windows consoles (cp1251 can't handle box-drawing chars)
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

_proc = None  # FIX R-1: global ref so atexit can terminate the child


def _cleanup():
    """FIX R-1: Kill server if parent exits for any reason (crash, kill, etc.)"""
    if _proc is not None:
        try:
            _proc.terminate()
        except Exception:
            pass


atexit.register(_cleanup)


def _tail_for_url(proc: subprocess.Popen) -> None:
    """
    FIX H-1: Read sim_server stdout until the 'HTTP → http://...' line appears,
    then open THAT exact URL.  Previously the URL was hardcoded to
    http://localhost:8080, which was wrong whenever port 8080 was already taken
    and sim_server.py bound to a different dynamic port.

    FIX R-2: If no URL appears within 15 s (slow machine, heavy load), fall back
    to http://localhost:8080 so the browser still opens automatically.
    """
    url_pattern = re.compile(r"HTTP\s*[→>]\s*(http://\S+)")
    url_opened  = False

    # FIX R-2: start a fallback timer — fires if the URL line never appears
    def _fallback():
        time.sleep(15)
        if not url_opened:
            fallback = "http://localhost:8080"
            print(f"\n  (URL not detected after 15 s — trying {fallback})")
            try:
                webbrowser.open(fallback)
            except Exception:
                print(f"  Please open manually: {fallback}")

    threading.Thread(target=_fallback, daemon=True).start()

    for line in proc.stdout:
        print(line, end="")           # pass-through to terminal
        if not url_opened:
            m = url_pattern.search(line)
            if m:
                url = m.group(1).rstrip("/")
                try:
                    webbrowser.open(url)
                except Exception as e:
                    print(f"  (Could not open browser automatically: {e})")
                    print(f"  Please open manually: {url}")
                url_opened = True


if __name__ == "__main__":
    root   = os.path.dirname(os.path.abspath(__file__))
    server = os.path.join(root, "sim_server.py")

    print(f"\nMETS v1.0 -- Marine Engineering Training Simulator")
    print(f"   Starting server…\n")

    try:
        _proc = subprocess.Popen(
            [sys.executable, "-u", server],
            cwd=root,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        threading.Thread(target=_tail_for_url, args=(_proc,), daemon=True).start()
        _proc.wait()
        if _proc.returncode not in (0, None, -15):  # -15 = SIGTERM (normal shutdown)
            print(f"\n  [ERROR] Server exited with code {_proc.returncode}.")
            print("  Check output above for details.")
    except KeyboardInterrupt:
        print("\n  Server stopped.")


