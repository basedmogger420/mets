@echo off
chcp 65001 > nul
title METS v1.0 - Marine Engineering Training Simulator
echo.
echo  =====================================================
echo   METS v1.0 - Marine Engineering Training Simulator
echo   STCW A-III/1 Competence Assessment Platform
echo  =====================================================
echo.
echo  Starting server... Browser will open automatically.
echo  Press Ctrl+C to stop the simulator.
echo.
python run_simulator.py
pause
