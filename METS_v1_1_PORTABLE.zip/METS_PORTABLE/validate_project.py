# -*- coding: utf-8 -*-
from __future__ import annotations
# FIX WINDOWS: Force UTF-8 console output on Windows (cp1251 can't handle box-drawing chars)
import sys as _sys, io as _io
if hasattr(_sys.stdout, 'reconfigure'):
    try:
        _sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        _sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
elif hasattr(_sys.stdout, 'buffer'):
    try:
        _sys.stdout = _io.TextIOWrapper(_sys.stdout.buffer, encoding='utf-8', errors='replace')
        _sys.stderr = _io.TextIOWrapper(_sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

#!/usr/bin/env python3
"""
validate_project.py — METS v1.0 Project Integrity Validator
=============================================================
GOLD BUILD: All 6 checks now functional.
FIX #45: Corrected JSON key (module_id, not lab_id) and added get_scenario_list()
         support via BaseLabModule. Added check [H] for step ID consistency.

Checks performed for all 10 labs:
  [A] Every gauge key in labs/*.json has a matching key in physics get_state()
  [B] Every control action in labs/*.json has a matching method on the module
  [C] Every scenario ID in labs/*.json matches a key in FAULT_SCENARIOS
  [D] Every Python scenario has a matching entry in labs/*.json
  [E] All get_state() values are JSON-serialisable (no NaN / Infinity)
  [F] Gauge threshold fields are numeric (not strings)
  [G] Gauge max >= crit_high * 1.20 (visual headroom)
  [H] JSON scenario step IDs match Python expected_steps (FIX #45)
"""

import json, math, os, sys, types, argparse

# ── PySide6 shim ─────────────────────────────────────────────────────────────
class _Sig:
    def __init__(self, *a, **k): self._o = []
    def connect(self, f): self._o.append(f)
    def emit(self, *a, **k):
        for f in self._o:
            try: f(*a, **k)
            except Exception: pass

class _MQO:
    def __init__(self, *a, **k): self._qprops = {}; self._obj_name = ""
    def setProperty(self, n, v): self._qprops[n] = v; return True
    def property(self, n): return self._qprops.get(n)
    def objectName(self): return self._obj_name
    def setObjectName(self, n): self._obj_name = n
    def parent(self): return None
    def setParent(self, p): pass
    def blockSignals(self, b): return False

_qt = types.ModuleType("PySide6.QtCore")
_qt.Signal, _qt.QObject, _qt.QTimer = _Sig, _MQO, _MQO
sys.modules["PySide6"]           = types.ModuleType("PySide6")
sys.modules["PySide6.QtCore"]    = _qt
sys.modules["PySide6.QtWidgets"] = types.ModuleType("PySide6.QtWidgets")

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

# FIX #45: Use module_id as key (matches labs/*.json "module_id" field)
MODULE_MAP: dict[str, tuple[str, str]] = {
    "oily_water_separator": ("marine_simulator.modules.oily_water_separator.ows_module", "OWSModule"),
    "boiler":               ("marine_simulator.modules.boiler.boiler_module",             "BoilerModule"),
    "fw_generator":         ("marine_simulator.modules.fw_generator.fwg_module",           "FWGModule"),
    "refrigeration":        ("marine_simulator.modules.refrigeration.refrig_module",       "RefrigerationModule"),
    "hydrophore":           ("marine_simulator.modules.hydrophore.hydro_module",           "HydrophoreModule"),
    "diesel_generator":     ("marine_simulator.modules.diesel_generator.dg_module",        "DGModule"),
    "fuel_separator":       ("marine_simulator.modules.fuel_separator.fsep_module",        "FuelSeparatorModule"),
    "fuel_conditioning":    ("marine_simulator.modules.fuel_conditioning.fcm_module",      "FCMModule"),
    "steering_gear":        ("marine_simulator.modules.steering_gear.steer_module",        "SteeringModule"),
    "cooling_system":       ("marine_simulator.modules.cooling_system.csf_module",         "CoolingSystemModule"),
}

RESET = "\033[0m"; RED = "\033[91m"; GREEN = "\033[92m"; YELLOW = "\033[93m"; BOLD = "\033[1m"
def _ok(msg):   return f"{GREEN}  [OK] {msg}{RESET}"
def _err(msg):  return f"{RED}  [FAIL] {msg}{RESET}"
def _warn(msg): return f"{YELLOW}  [WARN] {msg}{RESET}"

def _is_json_safe(v) -> bool:
    if isinstance(v, float):
        return not (math.isnan(v) or math.isinf(v))
    if isinstance(v, dict):
        return all(_is_json_safe(x) for x in v.values())
    if isinstance(v, (list, tuple)):
        return all(_is_json_safe(x) for x in v)
    try: json.dumps(v); return True
    except (TypeError, ValueError): return False


def validate(strict: bool = False) -> int:
    labs_dir = os.path.join(ROOT, "labs")
    if not os.path.isdir(labs_dir):
        print(_err(f"labs/ directory not found at {labs_dir}"))
        return 1

    total_issues = 0
    total_checks = 0

    print(f"\n{BOLD}METS v1.0 — Project Integrity Validation (GOLD){RESET}")
    print("=" * 66)

    for lab_file in sorted(os.listdir(labs_dir)):
        if not lab_file.endswith(".json"):
            continue

        lab_path = os.path.join(labs_dir, lab_file)
        try:
            with open(lab_path, encoding="utf-8") as fh:
                lab_def = json.load(fh)
        except Exception as e:
            print(_err(f"{lab_file}: cannot parse JSON — {e}"))
            total_issues += 1
            continue

        # FIX #45: Use module_id key (not lab_id which was always wrong)
        module_id = lab_def.get("module_id", "")
        lab_no    = lab_def.get("lab_no", "?")
        gauges    = lab_def.get("gauges", [])
        controls  = lab_def.get("controls", []) + lab_def.get("common_controls", [])
        scenarios = lab_def.get("scenarios", [])

        print(f"\n  {BOLD}Lab {lab_no}: {module_id}{RESET}")

        if module_id not in MODULE_MAP:
            print(_err(f"  {module_id}: not in MODULE_MAP — skipping"))
            total_issues += 1
            continue

        mod_path, cls_name = MODULE_MAP[module_id]
        try:
            pkg = __import__(mod_path, fromlist=[cls_name])
            ModClass = getattr(pkg, cls_name)
            instance = ModClass()
            instance.start()
        except Exception as e:
            print(_err(f"  Cannot instantiate {cls_name}: {e}"))
            total_issues += 1
            continue

        state_keys     = set(instance.get_state().keys())
        module_methods = {m for m in dir(instance) if not m.startswith("_")}
        # FIX #45: Use get_scenario_list() which is now defined in BaseLabModule
        py_scenarios   = {s["id"]: s for s in instance.get_scenario_list()}

        # [A] Gauge keys vs get_state()
        for g in gauges:
            gid = g.get("id", "")
            total_checks += 1
            if gid in state_keys:
                print(_ok(f"[A] gauge '{gid}' -> get_state() OK"))
            else:
                print(_err(f"[A] gauge '{gid}' NOT in get_state() — UI will show NaN"))
                total_issues += 1

        # [B] Control actions vs module methods
        for c in controls:
            action = c.get("action", "")
            total_checks += 1
            if action in module_methods:
                print(_ok(f"[B] control '{action}' -> module method OK"))
            else:
                print(_err(f"[B] control '{action}' NOT a method on {cls_name}"))
                total_issues += 1

        # [C] JSON scenario IDs vs Python FAULT_SCENARIOS
        json_sc_ids = {(s.get("id") or s.get("scenario_id", "")) for s in scenarios}
        for sc_id in json_sc_ids:
            total_checks += 1
            if sc_id in py_scenarios:
                print(_ok(f"[C] scenario '{sc_id}' -> FAULT_SCENARIOS OK"))
            else:
                print(_err(f"[C] scenario '{sc_id}' in JSON but NOT in Python FAULT_SCENARIOS"))
                total_issues += 1

        # [D] Python scenarios vs JSON
        for sc_id in py_scenarios:
            total_checks += 1
            if sc_id in json_sc_ids:
                print(_ok(f"[D] Python scenario '{sc_id}' -> labs JSON OK"))
            else:
                print(_warn(f"[D] Python scenario '{sc_id}' NOT in {lab_file} — UI won't show it"))
                total_issues += 1

        # [E] JSON serialisability
        total_checks += 1
        state = instance.get_state()
        bad_keys = [k for k, v in state.items() if not _is_json_safe(v)]
        if bad_keys:
            print(_err(f"[E] get_state() has NaN/Inf keys: {bad_keys}"))
            total_issues += 1
        else:
            print(_ok(f"[E] get_state() all values JSON-safe OK"))

        # [G] Gauge scale headroom
        scale_issues = []
        for g in gauges:
            gid = g.get("id","?"); crit = g.get("crit_high"); mx = g.get("max")
            if crit and mx and isinstance(crit,(int,float)) and isinstance(mx,(int,float)) and crit > 0:
                if mx < crit * 1.20:
                    scale_issues.append(f"'{gid}': max={mx} < crit_high={crit}×1.20 (need ≥{crit*1.20:.1f})")
        total_checks += 1
        if scale_issues:
            for i in scale_issues: print(_warn(f"[G] SCALE: {i}")); total_issues += 1
        else:
            print(_ok(f"[G] all gauge scales have ≥20% headroom OK"))

        # [F] Gauge threshold types
        type_issues = []
        THRESHOLD_FIELDS = ("warn_high","crit_high","warn_low","crit_low","max","min","step")
        for g in gauges:
            gid = g.get("id","?")
            for field in THRESHOLD_FIELDS:
                if field in g and g[field] is not None:
                    if not isinstance(g[field], (int, float)):
                        type_issues.append(f"gauge '{gid}'.{field}={g[field]!r} must be numeric")
        total_checks += 1
        if type_issues:
            for i in type_issues: print(_err(f"[F] TYPE: {i}")); total_issues += 1
        else:
            print(_ok(f"[F] all gauge thresholds are numeric OK"))

        # [H] FIX #45: Step ID consistency — JSON scenario steps vs Python expected_steps
        for sc in scenarios:
            sc_id = sc.get("id") or sc.get("scenario_id","")
            if sc_id not in py_scenarios:
                continue
            json_step_ids = [s.get("id") for s in sc.get("steps", [])]
            # Get Python expected_steps from the module
            try:
                scenarios_dict = instance._get_fault_scenarios()
                py_expected = list(scenarios_dict[sc_id].expected_steps) if sc_id in scenarios_dict else []
            except Exception:
                py_expected = []
            total_checks += 1
            json_only = set(json_step_ids) - set(py_expected)
            py_only   = set(py_expected)   - set(json_step_ids)
            if json_only or py_only:
                print(_err(f"[H] '{sc_id}' step ID mismatch:"))
                if json_only: print(_err(f"     JSON-only: {sorted(json_only)}"))
                if py_only:   print(_err(f"     Python-only: {sorted(py_only)}"))
                total_issues += 1
            else:
                print(_ok(f"[H] '{sc_id}' step IDs synchronized OK"))

    print()
    print("=" * 66)
    print(f"  {total_checks} checks  |  ", end="")
    if total_issues == 0:
        print(f"{GREEN}{BOLD}ALL PASS — 0 issues found OK{RESET}")
    else:
        print(f"{RED}{BOLD}{total_issues} issue(s) found FAIL{RESET}")
    print()
    if strict and total_issues > 0:
        return 1
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="METS v1.0 project integrity check")
    parser.add_argument("--strict", action="store_true", help="Exit 1 on any issue (for CI)")
    args = parser.parse_args()
    sys.exit(validate(strict=args.strict))
