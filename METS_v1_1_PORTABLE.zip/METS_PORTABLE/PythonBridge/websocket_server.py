"""
PythonBridge/websocket_server.py

WebSocket bridge between the Marine Engineering Training Simulator (Python)
and the Unity 3D front-end.

Architecture
------------
  Python SimulationEngine  ←→  WebSocketBridge  ←→  Unity (C# client)

Protocol (JSON over WebSocket)
-------------------------------
  Unity  → Python:
    {"type": "command",
     "module": "diesel_generator",
     "action": "start_dg",
     "args":   [1]}

  Unity  → Python (lab selection):
    {"type": "select_lab",
     "lab_id": "diesel_generator"}

  Unity  → Python (reset):
    {"type": "reset",
     "module": "diesel_generator"}

  Python → Unity (state broadcast, 10 Hz):
    {"type": "state",
     "module": "<module_id>",
     "data":   <get_state() dict>,
     "tick":   <int>}

  Python → Unity (alarm event):
    {"type": "alarm",
     "module": "<module_id>",
     "alarm_id": "<id>",
     "message":  "<text>",
     "severity": <int>,
     "status":   "<ACTIVE|CLEARED>"}

  Python → Unity (lab list):
    {"type": "lab_list",
     "labs": [{"id": "...", "name_en": "...", "name_ua": "..."}, ...]}

Usage
-----
    python websocket_server.py [--host 0.0.0.0] [--port 8765]

The script adds the parent directory to sys.path so it can import the
existing marine_simulator package without modification.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import os
import threading
import time
from typing import Set

# ── Add simulator root to path ────────────────────────────────────────────────
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.join(SCRIPT_DIR, "..")
SIM_ROOT    = os.path.join(PROJECT_ROOT, "marine_simulator")
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, SIM_ROOT)

import websockets
from websockets.server import WebSocketServerProtocol

# FIX M-5: QApplication was imported and instantiated here but served no
# purpose — this is a pure asyncio/WebSocket server with no Qt event loop.
# The import created a hard dependency on PySide6 that crashed the bridge on
# any headless server or CI environment without a display.  Removed entirely.
from core.simulation_engine  import SimulationEngine
from core.simulation_thread  import SimulationThread
from core.ship_system_protocol import ShipSystemProtocol
from modules.oily_water_separator.ows_module      import OWSModule
from modules.boiler.boiler_module                  import BoilerModule
from modules.fw_generator.fwg_module               import FWGModule
from modules.hydrophore.hydro_module               import HydrophoreModule
from modules.refrigeration.refrig_module           import RefrigerationModule
from modules.fuel_separator.fsep_module            import FuelSeparatorModule
from modules.fuel_conditioning.fcm_module          import FCMModule
from modules.steering_gear.steer_module            import SteeringModule
from modules.diesel_generator.dg_module            import DGModule
from modules.cooling_system.csf_module             import CoolingSystemModule

log = logging.getLogger("SimBridge")

# ─────────────────────────────────────────────────────────────────────────────
# Module registry
# ─────────────────────────────────────────────────────────────────────────────

MODULE_CONSTRUCTORS = {
    "oily_water_separator":  OWSModule,
    "boiler":                BoilerModule,
    "fw_generator":          FWGModule,
    "hydrophore":            HydrophoreModule,
    "refrigeration":         RefrigerationModule,
    "fuel_separator":        FuelSeparatorModule,
    "fuel_conditioning":     FCMModule,
    "steering_gear":         SteeringModule,
    "diesel_generator":      DGModule,
    "cooling_system":        CoolingSystemModule,
}

LAB_METADATA = [
    {"id": "oily_water_separator", "lab_no": 1,
     "name_en": "Oily Water Separator (Hamworthy MK2)",
     "name_ua": "Сепаратор нафтовмісних вод (Hamworthy MK2)"},
    {"id": "boiler",               "lab_no": 2,
     "name_en": "Auxiliary Boiler (AQ-10)",
     "name_ua": "Допоміжний котел (AQ-10)"},
    {"id": "fw_generator",         "lab_no": 3,
     "name_en": "Fresh Water Generator (Alfa Laval JWP-26-C)",
     "name_ua": "Опрісняюща установка (Alfa Laval JWP-26-C)"},
    {"id": "refrigeration",        "lab_no": 4,
     "name_en": "Refrigeration Plant (R22)",
     "name_ua": "Холодильна установка (R22)"},
    {"id": "hydrophore",           "lab_no": 5,
     "name_en": "Hydrophore System",
     "name_ua": "Гідрофорна система"},
    {"id": "diesel_generator",     "lab_no": 6,
     "name_en": "Diesel Generators x2 (MSB Synchronisation)",
     "name_ua": "Дизель-Генератори x2 (Синхронізація ГРЩ)"},
    {"id": "fuel_separator",       "lab_no": 7,
     "name_en": "Fuel/Oil Separator (Alfa Laval S)",
     "name_ua": "Паливний сепаратор (Alfa Laval S)"},
    {"id": "steering_gear",        "lab_no": 8,
     "name_en": "Steering Gear (2-Ram Electro-Hydraulic)",
     "name_ua": "Рульова машина (2-плунжерна ЕГ)"},
    {"id": "fuel_conditioning",    "lab_no": 9,
     "name_en": "Fuel Conditioning Module (FCM One)",
     "name_ua": "Модуль кондиціювання палива (FCM One)"},
    {"id": "cooling_system",       "lab_no": 10,
     "name_en": "Seawater Cooling System Failure (SW Pump Trip)",
     "name_ua": "Відмова системи охолодження забортною водою (зупинка насоса)"},
]


# ─────────────────────────────────────────────────────────────────────────────
# Bridge
# ─────────────────────────────────────────────────────────────────────────────

class SimulationBridge:
    """
    Owns the SimulationEngine + SimulationThread and exposes a WebSocket API.
    One instance is created at startup; WebSocket handlers reference it.
    """

    BROADCAST_HZ = 10   # state push rate to Unity clients

    def __init__(self) -> None:
        # FIX M-5: QApplication instantiation removed — see import comment above.
        self._engine    = SimulationEngine()
        self._modules:  dict = {}
        self._thread:   SimulationThread | None = None
        self._clients:  Set[WebSocketServerProtocol] = set()
        self._lock      = threading.Lock()
        # FIX C-4: store a reference to the asyncio event loop so that
        # _on_alarm() — which is called from SimulationThread (a plain
        # threading.Thread) — can schedule coroutines safely via
        # asyncio.run_coroutine_threadsafe() instead of ensure_future().
        # ensure_future() raises RuntimeError when called from a non-asyncio
        # thread (Python 3.10+), so alarm messages were silently lost.
        self._loop: asyncio.AbstractEventLoop | None = None

        # Load all modules at startup
        for mod_id, cls in MODULE_CONSTRUCTORS.items():
            mod = cls()
            assert isinstance(mod, ShipSystemProtocol), \
                f"Module '{mod_id}' does not implement ShipSystemProtocol"
            mod.start()
            self._engine.register(mod)
            self._modules[mod_id] = mod
            # Wire alarm signals to broadcast
            mod.alarm_raised.connect(
                lambda alarm_id, sev, mid=mod_id:
                    self._on_alarm(mid, alarm_id, sev, "ACTIVE")
            )
            mod.alarm_cleared.connect(
                lambda alarm_id, mid=mod_id:
                    self._on_alarm(mid, alarm_id, 0, "CLEARED")
            )

        self._thread = SimulationThread(self._engine)
        self._thread.start()
        log.info("SimulationBridge started — %d modules loaded", len(self._modules))

    # ── Client registration ───────────────────────────────────────────

    def add_client(self, ws: WebSocketServerProtocol) -> None:
        with self._lock:
            self._clients.add(ws)
        log.info("Client connected: %s  (total=%d)", ws.remote_address, len(self._clients))
        # FIX C-4: capture the running asyncio loop the first time a client
        # connects (guaranteed to be called from inside asyncio).
        if self._loop is None:
            self._loop = asyncio.get_event_loop()
        asyncio.ensure_future(self._send(ws, {
            "type": "lab_list",
            "labs": LAB_METADATA,
        }))

    def remove_client(self, ws: WebSocketServerProtocol) -> None:
        with self._lock:
            self._clients.discard(ws)
        log.info("Client disconnected (total=%d)", len(self._clients))

    # ── Command dispatch ──────────────────────────────────────────────

    def dispatch(self, message: str) -> None:
        """Parse a JSON message from Unity and execute the command."""
        try:
            msg = json.loads(message)
        except json.JSONDecodeError:
            log.warning("Bad JSON from client: %s", message[:120])
            return

        msg_type = msg.get("type")

        if msg_type == "command":
            self._dispatch_command(msg)
        elif msg_type == "reset":
            mod_id = msg.get("module")
            if mod_id in self._modules:
                self._thread.enqueue_command(self._modules[mod_id].reset)
        elif msg_type == "select_lab":
            pass   # Labs are always loaded; Unity just switches its view

    def _dispatch_command(self, msg: dict) -> None:
        mod_id = msg.get("module", "")
        action = msg.get("action", "")
        args   = msg.get("args", [])
        # FIX #36: Block private/dunder method access
        if not action or action.startswith("_"):
            log.warning("Blocked private action attempt: %s.%s", mod_id, action)
            return
        mod    = self._modules.get(mod_id)
        if mod is None:
            log.warning("Unknown module: %s", mod_id)
            return
        fn = getattr(mod, action, None)
        if fn is None or not callable(fn):
            log.warning("Unknown action %s.%s", mod_id, action)
            return
        self._thread.enqueue_command(fn, *args)
        log.debug("Dispatched %s.%s(%s)", mod_id, action, args)

    # ── State broadcast (called from asyncio task at 10 Hz) ──────────

    async def broadcast_states(self) -> None:
        """Continuously push state dicts to all connected clients."""
        dt = 1.0 / self.BROADCAST_HZ
        while True:
            await asyncio.sleep(dt)
            if not self._clients:
                continue
            with self._lock:
                clients = list(self._clients)

            for mod_id, mod in self._modules.items():
                try:
                    state = mod.get_state()
                except Exception as exc:
                    log.error("get_state() error for %s: %s", mod_id, exc)
                    continue
                msg = json.dumps({
                    "type":   "state",
                    "module": mod_id,
                    "data":   state,
                    "tick":   self._engine.tick_count,
                })
                dead = set()
                for ws in clients:
                    try:
                        await ws.send(msg)
                    except websockets.ConnectionClosed:
                        dead.add(ws)
                with self._lock:
                    self._clients -= dead

    # ── Alarm relay ───────────────────────────────────────────────────

    def _on_alarm(self, module_id: str, alarm_id: str,
                  severity: int, status: str) -> None:
        msg = json.dumps({
            "type":      "alarm",
            "module":    module_id,
            "alarm_id":  alarm_id,
            "severity":  severity,
            "status":    status,
        })
        with self._lock:
            clients = list(self._clients)
        # FIX C-4: _on_alarm is invoked by SimulationThread — a plain
        # threading.Thread that runs outside the asyncio event loop.
        # asyncio.ensure_future() called from a foreign thread raises
        # RuntimeError("no running event loop") in Python 3.10+, so alarm
        # messages were silently dropped.  run_coroutine_threadsafe() is the
        # correct cross-thread scheduling API: it submits the coroutine to the
        # loop that was captured in add_client() and returns a concurrent.Future.
        loop = self._loop
        if loop is None or not loop.is_running():
            return   # loop not yet started or already stopped — drop gracefully
        for ws in clients:
            asyncio.run_coroutine_threadsafe(self._send(ws, msg, raw=True), loop)

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    async def _send(ws: WebSocketServerProtocol,
                    payload, raw: bool = False) -> None:
        try:
            text = payload if raw else json.dumps(payload)
            await ws.send(text)
        except websockets.ConnectionClosed:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# WebSocket handler
# ─────────────────────────────────────────────────────────────────────────────

bridge: SimulationBridge | None = None


async def handler(ws: WebSocketServerProtocol, path: str) -> None:
    bridge.add_client(ws)
    try:
        async for message in ws:
            bridge.dispatch(message)
    except websockets.ConnectionClosed:
        pass
    finally:
        bridge.remove_client(ws)


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

async def main(host: str, port: int) -> None:
    global bridge
    bridge = SimulationBridge()

    log.info("WebSocket server starting on ws://%s:%d", host, port)
    async with websockets.serve(handler, host, port):
        await asyncio.gather(
            bridge.broadcast_states(),
            asyncio.Future(),   # run forever
        )


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(name)-14s  %(levelname)-8s  %(message)s",
    )
    parser = argparse.ArgumentParser(description="Marine Sim WebSocket Bridge")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    asyncio.run(main(args.host, args.port))
