# METS v1.0 — Marine Engineering Training Simulator  
## Architecture Documentation

---

## Overview

METS (Marine Engineering Training Simulator) is a browser-based real-time training platform for marine engineering students. It simulates 10 shipboard machinery systems in accordance with STCW A-III/1 competency standards.

**Version:** 1.0 (GOLD)  
**Architecture:** Python asyncio backend + JavaScript SVG frontend, communicating via WebSocket  
**Standards:** STCW 2010 Manila Amendments, MARPOL Annex I, SOLAS Chapter II-1

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Browser (Student / Instructor)                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │ scada.js │ │  app.js  │ │features.js│ │instructor│   │
│  │(P&ID SVG)│ │(WS/State)│ │(UI tools)│ │   .js    │   │
│  └────┬─────┘ └────┬─────┘ └──────────┘ └──────────┘   │
│       └────────────┴──── WebSocket (JSON) ───────────┐  │
└──────────────────────────────────────────────────────│──┘
                                                        │
┌──────────────────────────────────────────────────────│──┐
│  sim_server.py (Python asyncio)                       │  │
│  ┌─────────────────────────────────────────────────┐ │  │
│  │  WebSocket Handler (asyncio, port 8765)         │◄┘  │
│  │  • Auth token validation                        │    │
│  │  • Per-client lab selection (_client_lab)       │    │
│  │  • Command dispatch (action whitelist)          │    │
│  └──────────────────┬──────────────────────────────┘    │
│                     │ tick() @ 1 Hz                      │
│  ┌──────────────────▼──────────────────────────────┐    │
│  │  SimulationEngine                               │    │
│  │  • Orchestrates all 10 physics modules          │    │
│  │  • Power coupling (DG → all modules)            │    │
│  └──────────────────┬──────────────────────────────┘    │
│                     │                                    │
│  ┌──────────────────▼──────────────────────────────┐    │
│  │  10 Lab Modules (BaseLabModule subclasses)       │    │
│  │  BoilerModule │ OWSModule │ DGModule │ ...       │    │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐   │    │
│  │  │  Physics   │ │ Procedure  │ │   Fault    │   │    │
│  │  │  (dataclass│ │(STCW steps)│ │ Injection  │   │    │
│  │  │   + step())│ │(scoring)   │ │  Engine    │   │    │
│  │  └────────────┘ └────────────┘ └────────────┘   │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌─────────────┐   ┌────────────────┐                   │
│  │ HTTP Server │   │  session_db.py │                   │
│  │ (port 8080) │   │  (SQLite WAL)  │                   │
│  │ static files│   │  session logs  │                   │
│  └─────────────┘   └────────────────┘                   │
└────────────────────────────────────────────────────────-┘
```

---

## Directory Structure

```
METS_v1.0/
├── sim_server.py              # Main entry point — asyncio WS + HTTP server
├── run_simulator.py           # Launcher helper (auto-opens browser)
├── validate_project.py        # CI integrity checker (9 check categories)
│
├── marine_simulator/
│   ├── core/
│   │   ├── base_module.py         # Abstract base for all lab modules
│   │   ├── base_procedure.py      # STCW step assessment engine
│   │   ├── base_faults.py         # Re-exports for backward compat
│   │   ├── fault_injection_engine.py  # Atomic fault injection (thread-safe)
│   │   ├── simulation_engine.py   # Module orchestrator + power coupling
│   │   ├── simulation_thread.py   # Background physics thread (PythonBridge)
│   │   ├── assessment_rules.py    # Dynamic procedure builder (DPM)
│   │   ├── session_db.py          # SQLite session persistence
│   │   └── ship_system_protocol.py  # Structural typing Protocol
│   │
│   └── modules/
│       ├── boiler/                # Lab 2 — Auxiliary Boiler
│       ├── oily_water_separator/  # Lab 1 — OWS
│       ├── fw_generator/          # Lab 3 — Fresh Water Generator
│       ├── refrigeration/         # Lab 4 — Refrigeration Plant
│       ├── hydrophore/            # Lab 5 — Hydrophore System
│       ├── diesel_generator/      # Lab 6 — Diesel Generator / MSB
│       ├── fuel_separator/        # Lab 7 — Fuel Separator
│       ├── steering_gear/         # Lab 8 — Steering Gear
│       ├── fuel_conditioning/     # Lab 9 — FCM
│       └── cooling_system/        # Lab 10 — Central Seawater Cooling
│
├── web_ui/
│   ├── index.html            # Single-page application shell
│   ├── ws_port.js            # Auto-generated port config (at startup)
│   ├── css/
│   │   └── simulator.css     # Full dark-theme HMI stylesheet
│   └── js/
│       ├── app.js            # WebSocket client + state management
│       ├── scada.js          # P&ID SVG renderer (all 10 schematics)
│       ├── features.js       # Audio alarms, trend recorder, PDF export
│       └── instructor.js     # Instructor dashboard panel
│
├── labs/                     # Lab JSON definitions (gauges, scenarios, steps)
│   ├── lab01_ows.json
│   ├── lab02_boiler.json
│   └── ... (10 total)
│
├── PythonBridge/
│   └── websocket_server.py   # Unity 3D bridge (uses SimulationThread)
│
└── manuals/                  # Student and instructor documentation
```

---

## Core Subsystems

### 1. WebSocket Protocol (sim_server.py)

**Security:** Auth token generated at startup, written to `ws_port.js`, required in every client message.

**Message types (client → server):**

| Type | Description |
|------|-------------|
| `hello` | Initial handshake, receives auth_token |
| `select_lab` | Start a lab session, resets module state |
| `command` | Execute module action (whitelist enforced, `_` prefix blocked) |
| `inject_fault` | Inject a fault scenario (instructor only) |
| `ack_alarm` | Acknowledge an active alarm |
| `reset` | Reset module to nominal state |

**Message types (server → client):**

| Type | Description |
|------|-------------|
| `connected` | Handshake response with auth_token |
| `lab_list` | Available lab definitions |
| `telemetry` | Physics state + NEW alarms (1 Hz, delta only) |
| `procedure_update` | Step list update after fault injection |
| `hard_fail` | Immediate notification of hard fail event |
| `fault_injected` | Confirmation of scenario injection |

### 2. Physics Engine

Each module has three components:

**Physics dataclass** (`*State`) — pure data, no logic. Fields map 1:1 to `get_state()` keys used by SCADA gauges.

**Physics class** (`*Physics`) — `step(dt_s)` advances simulation one tick, returns `list[tuple[alarm_id, severity]]`. Uses first-order lag (τ) for realistic transient response.

**Module** (`*Module extends BaseLabModule`) — bridges physics to procedure and fault engine. Implements:
- `_check_hard_fail()` — catastrophic condition detection
- `_check_auto_advance()` — physics-triggered step completion
- Operator action methods (called from UI buttons)

### 3. Assessment System (DynamicProcedureManager)

On fault injection:
1. `FaultInjectionEngine.inject()` applies `interrupt_overrides` (immediate state) then `_apply_fn` (physics changes). Atomic — rolls back on failure.
2. `DynamicProcedureManager.rebuild_procedure()` filters STEP_DEFINITIONS to only the steps relevant for this scenario, resets timers.
3. `BaseProcedure.mark_done()` / `auto_mark_done()` track step completion with time-penalty scoring.
4. Final grade: DISTINCTION (≥90%) / PASS (≥75%) / BORDERLINE_PASS (≥60%) / FAIL.

### 4. Power Coupling

`SimulationEngine._update_power_state()` reads DG bus voltage after every tick. If voltage drops below 50V (blackout), all non-DG modules receive `set_power_available(False)`, stopping their motors and pumps. Students cannot start electrical equipment during blackout.

### 5. SCADA Renderer (scada.js)

Generates SVG P&ID schematics in real-time. Each of the 10 labs has a hand-crafted rendering function. Uses ISO 14726 pipe colour codes and ISA 5.1 symbol library. Values are guarded by `_n(v, decimals, fallback)` — returns `"—"` instead of NaN/undefined.

---

## Security Architecture

| Threat | Mitigation |
|--------|-----------|
| WebSocket command injection | Auth token required on every message |
| Private method access (RCE) | `action.startswith('_')` blocked in dispatch |
| Path traversal via HTTP | URL decoded + normalized before extension check |
| XSS via server data | `escHtml()` applied to all `innerHTML` insertions |
| CSV export path traversal | Output restricted to `exports/` subdirectory |
| Oversized WS frames (OOM) | `MAX_WS_PAYLOAD = 256KB` enforced in frame decoder |
| Clickjacking | `X-Frame-Options: SAMEORIGIN` header |
| MIME sniffing | `X-Content-Type-Options: nosniff` header |
| Content injection | `Content-Security-Policy` restricts external sources |

---

## Thread Safety

| Resource | Mechanism |
|----------|-----------|
| `_active_alarms` dict | `threading.Lock` in `BaseLabModule` |
| `_alarm_buf` deque | `threading.Lock` in sim_server |
| `FaultInjectionEngine._fie_injecting` | `threading.Lock` wraps bool check |
| `DynamicProcedureManager.rebuild_procedure()` | Per-procedure `threading.Lock` |
| `SimulationThread` command queue | `Queue(maxsize=200)` (bounded, DoS-safe) |

---

*METS v1.0 — Developed by the Department of Ship Power Plants Operation and Thermal Power Engineering*
