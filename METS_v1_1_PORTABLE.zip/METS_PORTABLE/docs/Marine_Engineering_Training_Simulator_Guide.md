
# Marine Engineering Training Simulator
## Instructor & Student Guide

### 1. Introduction
The Marine Engineering Training Simulator is an educational platform designed to train marine engineering students in diagnosis, operation, and troubleshooting of ship machinery systems.

### 2. System Architecture
Web UI → WebSocket → FastAPI Server → Physics Engine → Equipment Modules

### 3. Laboratories

1. Oily Water Separator (OWS)
2. Auxiliary Boiler
3. Fresh Water Generator
4. Refrigeration Plant
5. Hydrophore System
6. Diesel Generator System
7. Fuel Separator
8. Fuel Conditioning Module
9. Steering Gear
10. Seawater Cooling System

### 4. Laboratory Details

**OWS**
Purpose: Separate oil from bilge water.
Key parameters: Oil ppm, flow rate, heater temperature.
Typical faults:
- Heater failure
- Monitor malfunction
- Disc blockage

**Boiler**
Purpose: Produce steam for ship systems.
Key parameters: Steam pressure, water level.
Typical faults:
- Flame failure
- Feed pump trip

**Fresh Water Generator**
Purpose: Produce freshwater from seawater.
Fault examples:
- Ejector failure
- Tube leak

**Refrigeration**
Maintains cold storage temperatures.
Faults:
- Refrigerant leak
- Compressor trip

**Hydrophore**
Maintains freshwater pressure onboard.

**Diesel Generator**
Electrical power generation system.

**Fuel Separator**
Removes contaminants from fuel oil.

**Fuel Conditioning Module**
Controls viscosity and temperature of fuel.

**Steering Gear**
Controls rudder movement.

**Cooling System**
Maintains engine operating temperature.

### 5. Instructor Dashboard
Instructor can:
- Inject faults
- Start scenarios
- Monitor student actions

### 6. Scenario Training
Example scenarios:

| Scenario | System | Fault |
|--------|------|------|
| 1 | Boiler | Flame Failure |
| 2 | OWS | High Oil Content |
| 3 | Cooling | Pump Failure |

### 7. Session Recorder
All student actions are recorded with timestamps.

### 8. Student Workflow
1. Select laboratory
2. Observe parameters
3. Diagnose problem
4. Execute corrective actions

### 9. Evaluation Criteria

| Criteria | Description |
|---------|-------------|
| Detection time | Speed of fault identification |
| Diagnosis | Correct cause identification |
| Procedure | Correct actions |
| Stabilization | Recovery of system |

### 10. Future Development
- multi-student classroom mode
- automatic grading
- 3D engine room visualization
