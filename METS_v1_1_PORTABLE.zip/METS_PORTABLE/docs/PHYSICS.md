# METS v1.0 — Physics Models Reference

---

## Overview

All physics modules use **first-order lag** (exponential smoothing) for state transitions, providing realistic transient behaviour without numerical instability:

```
dx/dt = (target - x) / τ
→ x_new = x + (target - x) / τ * dt
```

All values are safety-clamped after each tick. Division-by-zero is prevented by `max(ε, ...)` guards. Safety valve hysteresis uses confirmation timers to prevent oscillation.

---

## Lab 1 — Oily Water Separator (Hamworthy MK2)

**Key parameters:** PPM limit 15 (MARPOL Annex I), flow 2.5 L/s, heater 55°C

| State variable | Physics model |
|---|---|
| `oil_content_ppm` | First-order lag τ=20s toward `base_ppm`. `base_ppm = 5 / disc_condition` when fully operational; 60 ppm when not running. Guard: `max(0.05, disc_condition)` prevents div/zero |
| `flow_ls` | First-order lag τ=5s toward `NOMINAL_FLOW × disc_condition` |
| `heater_temp_c` | First-order lag τ=60s toward 55°C (on) or 22°C (off) |
| `bowl_speed_pct` | Spin-up τ=30s. Purification only at ≥95% bowl speed (realistic Alfa-Laval behaviour) |

**Hard Fails:**
- `three_way_valve_overboard=True` AND `oil_content_ppm > 15` → `MARPOL_ILLEGAL_DISCHARGE` (STCW/MARPOL)
- Student calls `switch_overboard()` above limit → stops separator + hard fail

---

## Lab 2 — Auxiliary Boiler (AQ-10)

**Key parameters:** Nominal 7.0 bar, safety valve 8.5 bar, SCRAM water 10%

| State variable | Physics model |
|---|---|
| `steam_pressure_bar` | First-order lag τ=25s. Target = 7.0 + demand×3.0 (firing). Drain = demand×0.05/s. Fuel-stuck scenario: target = safety+1.5 (runaway) |
| `water_level_pct` | Feed pump: +0.10%/s each. Steam consumption: -0.10%/s (flame on), -0.02%/s (off) |
| `flue_temp_c` | First-order lag τ=20s toward 280°C (firing) or 45°C (off) |
| `safety_valve` | Opens at ≥8.5 bar after 1s confirmation timer; bleeds 0.5 bar/s. Closes at <8.0 bar with 0.5 bar hysteresis |

**Hard Fails:**
- `water_level_pct ≤ 10%` → `BOILER_DANGEROUSLY_LOW_WATER`
- `start_boiler()` or `relight_burner()` with dry drum → `LETHAL_DRY_BOILER`
- `burner_locked_out=True` respected by `start_boiler()` — no bypass

---

## Lab 3 — Fresh Water Generator (Alfa Laval JWP-26-C)

**Real spec:** 26 t/day = 1.08 t/h, 93% vacuum (71 mbar abs), JW inlet 80°C

| State variable | Physics model |
|---|---|
| `vacuum_mbar` | First-order lag τ=20s toward 71 mbar (ejector on) or 1013 mbar (off) |
| `fw_production_th` | Requires: ejector running + vacuum < 150 mbar + JW ≥ 65°C. Rate = 1.08 × tube_eff × vac_factor × jw_factor |
| `salinity_ppm` | First-order lag τ=20s. Target = 5×2.5/tube_eff when tube_condition < 0.5; 1.5 ppm clean operation |

**Hard Fail:** Producing at salinity > 5 ppm for more than 5 ticks → `FW_CONTAMINATION_PRODUCTION_NOT_STOPPED`

---

## Lab 4 — Refrigeration Plant (R22)

**Vapour compression cycle with Bernoulli leak model**

| State variable | Physics model |
|---|---|
| `condenser_pressure_bar` | Target = `NOMINAL / cond_factor`. Guard: `cond_factor = max(0.05, condenser_condition)` |
| `suction_pressure_bar` | Target = `NOMINAL × charge_factor`. Zero charge → zero suction |
| `discharge_temp_c` | Target = `85 / cond_factor`. High at low condensing efficiency |
| `refrigerant_charge_pct` | Bernoulli leak: `dQ/dt = orifice_coeff × √P_suction × dt`. Progressive, pressure-dependent drain |

**Hard Fail:** `discharge_temp_c ≥ 140°C` → `COMPRESSOR_OVERHEAT_SCRAM`

**Note:** `refrig_compressor_trip` scenario uses `condenser_fouling(0.2)` → condition=0.8 → condenser_pressure = 12/0.8 = 15.0 bar < VERIFY threshold 16.0 → completable.

---

## Lab 5 — Hydrophore System

**Key parameters:** Nominal 3.5 bar, air cushion 35%, SCRAM at <2.0 bar

| State variable | Physics model |
|---|---|
| `tank_pressure_bar` | With pump: `target = NOMINAL × air_cushion + net_flow × 0.1`. No pump: pressure decays from demand drain |
| `air_charge_pct` | Air leak: -0.3%/s. Waterlogged: -0.1%/s additional. Clamped 0–50% |
| Waterlogged | `air_cushion = 0.1` (near-zero) → wildly unstable pressure |

---

## Lab 6 — Diesel Generator (MSB Synchronisation)

**Key parameters:** 750 RPM, 50 Hz, 400 V, overload threshold 500 kW

| State variable | Physics model |
|---|---|
| `frequency_hz` | First-order lag τ=8s toward 50 Hz. Governor fault → 3 Hz penalty (only from on-bus generators) |
| `voltage_v` | First-order lag τ=8s toward 400 V |
| `speed_rpm` | First-order lag τ=8s toward 750 RPM |

**Reverse power protection:** If CB closed and RPM < 100 → CB trips automatically (prevents motoring)

**Hard Fail:** `close_breaker()` when RPM < 92% of nominal → `OUT_OF_SYNC_BREAKER_CLOSE` (teaches correct synchronisation procedure)

---

## Lab 7 — Fuel Separator (Alfa Laval S)

**Key parameters:** 7500 RPM, 98°C fuel temp, PURIFY threshold 7125 RPM (95%)

| State variable | Physics model |
|---|---|
| `bowl_speed_rpm` | First-order lag τ=15s. Motor fault: target=3000 RPM instead of 7500 |
| `clean_fuel_flow_ls` | Gated at ≥95% bowl speed. Rate = 0.8 × temp_efficiency × rpm_fraction |
| `sludge_level_pct` | +0.02%/s while running |

**Hard Fail:** `sludge_level_pct ≥ 99.5%` with separator running → `SLUDGE_OVERFLOW_FUEL_CONTAMINATION`

---

## Lab 8 — Steering Gear (Hydroster 2-Ram Electro-Hydraulic)

**Real spec:** ±35°, putting-over time ≤28s (1 pump), ≤14s (2 pumps)

| State variable | Physics model |
|---|---|
| `rudder_angle_deg` | Rate: 2.32 deg/s (1 pump), 4.64 deg/s (2 pumps). Requires pressure > 80 bar |
| `hydraulic_pressure_bar` | First-order lag τ=10s. Bernoulli leak when `oil_leak=True`: `P, level = f(√P, dt)` |
| `oil_temp_c` | +0.005°C/s per active pump. Alarm at ≥70°C |

**Hard Fail (isolation safety):** `isolate_leak()` when NO active leak AND pump running AND P > 100 bar → `UNSAFE_ISOLATION_UNDER_PRESSURE`. When oil_leak is active (pressure FALLING), isolation is always safe.

---

## Lab 9 — Fuel Conditioning Module (Alfa Laval FCM One)

**Real spec:** LP 4 bar, HP 8 bar, viscosity target 8–15 cSt at engine

| State variable | Physics model |
|---|---|
| `viscosity_cst` | Walther equation calibrated to Alfa Laval HFO data: `ν = 29,407,209 / (T-20)^3.13` where T = max(30, fuel_temp). Blend zone 75–95°C for smooth transition |
| `lp_pressure_bar` | LP = LP_nominal / visc_factor (viscosity-pressure coupling) |
| `pressure_bar` | HP = (LP + 4) / visc_factor. Standby pump auto-starts after 3s delay |

**Hard Fails:**
- `viscosity_cst ≥ 50 cSt` (SCRAM) → `ME_FUEL_STARVATION_VISC_XXcST`
- `pressure_bar < 1.0` with no standby pump → `ME_FUEL_STARVATION_NO_FLOW`

**Alarm confirmations:** HIGH_VISC needs 3s sustained exceedance. Diesel auto-switch delayed 4s after confirmed alarm.

---

## Lab 10 — Seawater Cooling System

**Calibrated to:** Engine waste heat ≈ 800 kW, nominal FW supply 36°C, SW inlet 22°C

| State variable | Physics model |
|---|---|
| `fw_temp_c` | `d(FW)/dt = engine_heat/60 - hx_eff × (FW - SW_in) × 0.0095`. Clamped ≥ SW+2°C |
| `hx_eff` | `hx_condition × min(1, sw_flow / 25)`. Calibrated: at nominal, cooling = heating rate (36°C steady state) |
| `sw_temp_out_c` | `SW_in + min(12, 8 / (sw_flow/25))` |

**Hard Fail:** `fw_temp_c ≥ 58°C` → `CSF_OVERHEAT_SCRAM`

**Alarms:** `CSF_HIGH_FW_TEMP` at 42°C (severity 2), `CSF_CRITICAL_FW_TEMP` at 50°C (severity 3) — gives students a 12°C / ~90s window before SCRAM.

---

## General Alarm Architecture

All alarms use **latching with hysteresis** to prevent oscillation:

```python
# Rising latch with hysteresis band
if value > HIGH_THRESHOLD and not _latched:
    _latched = True
    emit(alarm_id, severity=2)        # ALARM ON
elif value < HIGH_THRESHOLD - BAND and _latched:
    _latched = False
    emit(alarm_id, severity=0)        # ALARM CLEARED
```

Severity levels: 1=Info, 2=Warning, 3=Critical

---

*METS v1.0 — Physics parameters validated against manufacturer datasheets:*  
*Alfa Laval JWP-26-C, Alfa Laval FCM One (MDD00057RU), Hydroster MS200/MS320*
