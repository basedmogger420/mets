# METS v1.0 — GOLD BUILD Changelog

## v1.0 (GOLD) — All 52 Audit Fixes

### 🔴 Critical Fixes (8)

| # | File | Fix |
|---|------|-----|
| 1 | sim_server.py | Path Traversal: URL decode+normpath before extension check |
| 2 | sim_server.py | WebSocket auth token — all commands require `auth_token` |
| 3 | base_module.py | `_active_alarms` protected by `threading.Lock` |
| 14 | app.js | `escHtml()` sanitizes all `innerHTML` insertions of server data |
| 27 | labs/*.json | All 10 lab JSON files: step IDs synchronized with Python |
| 28 | ows_module.py | MARPOL Hard Fail fires at PPM > 15 with valve overboard |
| 36 | websocket_server.py | PythonBridge: `action.startswith("_")` guard added |
| 45 | validate_project.py | Fixed broken JSON key + added `get_scenario_list()` + check [H] |

### 🟠 High Fixes (21)

| # | File | Fix |
|---|------|-----|
| 4 | boiler_module.py | `start_boiler()` rejects when `water_level ≤ SCRAM` |
| 5 | refrig_physics.py | Explicit `charge_factor=0` branch with fallback |
| 6 | boiler_faults.py | Boiler expected_steps aligned with OWSProcedure step IDs |
| 7 | ows_module.py | `switch_overboard()` Hard Fail stops separator immediately |
| 8 | sim_server.py | Hard Fail event broadcast to client after every action |
| 9 | dg_module.py | Out-of-sync CB close triggers Hard Fail |
| 15 | session_db.py | `export_csv()` confined to `exports/` subdirectory |
| 16 | assessment_rules.py | `rebuild_procedure()` uses `proc._rebuild_lock` |
| 17 | fwg_module.py | Hard Fail after 5 ticks producing above 5 ppm salinity |
| 18 | scada.js | `_n(v,d,fb)` safe formatter injected at module top |
| 19 | csf_module.py | `RESET_TRIP` auto-advance removed — student must act |
| 29 | refrig_faults.py | `refrig_compressor_trip`: added `INCREASE_COOLING` + reduced fouling |
| 30 | fcm_module.py | `_check_hard_fail()` added for SCRAM_VISC and no-flow |
| 31 | lab06_dg.json | DG blackout scenario steps match Python procedure |
| 32 | websocket_server.py | PythonBridge documented as requiring same fixes as sim_server |
| 37 | sim_server.py | CSP + X-Frame-Options + X-Content-Type-Options headers added |
| 38 | csf_module.py | Intermediate severity-3 alarm at 50°C (before SCRAM at 58°C) |
| 39 | websocket_server.py | Lab 8/9 order corrected (Steering=8, FCM=9) |
| 40 | scada.js | `_n()` helper covers all 22 raw `.toFixed()` call sites |
| 46 | features.js | `_escRpt()` sanitizes exportReport() HTML |
| 47 | steer_module.py | `inject_oil_overtemp()` and `steer_oil_overtemp` scenario added |
| 48 | fault_injection_engine.py | State snapshot rollback if `_apply_fn` raises exception |

### 🟡 Medium Fixes (23)

| # | File | Fix |
|---|------|-----|
| 10 | sim_server.py | Per-client alarm cursor — only NEW alarms sent each tick |
| 11 | boiler_physics.py | Safety valve 1-second confirmation timer (hysteresis) |
| 12 | fault_injection_engine.py | `_fie_injecting` guard uses `threading.Lock` |
| 13 | sim_server.py | Disconnect only resets module if no other client has it |
| 20 | base_procedure.py | `_borderline_offset_pct` restored in `rebuild_procedure()` |
| 21 | hydro_module.py | `START_PUMP2` auto-advance removed (Pump1 no longer credited) |
| 22 | sim_server.py | `MAX_WS_PAYLOAD = 256 KB` — close oversized frames |
| 23 | assessment_rules.py | `_inject_fault_patched` guard prevents double monkey-patch |
| 24 | sim_server.py | `_alarm_buf` mutations protected by `threading.Lock` |
| 25 | dg_procedure.py | `RESTORE_LOAD` confirmed present — no fix needed |
| 26 | app.js/scada.js | Documented; _n() helper reduces GC pressure |
| 33 | validate_project.py | Check [H] step ID consistency added |
| 34 | steer_module.py | `steer_oil_leak` expected_steps includes `NOTIFY_BRIDGE` |
| 35 | fwg_module.py | `increase_jw_temp()` method added for jw_temp_drop scenario |
| 41 | simulator.css | Documented; fonts remain for online environments |
| 42 | app.js | `escHtml()` covers `sc.id` in instructor onclick attributes |
| 43 | sim_server.py | `ws_port.js` URL check uses `split("?")[0] == "/ws_port.js"` |
| 44 | boiler_module.py | `start_boiler()` respects `burner_locked_out` flag |
| 49 | auto_demo.html | Documented; hardcoded strings are safe currently |
| 50 | simulation_engine.py | `reset_all()` calls `_update_power_state()` after reset |
| 51 | instructor.js | Version comment updated to v1.0 |
| 52 | steer_module.py | `isolate_leak()` safe when `oil_leak=True` regardless of pressure |

## v1.0.1 — Bug Fix Session 2 (2026-03-25)

### Critical Fixes

**BUG-H** `dg_governor_fault` — `START_DG2` was missing from `expected_steps`.
DG2 is not running after fault injection; student must start it before syncing, but
the step was absent from the procedure display and earned no credit.
_Fix: added `START_DG2` between `IDENTIFY_FAULT` and `SYNC_DG2` in `expected_steps`._

**BUG-I** `csf_sw_shortage` — `CLEAN_HX` was incorrectly included in `expected_steps`.
The HX is clean in this scenario (`hx_condition=1.0`), so `CLEAN_HX` fired automatically
after ACK, giving students free points for a step they never performed.
_Fix: removed `CLEAN_HX` from `csf_sw_shortage` expected_steps._

**BUG-J** `csf_pump_trip` — `VERIFY_TEMPS` auto-fired immediately after ACK because
`fw_temp_c` was never elevated at fault injection (no `interrupt_overrides`). Students
received credit without performing any corrective action.
_Fix: added `interrupt_overrides={"fw_temp_c": 46.0}` to `csf_pump_trip`._

**BUG-K** `fcm_viscometer` — `VERIFY_VISCOSITY` auto-fired immediately after ACK because
viscosity was at nominal (11.8 cSt) despite viscometer fault injection. Students could
complete the scenario without bypassing the failed viscometer.
_Fix: added `viscosity_cst: 22.0` interrupt override; gated `VERIFY_VISCOSITY`
auto-advance behind its prerequisite step (BYPASS_VISCOMETER / RESTORE_HEATING / START_PUMP2)._

### Minor Fixes

**BUG-B** `steer_feedback_fail`, `steer_oil_overtemp` — `auto_mark_done("START_PUMP2")`
was called even in scenarios where `START_PUMP2` is not an expected step. Silently
harmless but cluttered the logic.
_Fix: guard with `has_start_pump2` check in `SteerAssessmentRules.check_auto_advance`._

**BUG-B2** `fcm_heater`, `fcm_viscometer` — same pattern as BUG-B for FCM.
_Fix: `has_start_pump2` guard in `FCMAssessmentRules.check_auto_advance`._

**BUG-B3** `csf_pump_trip`, `csf_sw_shortage` — `auto_mark_done("CLEAN_HX")`
called in scenarios without that step.
_Fix: `has_clean_hx` guard in `CSFAssessmentRules.check_auto_advance`._
